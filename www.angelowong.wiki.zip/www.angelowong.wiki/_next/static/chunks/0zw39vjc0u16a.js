(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push(["object" == typeof document ? document.currentScript : void 0, 423755, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    });
    let n = (0, e.r(543369).getDeploymentId)();
    globalThis.NEXT_DEPLOYMENT_ID = n, ("function" == typeof r.default || "object" == typeof r.default && null !== r.default) && void 0 === r.default.__esModule && (Object.defineProperty(r.default, "__esModule", {
        value: !0
    }), Object.assign(r.default, r), t.exports = r.default)
}, 140170, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), Object.defineProperty(r, "getAssetPrefix", {
        enumerable: !0,
        get: function() {
            return o
        }
    });
    let n = e.r(312718);

    function o() {
        let e = document.currentScript;
        if (!(e instanceof HTMLScriptElement)) throw Object.defineProperty(new n.InvariantError(`Expected document.currentScript to be a <script> element. Received ${e} instead.`), "__NEXT_ERROR_CODE", {
            value: "E783",
            enumerable: !1,
            configurable: !0
        });
        let {
            pathname: t
        } = new URL(e.src), r = t.indexOf("/_next/");
        if (-1 === r) throw Object.defineProperty(new n.InvariantError(`Expected document.currentScript src to contain '/_next/'. Received ${e.src} instead.`), "__NEXT_ERROR_CODE", {
            value: "E784",
            enumerable: !1,
            configurable: !0
        });
        return t.slice(0, r)
    }("function" == typeof r.default || "object" == typeof r.default && null !== r.default) && void 0 === r.default.__esModule && (Object.defineProperty(r.default, "__esModule", {
        value: !0
    }), Object.assign(r.default, r), t.exports = r.default)
}, 396517, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), Object.defineProperty(r, "appBootstrap", {
        enumerable: !0,
        get: function() {
            return a
        }
    });
    let n = e.r(140170),
        o = e.r(922737);

    function a(e) {
        var t, r;
        let a = (0, n.getAssetPrefix)();
        t = self.__next_s, r = () => {
            e(a)
        }, t && t.length ? t.reduce((e, [t, r]) => e.then(() => new Promise((e, n) => {
            let a = document.createElement("script");
            r && (0, o.setAttributesFromProps)(a, r), t ? (a.src = t, a.onload = () => e(), a.onerror = n) : r && (a.innerHTML = r.children, setTimeout(e)), document.head.appendChild(a)
        })), Promise.resolve()).catch(e => {
            console.error(e)
        }).then(() => {
            r()
        }) : r()
    }
    window.next = {
        version: "16.2.1",
        appDir: !0
    }, ("function" == typeof r.default || "object" == typeof r.default && null !== r.default) && void 0 === r.default.__esModule && (Object.defineProperty(r.default, "__esModule", {
        value: !0
    }), Object.assign(r.default, r), t.exports = r.default)
}, 816565, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    });
    var n = {
        getObjectClassLabel: function() {
            return a
        },
        isPlainObject: function() {
            return l
        }
    };
    for (var o in n) Object.defineProperty(r, o, {
        enumerable: !0,
        get: n[o]
    });

    function a(e) {
        return Object.prototype.toString.call(e)
    }

    function l(e) {
        if ("[object Object]" !== a(e)) return !1;
        let t = Object.getPrototypeOf(e);
        return null === t || t.hasOwnProperty("isPrototypeOf")
    }
}, 302023, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    });
    var n = {
        default: function() {
            return l
        },
        getProperError: function() {
            return i
        }
    };
    for (var o in n) Object.defineProperty(r, o, {
        enumerable: !0,
        get: n[o]
    });
    let a = e.r(816565);

    function l(e) {
        return "object" == typeof e && null !== e && "name" in e && "message" in e
    }

    function i(e) {
        let t;
        return l(e) ? e : Object.defineProperty(Error((0, a.isPlainObject)(e) ? (t = new WeakSet, JSON.stringify(e, (e, r) => {
            if ("object" == typeof r && null !== r) {
                if (t.has(r)) return "[Circular]";
                t.add(r)
            }
            return r
        })) : e + ""), "__NEXT_ERROR_CODE", {
            value: "E394",
            enumerable: !1,
            configurable: !0
        })
    }
}, 528279, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), Object.defineProperty(r, "reportGlobalError", {
        enumerable: !0,
        get: function() {
            return n
        }
    });
    let n = "function" == typeof reportError ? reportError : e => {
        globalThis.console.error(e)
    };
    ("function" == typeof r.default || "object" == typeof r.default && null !== r.default) && void 0 === r.default.__esModule && (Object.defineProperty(r.default, "__esModule", {
        value: !0
    }), Object.assign(r.default, r), t.exports = r.default)
}, 597238, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    });
    var n = {
        isRecoverableError: function() {
            return c
        },
        onRecoverableError: function() {
            return s
        }
    };
    for (var o in n) Object.defineProperty(r, o, {
        enumerable: !0,
        get: n[o]
    });
    let a = e.r(555682),
        l = e.r(132061),
        i = a._(e.r(302023)),
        u = e.r(528279),
        d = new WeakSet;

    function c(e) {
        return d.has(e)
    }
    let s = e => {
        let t = (0, i.default)(e) && "cause" in e ? e.cause : e;
        (0, l.isBailoutToCSRError)(t) || (0, u.reportGlobalError)(t)
    };
    ("function" == typeof r.default || "object" == typeof r.default && null !== r.default) && void 0 === r.default.__esModule && (Object.defineProperty(r.default, "__esModule", {
        value: !0
    }), Object.assign(r.default, r), t.exports = r.default)
}, 5526, (e, t, r) => {
    "use strict";
    t.exports = {}
}, 966849, (e, t, r) => {
    "trimStart" in String.prototype || (String.prototype.trimStart = String.prototype.trimLeft), "trimEnd" in String.prototype || (String.prototype.trimEnd = String.prototype.trimRight), "description" in Symbol.prototype || Object.defineProperty(Symbol.prototype, "description", {
        configurable: !0,
        get: function() {
            var e = /\((.*)\)/.exec(this.toString());
            return e ? e[1] : void 0
        }
    }), Array.prototype.flat || (Array.prototype.flat = function(e, t) {
        return t = this.concat.apply([], this), e > 1 && t.some(Array.isArray) ? t.flat(e - 1) : t
    }, Array.prototype.flatMap = function(e, t) {
        return this.map(e, t).flat()
    }), Promise.prototype.finally || (Promise.prototype.finally = function(e) {
        if ("function" != typeof e) return this.then(e, e);
        var t = this.constructor || Promise;
        return this.then(function(r) {
            return t.resolve(e()).then(function() {
                return r
            })
        }, function(r) {
            return t.resolve(e()).then(function() {
                throw r
            })
        })
    }), Object.fromEntries || (Object.fromEntries = function(e) {
        return Array.from(e).reduce(function(e, t) {
            return e[t[0]] = t[1], e
        }, {})
    }), Array.prototype.at || (Array.prototype.at = function(e) {
        var t = Math.trunc(e) || 0;
        if (t < 0 && (t += this.length), !(t < 0 || t >= this.length)) return this[t]
    }), Object.hasOwn || (Object.hasOwn = function(e, t) {
        if (null == e) throw TypeError("Cannot convert undefined or null to object");
        return Object.prototype.hasOwnProperty.call(Object(e), t)
    }), "canParse" in URL || (URL.canParse = function(e, t) {
        try {
            return new URL(e, t), !0
        } catch (e) {
            return !1
        }
    })
}, 523911, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), e.r(966849), ("function" == typeof r.default || "object" == typeof r.default && null !== r.default) && void 0 === r.default.__esModule && (Object.defineProperty(r.default, "__esModule", {
        value: !0
    }), Object.assign(r.default, r), t.exports = r.default)
}, 851323, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    });
    var n = {
        onCaughtError: function() {
            return f
        },
        onUncaughtError: function() {
            return p
        }
    };
    for (var o in n) Object.defineProperty(r, o, {
        enumerable: !0,
        get: n[o]
    });
    let a = e.r(555682),
        l = e.r(265713),
        i = e.r(132061),
        u = e.r(528279),
        d = e.r(972383),
        c = a._(e.r(168027)),
        s = {
            decorateDevError: e => e,
            handleClientError: () => {},
            originConsoleError: console.error.bind(console)
        };

    function f(e, t) {
        let r, n = t.errorBoundary ? .constructor;
        if (r = r || n === d.ErrorBoundaryHandler && t.errorBoundary.props.errorComponent === c.default) return p(e);
        (0, i.isBailoutToCSRError)(e) || (0, l.isNextRouterError)(e) || s.originConsoleError(e)
    }

    function p(e) {
        (0, i.isBailoutToCSRError)(e) || (0, l.isNextRouterError)(e) || (0, u.reportGlobalError)(e)
    }("function" == typeof r.default || "object" == typeof r.default && null !== r.default) && void 0 === r.default.__esModule && (Object.defineProperty(r.default, "__esModule", {
        value: !0
    }), Object.assign(r.default, r), t.exports = r.default)
}, 762634, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), Object.defineProperty(r, "AppRouterAnnouncer", {
        enumerable: !0,
        get: function() {
            return l
        }
    });
    let n = e.r(271645),
        o = e.r(174080),
        a = "next-route-announcer";

    function l({
        tree: e
    }) {
        let [t, r] = (0, n.useState)(null);
        (0, n.useEffect)(() => (r(function() {
            let e = document.getElementsByName(a)[0];
            if (e ? .shadowRoot ? .childNodes[0]) return e.shadowRoot.childNodes[0]; {
                let e = document.createElement(a);
                e.style.cssText = "position:absolute";
                let t = document.createElement("div");
                return t.ariaLive = "assertive", t.id = "__next-route-announcer__", t.role = "alert", t.style.cssText = "position:absolute;border:0;height:1px;margin:-1px;padding:0;width:1px;clip:rect(0 0 0 0);overflow:hidden;white-space:nowrap;word-wrap:normal", e.attachShadow({
                    mode: "open"
                }).appendChild(t), document.body.appendChild(e), t
            }
        }()), () => {
            let e = document.getElementsByTagName(a)[0];
            e ? .isConnected && document.body.removeChild(e)
        }), []);
        let [i, u] = (0, n.useState)(""), d = (0, n.useRef)(void 0);
        return (0, n.useEffect)(() => {
            let e = "";
            if (document.title) e = document.title;
            else {
                let t = document.querySelector("h1");
                t && (e = t.innerText || t.textContent || "")
            }
            void 0 !== d.current && d.current !== e && u(e), d.current = e
        }, [e]), t ? (0, o.createPortal)(i, t) : null
    }("function" == typeof r.default || "object" == typeof r.default && null !== r.default) && void 0 === r.default.__esModule && (Object.defineProperty(r.default, "__esModule", {
        value: !0
    }), Object.assign(r.default, r), t.exports = r.default)
}, 425018, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), Object.defineProperty(r, "findHeadInCache", {
        enumerable: !0,
        get: function() {
            return a
        }
    });
    let n = e.r(813258),
        o = e.r(270725);

    function a(e, t) {
        return function e(t, r, a, l) {
            if (0 === Object.keys(r).length) return [t, a, l];
            let i = Object.keys(r).filter(e => "children" !== e);
            "children" in r && i.unshift("children");
            let u = t.slots;
            if (null !== u)
                for (let t of i) {
                    let [l, i] = r[t];
                    if (l === n.DEFAULT_SEGMENT_KEY) continue;
                    let d = u[t];
                    if (!d) continue;
                    let c = e(d, i, a + "/" + (0, o.createRouterCacheKey)(l), a + "/" + (0, o.createRouterCacheKey)(l, !0));
                    if (c) return c
                }
            return null
        }(e, t, "", "")
    }("function" == typeof r.default || "object" == typeof r.default && null !== r.default) && void 0 === r.default.__esModule && (Object.defineProperty(r.default, "__esModule", {
        value: !0
    }), Object.assign(r.default, r), t.exports = r.default)
}, 241624, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    });
    var n = {
        GracefulDegradeBoundary: function() {
            return i
        },
        default: function() {
            return u
        }
    };
    for (var o in n) Object.defineProperty(r, o, {
        enumerable: !0,
        get: n[o]
    });
    let a = e.r(843476),
        l = e.r(271645);
    class i extends l.Component {
        constructor(e) {
            super(e), this.state = {
                hasError: !1
            }, this.rootHtml = "", this.htmlAttributes = {}, this.htmlRef = (0, l.createRef)()
        }
        static getDerivedStateFromError(e) {
            return {
                hasError: !0
            }
        }
        componentDidMount() {
            let e = this.htmlRef.current;
            this.state.hasError && e && Object.entries(this.htmlAttributes).forEach(([t, r]) => {
                e.setAttribute(t, r)
            })
        }
        render() {
            let {
                hasError: e
            } = this.state;
            return ("u" > typeof window && !this.rootHtml && (this.rootHtml = document.documentElement.innerHTML, this.htmlAttributes = function(e) {
                let t = {};
                for (let r = 0; r < e.attributes.length; r++) {
                    let n = e.attributes[r];
                    t[n.name] = n.value
                }
                return t
            }(document.documentElement)), e) ? (0, a.jsx)("html", {
                ref: this.htmlRef,
                suppressHydrationWarning: !0,
                dangerouslySetInnerHTML: {
                    __html: this.rootHtml
                }
            }) : this.props.children
        }
    }
    let u = i;
    ("function" == typeof r.default || "object" == typeof r.default && null !== r.default) && void 0 === r.default.__esModule && (Object.defineProperty(r.default, "__esModule", {
        value: !0
    }), Object.assign(r.default, r), t.exports = r.default)
}, 794109, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), Object.defineProperty(r, "default", {
        enumerable: !0,
        get: function() {
            return d
        }
    });
    let n = e.r(555682),
        o = e.r(843476);
    e.r(271645);
    let a = n._(e.r(241624)),
        l = e.r(972383),
        i = e.r(82604),
        u = "u" > typeof window && (0, i.isBot)(window.navigator.userAgent);

    function d({
        children: e,
        errorComponent: t,
        errorStyles: r,
        errorScripts: n
    }) {
        return u ? (0, o.jsx)(a.default, {
            children: e
        }) : (0, o.jsx)(l.ErrorBoundary, {
            errorComponent: t,
            errorStyles: r,
            errorScripts: n,
            children: e
        })
    }("function" == typeof r.default || "object" == typeof r.default && null !== r.default) && void 0 === r.default.__esModule && (Object.defineProperty(r.default, "__esModule", {
        value: !0
    }), Object.assign(r.default, r), t.exports = r.default)
}, 875530, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), Object.defineProperty(r, "default", {
        enumerable: !0,
        get: function() {
            return N
        }
    });
    let n = e.r(555682),
        o = e.r(190809),
        a = e.r(843476),
        l = o._(e.r(271645)),
        i = e.r(8372),
        u = e.r(388540),
        d = e.r(451191),
        c = e.r(261994),
        s = e.r(941538),
        f = e.r(494272),
        p = e.r(762634),
        h = e.r(358442),
        _ = e.r(425018),
        y = e.r(201244),
        b = e.r(387250),
        m = e.r(652817),
        v = e.r(734727),
        E = e.r(178377),
        w = e.r(699781),
        g = e.r(124063),
        j = e.r(968391),
        P = e.r(91949),
        R = n._(e.r(794109)),
        S = n._(e.r(168027)),
        O = e.r(897367);
    e.r(543369);
    let x = {};

    function T({
        appRouterState: e
    }) {
        return (0, l.useInsertionEffect)(() => {
            let {
                tree: t,
                pushRef: r,
                canonicalUrl: n,
                renderedSearch: o
            } = e, a = { ...r.preserveCustomHistoryState ? window.history.state : {},
                __NA: !0,
                __PRIVATE_NEXTJS_INTERNALS_TREE: {
                    tree: t,
                    renderedSearch: o
                }
            };
            r.pendingPush && (0, d.createHrefFromUrl)(new URL(window.location.href)) !== n ? (r.pendingPush = !1, window.history.pushState(a, "", n)) : window.history.replaceState(a, "", n), (0, f.setLastCommittedTree)(t)
        }, [e]), (0, l.useEffect)(() => {
            (0, P.pingVisibleLinks)(e.nextUrl, e.tree)
        }, [e.nextUrl, e.tree]), null
    }

    function M(e) {
        null == e && (e = {});
        let t = window.history.state,
            r = t ? .__NA;
        r && (e.__NA = r);
        let n = t ? .__PRIVATE_NEXTJS_INTERNALS_TREE;
        return n && (e.__PRIVATE_NEXTJS_INTERNALS_TREE = n), e
    }

    function A({
        headCacheNode: e
    }) {
        let t = null !== e ? e.head : null,
            r = null !== e ? e.prefetchHead : null,
            n = null !== r ? r : t;
        return (0, l.useDeferredValue)(t, n)
    }

    function C({
        actionQueue: e,
        globalError: t,
        webSocket: r,
        staticIndicatorState: n
    }) {
        let o, d = (0, s.useActionQueue)(e),
            {
                canonicalUrl: f
            } = d,
            {
                searchParams: E,
                pathname: P
            } = (0, l.useMemo)(() => {
                let e = new URL(f, "u" < typeof window ? "http://n" : window.location.href);
                return {
                    searchParams: e.searchParams,
                    pathname: (0, m.hasBasePath)(e.pathname) ? (0, b.removeBasePath)(e.pathname) : e.pathname
                }
            }, [f]);
        (0, l.useEffect)(() => {
            let e = (0, v.extractSourcePageFromFlightRouterState)(d.tree);
            void 0 !== e ? window.next.__internal_src_page = e : delete window.next.__internal_src_page
        }, [d.tree]), (0, l.useEffect)(() => {
            function e(e) {
                e.persisted && window.history.state ? .__PRIVATE_NEXTJS_INTERNALS_TREE && (x.pendingMpaPath = void 0, (0, s.dispatchAppRouterAction)({
                    type: u.ACTION_RESTORE,
                    url: new URL(window.location.href),
                    historyState: window.history.state.__PRIVATE_NEXTJS_INTERNALS_TREE
                }))
            }
            return window.addEventListener("pageshow", e), () => {
                window.removeEventListener("pageshow", e)
            }
        }, []), (0, l.useEffect)(() => {
            function e(e) {
                let t = "reason" in e ? e.reason : e.error;
                if ((0, j.isRedirectError)(t)) {
                    e.preventDefault();
                    let r = (0, g.getURLFromRedirectError)(t);
                    "push" === (0, g.getRedirectTypeFromError)(t) ? w.publicAppRouterInstance.push(r, {}): w.publicAppRouterInstance.replace(r, {})
                }
            }
            return window.addEventListener("error", e), window.addEventListener("unhandledrejection", e), () => {
                window.removeEventListener("error", e), window.removeEventListener("unhandledrejection", e)
            }
        }, []);
        let {
            pushRef: S
        } = d;
        if (S.mpaNavigation) {
            if (x.pendingMpaPath !== f) {
                let e = window.location;
                S.pendingPush ? e.assign(f) : e.replace(f), x.pendingMpaPath = f
            }
            throw y.unresolvedThenable
        }(0, l.useEffect)(() => {
            let e = window.history.pushState.bind(window.history),
                t = window.history.replaceState.bind(window.history),
                r = e => {
                    let t = window.location.href,
                        r = window.history.state ? .__PRIVATE_NEXTJS_INTERNALS_TREE;
                    (0, l.startTransition)(() => {
                        (0, s.dispatchAppRouterAction)({
                            type: u.ACTION_RESTORE,
                            url: new URL(e ? ? t, t),
                            historyState: r
                        })
                    })
                };
            window.history.pushState = function(t, n, o) {
                return t ? .__NA || t ? ._N || (t = M(t), o && r(o)), e(t, n, o)
            }, window.history.replaceState = function(e, n, o) {
                return e ? .__NA || e ? ._N || (e = M(e), o && r(o)), t(e, n, o)
            };
            let n = e => {
                if (e.state) {
                    if (!e.state.__NA) return void window.location.reload();
                    (0, l.startTransition)(() => {
                        (0, w.dispatchTraverseAction)(window.location.href, e.state.__PRIVATE_NEXTJS_INTERNALS_TREE)
                    })
                }
            };
            return window.addEventListener("popstate", n), () => {
                window.history.pushState = e, window.history.replaceState = t, window.removeEventListener("popstate", n)
            }
        }, []);
        let {
            cache: N,
            tree: L,
            nextUrl: I,
            focusAndScrollRef: D,
            previousNextUrl: U
        } = d, F = (0, l.useMemo)(() => (0, _.findHeadInCache)(N, L[1]), [N, L]), B = (0, l.useMemo)(() => (0, v.getSelectedParams)(L), [L]), H = (0, l.useMemo)(() => ({
            parentTree: L,
            parentCacheNode: N,
            parentSegmentPath: null,
            parentParams: {},
            parentLoadingData: null,
            debugNameContext: "/",
            url: f,
            isActive: !0
        }), [L, N, f]), X = (0, l.useMemo)(() => ({
            tree: L,
            focusAndScrollRef: D,
            nextUrl: I,
            previousNextUrl: U
        }), [L, D, I, U]);
        if (null !== F) {
            let [e, t, r] = F;
            o = (0, a.jsx)(A, {
                headCacheNode: e
            }, "u" < typeof window ? r : t)
        } else o = null;
        let k = (0, a.jsxs)(h.RedirectBoundary, {
            children: [o, (0, a.jsx)(O.RootLayoutBoundary, {
                children: N.rsc
            }), (0, a.jsx)(p.AppRouterAnnouncer, {
                tree: L
            })]
        });
        return k = (0, a.jsx)(R.default, {
            errorComponent: t[0],
            errorStyles: t[1],
            children: k
        }), (0, a.jsxs)(a.Fragment, {
            children: [(0, a.jsx)(T, {
                appRouterState: d
            }), null, (0, a.jsx)(c.NavigationPromisesContext.Provider, {
                value: null,
                children: (0, a.jsx)(c.PathParamsContext.Provider, {
                    value: B,
                    children: (0, a.jsx)(c.PathnameContext.Provider, {
                        value: P,
                        children: (0, a.jsx)(c.SearchParamsContext.Provider, {
                            value: E,
                            children: (0, a.jsx)(i.GlobalLayoutRouterContext.Provider, {
                                value: X,
                                children: (0, a.jsx)(i.AppRouterContext.Provider, {
                                    value: w.publicAppRouterInstance,
                                    children: (0, a.jsx)(i.LayoutRouterContext.Provider, {
                                        value: H,
                                        children: k
                                    })
                                })
                            })
                        })
                    })
                })
            })]
        })
    }

    function N({
        actionQueue: e,
        globalErrorState: t,
        webSocket: r,
        staticIndicatorState: n
    }) {
        (0, E.useNavFailureHandler)();
        let o = (0, a.jsx)(C, {
            actionQueue: e,
            globalError: t,
            webSocket: r,
            staticIndicatorState: n
        });
        return (0, a.jsx)(R.default, {
            errorComponent: S.default,
            children: o
        })
    }("function" == typeof r.default || "object" == typeof r.default && null !== r.default) && void 0 === r.default.__esModule && (Object.defineProperty(r.default, "__esModule", {
        value: !0
    }), Object.assign(r.default, r), t.exports = r.default)
}, 665716, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), Object.defineProperty(r, "createInitialRouterState", {
        enumerable: !0,
        get: function() {
            return f
        }
    });
    let n = e.r(451191),
        o = e.r(734727),
        a = e.r(450590),
        l = e.r(595871),
        i = e.r(620896),
        u = e.r(509396),
        d = e.r(179027),
        c = e.r(787288),
        s = e.r(496167);

    function f({
        navigatedAt: e,
        initialRSCPayload: t,
        initialFlightStreamForCache: r,
        location: p
    }) {
        let {
            c: h,
            f: _,
            q: y,
            i: b,
            S: m,
            s: v,
            l: E,
            h: w,
            p: g,
            d: j
        } = t, P = h.join("/"), {
            tree: R,
            seedData: S,
            head: O
        } = (0, a.getFlightDataPartsFromPath)(_[0]), x = p ? (0, n.createHrefFromUrl)(p) : P, T = {
            metadataVaryPath: null
        }, M = (0, i.convertRootFlightRouterStateToRouteTree)(R, y, T), A = T.metadataVaryPath, C = (0, l.createInitialCacheNodeForHydration)(e, M, S, O, (0, d.computeDynamicStaleAt)(e, j ? ? d.UnknownDynamicStaleTime));
        if (null !== p && null !== A) {
            if ((0, s.discoverKnownRoute)(Date.now(), p.pathname, null, null, M, A, b, x, m, !1), null !== S && void 0 !== v)
                if (void 0 !== E && null != r)(0, c.decodeStaticStage)(r, E, void 0).then(async e => {
                    let t = Date.now(),
                        r = await (0, i.getStaleAt)(t, e.s);
                    (0, i.writeStaticStageResponseIntoCache)(t, e.f, void 0, e.h, r, R, y, !0)
                }).catch(() => {});
                else {
                    let e = Date.now();
                    (0, i.getStaleAt)(e, v).then(t => {
                        (0, i.writeStaticStageResponseIntoCache)(e, _, void 0, w, t, R, y, !1)
                    }).catch(() => {}), r ? .cancel()
                }
            else r ? .cancel();
            null != g && (0, i.processRuntimePrefetchStream)(Date.now(), g, R, y).then(e => {
                null !== e && (0, i.writeDynamicRenderResponseIntoCache)(Date.now(), u.FetchStrategy.PPRRuntime, e.flightDatas, e.buildId, e.isResponsePartial, e.headVaryParams, e.staleAt, e.navigationSeed, null)
            }).catch(() => {})
        }
        return {
            tree: C.route,
            cache: C.node,
            pushRef: {
                pendingPush: !1,
                mpaNavigation: !1,
                preserveCustomHistoryState: !0
            },
            focusAndScrollRef: {
                scrollRef: null,
                forceScroll: !1,
                onlyHashChange: !1,
                hashFragment: null
            },
            canonicalUrl: x,
            renderedSearch: y,
            nextUrl: ((0, o.extractPathFromFlightRouterState)(R) || p ? .pathname) ? ? null,
            previousNextUrl: null,
            debugInfo: null
        }
    }("function" == typeof r.default || "object" == typeof r.default && null !== r.default) && void 0 === r.default.__esModule && (Object.defineProperty(r.default, "__esModule", {
        value: !0
    }), Object.assign(r.default, r), t.exports = r.default)
}, 198569, (e, t, r) => {
    "use strict";
    let n, o, a, l;
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), Object.defineProperty(r, "hydrate", {
        enumerable: !0,
        get: function() {
            return B
        }
    });
    let i = e.r(555682),
        u = e.r(843476);
    e.r(523911);
    let d = i._(e.r(88014)),
        c = i._(e.r(271645)),
        s = e.r(235326),
        f = e.r(742732),
        p = e.r(597238),
        h = e.r(851323),
        _ = e.r(132120),
        y = e.r(92245),
        b = e.r(699781),
        m = i._(e.r(875530)),
        v = e.r(665716);
    e.r(8372);
    let E = e.r(450590),
        w = e.r(543369),
        g = e.r(732992),
        j = s.createFromReadableStream,
        P = s.createFromFetch,
        R = document,
        S = self.__next_instant_test ? self.__next_instant_test : void 0,
        O = new TextEncoder,
        x = !1,
        T = !1,
        M = null;

    function A(e) {
        if (0 === e[0]) a = [];
        else if (1 === e[0]) {
            if (!a) throw Object.defineProperty(Error("Unexpected server data: missing bootstrap script."), "__NEXT_ERROR_CODE", {
                value: "E18",
                enumerable: !1,
                configurable: !0
            });
            l ? l.enqueue(O.encode(e[1])) : a.push(e[1])
        } else if (2 === e[0]) M = e[1];
        else if (3 === e[0]) {
            if (!a) throw Object.defineProperty(Error("Unexpected server data: missing bootstrap script."), "__NEXT_ERROR_CODE", {
                value: "E18",
                enumerable: !1,
                configurable: !0
            });
            let r = atob(e[1]),
                n = new Uint8Array(r.length);
            for (var t = 0; t < r.length; t++) n[t] = r.charCodeAt(t);
            l ? l.enqueue(n) : a.push(n)
        }
    }
    let C = function() {
        l && !T && (l.close(), T = !0, a = void 0), x = !0
    };
    "loading" === document.readyState ? document.addEventListener("DOMContentLoaded", C, !1) : setTimeout(C);
    let N = self.__next_f = self.__next_f || [];
    N.forEach(A), N.length = 0, N.push = A;
    let L = new ReadableStream({
        start(e) {
            a && (a.forEach(t => {
                e.enqueue("string" == typeof t ? O.encode(t) : t)
            }), x && !T) && (null === e.desiredSize || e.desiredSize < 0 ? S || e.error(Object.defineProperty(Error("The connection to the page was unexpectedly closed, possibly due to the stop button being clicked, loss of Wi-Fi, or an unstable internet connection."), "__NEXT_ERROR_CODE", {
                value: "E117",
                enumerable: !1,
                configurable: !0
            })) : e.close(), T = !0, a = void 0), l = e
        }
    });
    if (S) o = Promise.resolve(P(S, {
        callServer: _.callServer,
        findSourceMapURL: y.findSourceMapURL,
        debugChannel: n,
        unstable_allowPartialStream: !0
    })).then(async e => (0, E.createInitialRSCPayloadFromFallbackPrerender)(await S, e));
    else if (window.__NEXT_CLIENT_RESUME) {
        let e = window.__NEXT_CLIENT_RESUME;
        o = Promise.resolve(P(e, {
            callServer: _.callServer,
            findSourceMapURL: y.findSourceMapURL,
            debugChannel: n
        })).then(async t => (0, E.createInitialRSCPayloadFromFallbackPrerender)(await e, t))
    } else o = j(L, {
        callServer: _.callServer,
        findSourceMapURL: y.findSourceMapURL,
        debugChannel: n,
        startTime: 0
    });

    function I({
        initialRSCPayload: e,
        actionQueue: t,
        webSocket: r,
        staticIndicatorState: n
    }) {
        return (0, u.jsx)(m.default, {
            actionQueue: t,
            globalErrorState: e.G,
            webSocket: r,
            staticIndicatorState: n
        })
    }
    let D = c.default.StrictMode;

    function U({
        children: e
    }) {
        return e
    }
    let F = {
        onDefaultTransitionIndicator: function() {
            return () => {}
        },
        onRecoverableError: p.onRecoverableError,
        onCaughtError: h.onCaughtError,
        onUncaughtError: h.onUncaughtError
    };
    async function B(e, t) {
        let r, n, a = await o;
        a.b ? (0, g.setNavigationBuildId)(a.b) : (0, g.setNavigationBuildId)((0, w.getDeploymentId)());
        let l = Date.now(),
            i = (0, b.createMutableActionQueue)((0, v.createInitialRouterState)({
                navigatedAt: l,
                initialRSCPayload: a,
                initialFlightStreamForCache: null,
                location: window.location
            }), e),
            s = (0, u.jsx)(D, {
                children: (0, u.jsx)(f.HeadManagerContext.Provider, {
                    value: {
                        appDir: !0
                    },
                    children: (0, u.jsx)(U, {
                        children: (0, u.jsx)(I, {
                            initialRSCPayload: a,
                            actionQueue: i,
                            webSocket: n,
                            staticIndicatorState: r
                        })
                    })
                })
            });
        "__next_error__" === document.documentElement.id ? d.default.createRoot(R, F).render(s) : c.default.startTransition(() => {
            d.default.hydrateRoot(R, s, { ...F,
                formState: M
            })
        })
    }("function" == typeof r.default || "object" == typeof r.default && null !== r.default) && void 0 === r.default.__esModule && (Object.defineProperty(r.default, "__esModule", {
        value: !0
    }), Object.assign(r.default, r), t.exports = r.default)
}, 494553, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), e.r(423755);
    let n = e.r(396517);
    e.r(597238), window.next.turbopack = !0, self.__webpack_hash__ = "";
    let o = e.r(5526);
    (0, n.appBootstrap)(t => {
        let {
            hydrate: r
        } = e.r(198569);
        r(o, t)
    }), ("function" == typeof r.default || "object" == typeof r.default && null !== r.default) && void 0 === r.default.__esModule && (Object.defineProperty(r.default, "__esModule", {
        value: !0
    }), Object.assign(r.default, r), t.exports = r.default)
}]);