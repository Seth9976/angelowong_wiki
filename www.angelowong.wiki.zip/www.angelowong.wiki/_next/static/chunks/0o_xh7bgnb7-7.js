(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push(["object" == typeof document ? document.currentScript : void 0, 934537, t => {
    "use strict";
    var e, i, n = /^((children|dangerouslySetInnerHTML|key|ref|autoFocus|defaultValue|defaultChecked|innerHTML|suppressContentEditableWarning|suppressHydrationWarning|valueLink|abbr|accept|acceptCharset|accessKey|action|allow|allowUserMedia|allowPaymentRequest|allowFullScreen|allowTransparency|alt|async|autoComplete|autoPlay|capture|cellPadding|cellSpacing|challenge|charSet|checked|cite|classID|className|cols|colSpan|content|contentEditable|contextMenu|controls|controlsList|coords|crossOrigin|data|dateTime|decoding|default|defer|dir|disabled|disablePictureInPicture|disableRemotePlayback|download|draggable|encType|enterKeyHint|fetchpriority|fetchPriority|form|formAction|formEncType|formMethod|formNoValidate|formTarget|frameBorder|headers|height|hidden|high|href|hrefLang|htmlFor|httpEquiv|id|inputMode|integrity|is|keyParams|keyType|kind|label|lang|list|loading|loop|low|marginHeight|marginWidth|max|maxLength|media|mediaGroup|method|min|minLength|multiple|muted|name|nonce|noValidate|open|optimum|pattern|placeholder|playsInline|popover|popoverTarget|popoverTargetAction|poster|preload|profile|radioGroup|readOnly|referrerPolicy|rel|required|reversed|role|rows|rowSpan|sandbox|scope|scoped|scrolling|seamless|selected|shape|size|sizes|slot|span|spellCheck|src|srcDoc|srcLang|srcSet|start|step|style|summary|tabIndex|target|title|translate|type|useMap|value|width|wmode|wrap|about|datatype|inlist|prefix|property|resource|typeof|vocab|autoCapitalize|autoCorrect|autoSave|color|incremental|fallback|inert|itemProp|itemScope|itemType|itemID|itemRef|on|option|results|security|unselectable|accentHeight|accumulate|additive|alignmentBaseline|allowReorder|alphabetic|amplitude|arabicForm|ascent|attributeName|attributeType|autoReverse|azimuth|baseFrequency|baselineShift|baseProfile|bbox|begin|bias|by|calcMode|capHeight|clip|clipPathUnits|clipPath|clipRule|colorInterpolation|colorInterpolationFilters|colorProfile|colorRendering|contentScriptType|contentStyleType|cursor|cx|cy|d|decelerate|descent|diffuseConstant|direction|display|divisor|dominantBaseline|dur|dx|dy|edgeMode|elevation|enableBackground|end|exponent|externalResourcesRequired|fill|fillOpacity|fillRule|filter|filterRes|filterUnits|floodColor|floodOpacity|focusable|fontFamily|fontSize|fontSizeAdjust|fontStretch|fontStyle|fontVariant|fontWeight|format|from|fr|fx|fy|g1|g2|glyphName|glyphOrientationHorizontal|glyphOrientationVertical|glyphRef|gradientTransform|gradientUnits|hanging|horizAdvX|horizOriginX|ideographic|imageRendering|in|in2|intercept|k|k1|k2|k3|k4|kernelMatrix|kernelUnitLength|kerning|keyPoints|keySplines|keyTimes|lengthAdjust|letterSpacing|lightingColor|limitingConeAngle|local|markerEnd|markerMid|markerStart|markerHeight|markerUnits|markerWidth|mask|maskContentUnits|maskUnits|mathematical|mode|numOctaves|offset|opacity|operator|order|orient|orientation|origin|overflow|overlinePosition|overlineThickness|panose1|paintOrder|pathLength|patternContentUnits|patternTransform|patternUnits|pointerEvents|points|pointsAtX|pointsAtY|pointsAtZ|preserveAlpha|preserveAspectRatio|primitiveUnits|r|radius|refX|refY|renderingIntent|repeatCount|repeatDur|requiredExtensions|requiredFeatures|restart|result|rotate|rx|ry|scale|seed|shapeRendering|slope|spacing|specularConstant|specularExponent|speed|spreadMethod|startOffset|stdDeviation|stemh|stemv|stitchTiles|stopColor|stopOpacity|strikethroughPosition|strikethroughThickness|string|stroke|strokeDasharray|strokeDashoffset|strokeLinecap|strokeLinejoin|strokeMiterlimit|strokeOpacity|strokeWidth|surfaceScale|systemLanguage|tableValues|targetX|targetY|textAnchor|textDecoration|textRendering|textLength|to|transform|u1|u2|underlinePosition|underlineThickness|unicode|unicodeBidi|unicodeRange|unitsPerEm|vAlphabetic|vHanging|vIdeographic|vMathematical|values|vectorEffect|version|vertAdvY|vertOriginX|vertOriginY|viewBox|viewTarget|visibility|widths|wordSpacing|writingMode|x|xHeight|x1|x2|xChannelSelector|xlinkActuate|xlinkArcrole|xlinkHref|xlinkRole|xlinkShow|xlinkTitle|xlinkType|xmlBase|xmlns|xmlnsXlink|xmlLang|xmlSpace|y|y1|y2|yChannelSelector|z|zoomAndPan|for|class|autofocus)|(([Dd][Aa][Tt][Aa]|[Aa][Rr][Ii][Aa]|x)-.*))$/,
        s = (e = function(t) {
            return n.test(t) || 111 === t.charCodeAt(0) && 110 === t.charCodeAt(1) && 91 > t.charCodeAt(2)
        }, i = Object.create(null), function(t) {
            return void 0 === i[t] && (i[t] = e(t)), i[t]
        });
    t.s(["default", 0, s], 934537)
}, 846932, 749652, 88653, t => {
    "use strict";
    let e, i, n, s, r = ["transformPerspective", "x", "y", "z", "translateX", "translateY", "translateZ", "scale", "scaleX", "scaleY", "rotate", "rotateX", "rotateY", "rotateZ", "skew", "skewX", "skewY"],
        o = new Set(r),
        a = (t, e, i) => i > e ? e : i < t ? t : i,
        l = {
            test: t => "number" == typeof t,
            parse: parseFloat,
            transform: t => t
        },
        h = { ...l,
            transform: t => a(0, 1, t)
        },
        u = { ...l,
            default: 1
        },
        d = t => Math.round(1e5 * t) / 1e5,
        c = /-?(?:\d+(?:\.\d+)?|\.\d+)/gu,
        p = /^(?:#[\da-f]{3,8}|(?:rgb|hsl)a?\((?:-?[\d.]+%?[,\s]+){2}-?[\d.]+%?\s*(?:[,/]\s*)?(?:\b\d+(?:\.\d+)?|\.\d+)?%?\))$/iu,
        m = (t, e) => i => !!("string" == typeof i && p.test(i) && i.startsWith(t) || e && null != i && Object.prototype.hasOwnProperty.call(i, e)),
        f = (t, e, i) => n => {
            if ("string" != typeof n) return n;
            let [s, r, o, a] = n.match(c);
            return {
                [t]: parseFloat(s),
                [e]: parseFloat(r),
                [i]: parseFloat(o),
                alpha: void 0 !== a ? parseFloat(a) : 1
            }
        },
        g = { ...l,
            transform: t => Math.round(a(0, 255, t))
        },
        y = {
            test: m("rgb", "red"),
            parse: f("red", "green", "blue"),
            transform: ({
                red: t,
                green: e,
                blue: i,
                alpha: n = 1
            }) => "rgba(" + g.transform(t) + ", " + g.transform(e) + ", " + g.transform(i) + ", " + d(h.transform(n)) + ")"
        },
        v = {
            test: m("#"),
            parse: function(t) {
                let e = "",
                    i = "",
                    n = "",
                    s = "";
                return t.length > 5 ? (e = t.substring(1, 3), i = t.substring(3, 5), n = t.substring(5, 7), s = t.substring(7, 9)) : (e = t.substring(1, 2), i = t.substring(2, 3), n = t.substring(3, 4), s = t.substring(4, 5), e += e, i += i, n += n, s += s), {
                    red: parseInt(e, 16),
                    green: parseInt(i, 16),
                    blue: parseInt(n, 16),
                    alpha: s ? parseInt(s, 16) / 255 : 1
                }
            },
            transform: y.transform
        },
        x = t => ({
            test: e => "string" == typeof e && e.endsWith(t) && 1 === e.split(" ").length,
            parse: parseFloat,
            transform: e => `${e}${t}`
        }),
        w = x("deg"),
        T = x("%"),
        b = x("px"),
        S = x("vh"),
        P = x("vw"),
        A = { ...T,
            parse: t => T.parse(t) / 100,
            transform: t => T.transform(100 * t)
        },
        E = {
            test: m("hsl", "hue"),
            parse: f("hue", "saturation", "lightness"),
            transform: ({
                hue: t,
                saturation: e,
                lightness: i,
                alpha: n = 1
            }) => "hsla(" + Math.round(t) + ", " + T.transform(d(e)) + ", " + T.transform(d(i)) + ", " + d(h.transform(n)) + ")"
        },
        M = {
            test: t => y.test(t) || v.test(t) || E.test(t),
            parse: t => y.test(t) ? y.parse(t) : E.test(t) ? E.parse(t) : v.parse(t),
            transform: t => "string" == typeof t ? t : t.hasOwnProperty("red") ? y.transform(t) : E.transform(t),
            getAnimatableNone: t => {
                let e = M.parse(t);
                return e.alpha = 0, M.transform(e)
            }
        },
        k = /(?:#[\da-f]{3,8}|(?:rgb|hsl)a?\((?:-?[\d.]+%?[,\s]+){2}-?[\d.]+%?\s*(?:[,/]\s*)?(?:\b\d+(?:\.\d+)?|\.\d+)?%?\))/giu,
        C = "number",
        V = "color",
        R = /var\s*\(\s*--(?:[\w-]+\s*|[\w-]+\s*,(?:\s*[^)(\s]|\s*\((?:[^)(]|\([^)(]*\))*\))+\s*)\)|#[\da-f]{3,8}|(?:rgb|hsl)a?\((?:-?[\d.]+%?[,\s]+){2}-?[\d.]+%?\s*(?:[,/]\s*)?(?:\b\d+(?:\.\d+)?|\.\d+)?%?\)|-?(?:\d+(?:\.\d+)?|\.\d+)/giu;

    function D(t) {
        let e = t.toString(),
            i = [],
            n = {
                color: [],
                number: [],
                var: []
            },
            s = [],
            r = 0,
            o = e.replace(R, t => (M.test(t) ? (n.color.push(r), s.push(V), i.push(M.parse(t))) : t.startsWith("var(") ? (n.var.push(r), s.push("var"), i.push(t)) : (n.number.push(r), s.push(C), i.push(parseFloat(t))), ++r, "${}")).split("${}");
        return {
            values: i,
            split: o,
            indexes: n,
            types: s
        }
    }

    function L({
        split: t,
        types: e
    }) {
        let i = t.length;
        return n => {
            let s = "";
            for (let r = 0; r < i; r++)
                if (s += t[r], void 0 !== n[r]) {
                    let t = e[r];
                    t === C ? s += d(n[r]) : t === V ? s += M.transform(n[r]) : s += n[r]
                }
            return s
        }
    }
    let B = {
            test: function(t) {
                return isNaN(t) && "string" == typeof t && (t.match(c) ? .length || 0) + (t.match(k) ? .length || 0) > 0
            },
            parse: function(t) {
                return D(t).values
            },
            createTransformer: function(t) {
                return L(D(t))
            },
            getAnimatableNone: function(t) {
                let e = D(t);
                return L(e)(e.values.map((t, i) => ((t, e) => "number" == typeof t ? e ? .trim().endsWith("/") ? t : 0 : "number" == typeof t ? 0 : M.test(t) ? M.getAnimatableNone(t) : t)(t, e.split[i])))
            }
        },
        j = new Set(["brightness", "contrast", "saturate", "opacity"]);

    function F(t) {
        let [e, i] = t.slice(0, -1).split("(");
        if ("drop-shadow" === e) return t;
        let [n] = i.match(c) || [];
        if (!n) return t;
        let s = i.replace(n, ""),
            r = +!!j.has(e);
        return n !== i && (r *= 100), e + "(" + r + s + ")"
    }
    let I = /\b([a-z-]*)\(.*?\)/gu,
        O = { ...B,
            getAnimatableNone: t => {
                let e = t.match(I);
                return e ? e.map(F).join(" ") : t
            }
        },
        U = { ...B,
            getAnimatableNone: t => {
                let e = B.parse(t);
                return B.createTransformer(t)(e.map(t => "number" == typeof t ? 0 : "object" == typeof t ? { ...t,
                    alpha: 1
                } : t))
            }
        },
        W = { ...l,
            transform: Math.round
        },
        $ = {
            borderWidth: b,
            borderTopWidth: b,
            borderRightWidth: b,
            borderBottomWidth: b,
            borderLeftWidth: b,
            borderRadius: b,
            borderTopLeftRadius: b,
            borderTopRightRadius: b,
            borderBottomRightRadius: b,
            borderBottomLeftRadius: b,
            width: b,
            maxWidth: b,
            height: b,
            maxHeight: b,
            top: b,
            right: b,
            bottom: b,
            left: b,
            inset: b,
            insetBlock: b,
            insetBlockStart: b,
            insetBlockEnd: b,
            insetInline: b,
            insetInlineStart: b,
            insetInlineEnd: b,
            padding: b,
            paddingTop: b,
            paddingRight: b,
            paddingBottom: b,
            paddingLeft: b,
            paddingBlock: b,
            paddingBlockStart: b,
            paddingBlockEnd: b,
            paddingInline: b,
            paddingInlineStart: b,
            paddingInlineEnd: b,
            margin: b,
            marginTop: b,
            marginRight: b,
            marginBottom: b,
            marginLeft: b,
            marginBlock: b,
            marginBlockStart: b,
            marginBlockEnd: b,
            marginInline: b,
            marginInlineStart: b,
            marginInlineEnd: b,
            fontSize: b,
            backgroundPositionX: b,
            backgroundPositionY: b,
            rotate: w,
            rotateX: w,
            rotateY: w,
            rotateZ: w,
            scale: u,
            scaleX: u,
            scaleY: u,
            scaleZ: u,
            skew: w,
            skewX: w,
            skewY: w,
            distance: b,
            translateX: b,
            translateY: b,
            translateZ: b,
            x: b,
            y: b,
            z: b,
            perspective: b,
            transformPerspective: b,
            opacity: h,
            originX: A,
            originY: A,
            originZ: b,
            zIndex: W,
            fillOpacity: h,
            strokeOpacity: h,
            numOctaves: W
        },
        N = { ...$,
            color: M,
            backgroundColor: M,
            outlineColor: M,
            fill: M,
            stroke: M,
            borderColor: M,
            borderTopColor: M,
            borderRightColor: M,
            borderBottomColor: M,
            borderLeftColor: M,
            filter: O,
            WebkitFilter: O,
            mask: U,
            WebkitMask: U
        },
        z = t => N[t],
        H = () => ({
            translate: 0,
            scale: 1,
            origin: 0,
            originPoint: 0
        }),
        Y = () => ({
            x: H(),
            y: H()
        }),
        X = () => ({
            min: 0,
            max: 0
        }),
        K = () => ({
            x: X(),
            y: X()
        }),
        q = t => !!(t && t.getVelocity),
        G = new Set(["width", "height", "top", "left", "right", "bottom", ...r]),
        Z = t => e => e.test(t),
        _ = [l, b, T, w, P, S, {
            test: t => "auto" === t,
            parse: t => t
        }],
        J = t => _.find(Z(t));
    var Q, tt = t.i(247167);
    let te = () => {},
        ti = () => {};
    tt.default;
    let tn = t => e => "string" == typeof e && e.startsWith(t),
        ts = tn("--"),
        tr = tn("var(--"),
        to = t => !!tr(t) && ta.test(t.split("/*")[0].trim()),
        ta = /var\(--(?:[\w-]+\s*|[\w-]+\s*,(?:\s*[^)(\s]|\s*\((?:[^)(]|\([^)(]*\))*\))+\s*)\)$/iu;

    function tl(t) {
        return "string" == typeof t && t.split("/*")[0].includes("var(--")
    }
    let th = /^var\(--(?:([\w-]+)|([\w-]+), ?([a-zA-Z\d ()%#.,-]+))\)/u,
        tu = t => 180 * t / Math.PI,
        td = t => tp(tu(Math.atan2(t[1], t[0]))),
        tc = {
            x: 4,
            y: 5,
            translateX: 4,
            translateY: 5,
            scaleX: 0,
            scaleY: 3,
            scale: t => (Math.abs(t[0]) + Math.abs(t[3])) / 2,
            rotate: td,
            rotateZ: td,
            skewX: t => tu(Math.atan(t[1])),
            skewY: t => tu(Math.atan(t[2])),
            skew: t => (Math.abs(t[1]) + Math.abs(t[2])) / 2
        },
        tp = t => ((t %= 360) < 0 && (t += 360), t),
        tm = t => Math.sqrt(t[0] * t[0] + t[1] * t[1]),
        tf = t => Math.sqrt(t[4] * t[4] + t[5] * t[5]),
        tg = {
            x: 12,
            y: 13,
            z: 14,
            translateX: 12,
            translateY: 13,
            translateZ: 14,
            scaleX: tm,
            scaleY: tf,
            scale: t => (tm(t) + tf(t)) / 2,
            rotateX: t => tp(tu(Math.atan2(t[6], t[5]))),
            rotateY: t => tp(tu(Math.atan2(-t[2], t[0]))),
            rotateZ: td,
            rotate: td,
            skewX: t => tu(Math.atan(t[4])),
            skewY: t => tu(Math.atan(t[1])),
            skew: t => (Math.abs(t[1]) + Math.abs(t[4])) / 2
        };

    function ty(t) {
        return +!!t.includes("scale")
    }

    function tv(t, e) {
        let i, n;
        if (!t || "none" === t) return ty(e);
        let s = t.match(/^matrix3d\(([-\d.e\s,]+)\)$/u);
        if (s) i = tg, n = s;
        else {
            let e = t.match(/^matrix\(([-\d.e\s,]+)\)$/u);
            i = tc, n = e
        }
        if (!n) return ty(e);
        let r = i[e],
            o = n[1].split(",").map(tx);
        return "function" == typeof r ? r(o) : o[r]
    }

    function tx(t) {
        return parseFloat(t.trim())
    }
    let tw = t => t === l || t === b,
        tT = new Set(["x", "y", "z"]),
        tb = r.filter(t => !tT.has(t)),
        tS = {
            width: ({
                x: t
            }, {
                paddingLeft: e = "0",
                paddingRight: i = "0",
                boxSizing: n
            }) => {
                let s = t.max - t.min;
                return "border-box" === n ? s : s - parseFloat(e) - parseFloat(i)
            },
            height: ({
                y: t
            }, {
                paddingTop: e = "0",
                paddingBottom: i = "0",
                boxSizing: n
            }) => {
                let s = t.max - t.min;
                return "border-box" === n ? s : s - parseFloat(e) - parseFloat(i)
            },
            top: (t, {
                top: e
            }) => parseFloat(e),
            left: (t, {
                left: e
            }) => parseFloat(e),
            bottom: ({
                y: t
            }, {
                top: e
            }) => parseFloat(e) + (t.max - t.min),
            right: ({
                x: t
            }, {
                left: e
            }) => parseFloat(e) + (t.max - t.min),
            x: (t, {
                transform: e
            }) => tv(e, "x"),
            y: (t, {
                transform: e
            }) => tv(e, "y")
        };
    tS.translateX = tS.x, tS.translateY = tS.y;
    let tP = t => t,
        tA = {},
        tE = ["setup", "read", "resolveKeyframes", "preUpdate", "update", "preRender", "render", "postRender"];

    function tM(t, e) {
        let i = !1,
            n = !0,
            s = {
                delta: 0,
                timestamp: 0,
                isProcessing: !1
            },
            r = () => i = !0,
            o = tE.reduce((t, i) => (t[i] = function(t, e) {
                let i = new Set,
                    n = new Set,
                    s = !1,
                    r = !1,
                    o = new WeakSet,
                    a = {
                        delta: 0,
                        timestamp: 0,
                        isProcessing: !1
                    },
                    l = 0;

                function h(e) {
                    o.has(e) && (u.schedule(e), t()), l++, e(a)
                }
                let u = {
                    schedule: (t, e = !1, r = !1) => {
                        let a = r && s ? i : n;
                        return e && o.add(t), a.add(t), t
                    },
                    cancel: t => {
                        n.delete(t), o.delete(t)
                    },
                    process: t => {
                        if (a = t, s) {
                            r = !0;
                            return
                        }
                        s = !0;
                        let o = i;
                        i = n, n = o, i.forEach(h), e, l = 0, i.clear(), s = !1, r && (r = !1, u.process(t))
                    }
                };
                return u
            }(r, e ? i : void 0), t), {}),
            {
                setup: a,
                read: l,
                resolveKeyframes: h,
                preUpdate: u,
                update: d,
                preRender: c,
                render: p,
                postRender: m
            } = o,
            f = () => {
                let r = tA.useManualTiming,
                    o = r ? s.timestamp : performance.now();
                i = !1, r || (s.delta = n ? 1e3 / 60 : Math.max(Math.min(o - s.timestamp, 40), 1)), s.timestamp = o, s.isProcessing = !0, a.process(s), l.process(s), h.process(s), u.process(s), d.process(s), c.process(s), p.process(s), m.process(s), s.isProcessing = !1, i && e && (n = !1, t(f))
            };
        return {
            schedule: tE.reduce((e, r) => {
                let a = o[r];
                return e[r] = (e, r = !1, o = !1) => (!i && (i = !0, n = !0, s.isProcessing || t(f)), a.schedule(e, r, o)), e
            }, {}),
            cancel: t => {
                for (let e = 0; e < tE.length; e++) o[tE[e]].cancel(t)
            },
            state: s,
            steps: o
        }
    }
    let {
        schedule: tk,
        cancel: tC,
        state: tV,
        steps: tR
    } = tM("u" > typeof requestAnimationFrame ? requestAnimationFrame : tP, !0), tD = new Set, tL = !1, tB = !1, tj = !1;

    function tF() {
        if (tB) {
            let t = Array.from(tD).filter(t => t.needsMeasurement),
                e = new Set(t.map(t => t.element)),
                i = new Map;
            e.forEach(t => {
                let e, n = (e = [], tb.forEach(i => {
                    let n = t.getValue(i);
                    void 0 !== n && (e.push([i, n.get()]), n.set(+!!i.startsWith("scale")))
                }), e);
                n.length && (i.set(t, n), t.render())
            }), t.forEach(t => t.measureInitialState()), e.forEach(t => {
                t.render();
                let e = i.get(t);
                e && e.forEach(([e, i]) => {
                    t.getValue(e) ? .set(i)
                })
            }), t.forEach(t => t.measureEndState()), t.forEach(t => {
                void 0 !== t.suspendedScrollY && window.scrollTo(0, t.suspendedScrollY)
            })
        }
        tB = !1, tL = !1, tD.forEach(t => t.complete(tj)), tD.clear()
    }

    function tI() {
        tD.forEach(t => {
            t.readKeyframes(), t.needsMeasurement && (tB = !0)
        })
    }
    class tO {
        constructor(t, e, i, n, s, r = !1) {
            this.state = "pending", this.isAsync = !1, this.needsMeasurement = !1, this.unresolvedKeyframes = [...t], this.onComplete = e, this.name = i, this.motionValue = n, this.element = s, this.isAsync = r
        }
        scheduleResolve() {
            this.state = "scheduled", this.isAsync ? (tD.add(this), tL || (tL = !0, tk.read(tI), tk.resolveKeyframes(tF))) : (this.readKeyframes(), this.complete())
        }
        readKeyframes() {
            let {
                unresolvedKeyframes: t,
                name: e,
                element: i,
                motionValue: n
            } = this;
            if (null === t[0]) {
                let s = n ? .get(),
                    r = t[t.length - 1];
                if (void 0 !== s) t[0] = s;
                else if (i && e) {
                    let n = i.readValue(e, r);
                    null != n && (t[0] = n)
                }
                void 0 === t[0] && (t[0] = r), n && void 0 === s && n.set(t[0])
            }
            for (let e = 1; e < t.length; e++) t[e] ? ? (t[e] = t[e - 1])
        }
        setFinalKeyframe() {}
        measureInitialState() {}
        renderEndStyles() {}
        measureEndState() {}
        complete(t = !1) {
            this.state = "complete", this.onComplete(this.unresolvedKeyframes, this.finalKeyframe, t), tD.delete(this)
        }
        cancel() {
            "scheduled" === this.state && (tD.delete(this), this.state = "pending")
        }
        resume() {
            "pending" === this.state && this.scheduleResolve()
        }
    }
    let tU = new Set([O, U]);

    function tW(t, e) {
        let i = z(t);
        return tU.has(i) || (i = B), i.getAnimatableNone ? i.getAnimatableNone(e) : void 0
    }
    let t$ = new Set(["auto", "none", "0"]);
    class tN extends tO {
        constructor(t, e, i, n, s) {
            super(t, e, i, n, s, !0)
        }
        readKeyframes() {
            let {
                unresolvedKeyframes: t,
                element: e,
                name: i
            } = this;
            if (!e || !e.current) return;
            super.readKeyframes();
            for (let i = 0; i < t.length; i++) {
                let n = t[i];
                if ("string" == typeof n && to(n = n.trim())) {
                    let s = function t(e, i, n = 1) {
                        ti(n <= 4, `Max CSS variable fallback depth detected in property "${e}". This may indicate a circular fallback dependency.`, "max-css-var-depth");
                        let [s, r] = function(t) {
                            let e = th.exec(t);
                            if (!e) return [, ];
                            let [, i, n, s] = e;
                            return [`--${i??n}`, s]
                        }(e);
                        if (!s) return;
                        let o = window.getComputedStyle(i).getPropertyValue(s);
                        if (o) {
                            let t = o.trim();
                            return /^-?(?:\d+(?:\.\d+)?|\.\d+)$/u.test(t) ? parseFloat(t) : t
                        }
                        return to(r) ? t(r, i, n + 1) : r
                    }(n, e.current);
                    void 0 !== s && (t[i] = s), i === t.length - 1 && (this.finalKeyframe = n)
                }
            }
            if (this.resolveNoneKeyframes(), !G.has(i) || 2 !== t.length) return;
            let [n, s] = t, r = J(n), o = J(s);
            if (tl(n) !== tl(s) && tS[i]) {
                this.needsMeasurement = !0;
                return
            }
            if (r !== o)
                if (tw(r) && tw(o))
                    for (let e = 0; e < t.length; e++) {
                        let i = t[e];
                        "string" == typeof i && (t[e] = parseFloat(i))
                    } else tS[i] && (this.needsMeasurement = !0)
        }
        resolveNoneKeyframes() {
            let {
                unresolvedKeyframes: t,
                name: e
            } = this, i = [];
            for (let e = 0; e < t.length; e++)(null === t[e] || function(t) {
                if ("number" == typeof t) return 0 === t;
                if (null === t) return !0;
                return "none" === t || "0" === t || /^0[^.\s]+$/u.test(t)
            }(t[e])) && i.push(e);
            i.length && function(t, e, i) {
                let n, s = 0;
                for (; s < t.length && !n;) {
                    let e = t[s];
                    "string" == typeof e && !t$.has(e) && D(e).values.length && (n = t[s]), s++
                }
                if (n && i)
                    for (let s of e) t[s] = tW(i, n)
            }(t, i, e)
        }
        measureInitialState() {
            let {
                element: t,
                unresolvedKeyframes: e,
                name: i
            } = this;
            if (!t || !t.current) return;
            "height" === i && (this.suspendedScrollY = window.pageYOffset), this.measuredOrigin = tS[i](t.measureViewportBox(), window.getComputedStyle(t.current)), e[0] = this.measuredOrigin;
            let n = e[e.length - 1];
            void 0 !== n && t.getValue(i, n).jump(n, !1)
        }
        measureEndState() {
            let {
                element: t,
                name: e,
                unresolvedKeyframes: i
            } = this;
            if (!t || !t.current) return;
            let n = t.getValue(e);
            n && n.jump(this.measuredOrigin, !1);
            let s = i.length - 1,
                r = i[s];
            i[s] = tS[e](t.measureViewportBox(), window.getComputedStyle(t.current)), null !== r && void 0 === this.finalKeyframe && (this.finalKeyframe = r), this.removedTransforms ? .length && this.removedTransforms.forEach(([e, i]) => {
                t.getValue(e).set(i)
            }), this.resolveNoneKeyframes()
        }
    }
    let tz = t => 1e3 * t;

    function tH(t, e) {
        -1 === t.indexOf(e) && t.push(e)
    }

    function tY(t, e) {
        let i = t.indexOf(e);
        i > -1 && t.splice(i, 1)
    }
    class tX {
        constructor() {
            this.subscriptions = []
        }
        add(t) {
            return tH(this.subscriptions, t), () => tY(this.subscriptions, t)
        }
        notify(t, e, i) {
            let n = this.subscriptions.length;
            if (n)
                if (1 === n) this.subscriptions[0](t, e, i);
                else
                    for (let s = 0; s < n; s++) {
                        let n = this.subscriptions[s];
                        n && n(t, e, i)
                    }
        }
        getSize() {
            return this.subscriptions.length
        }
        clear() {
            this.subscriptions.length = 0
        }
    }

    function tK(t, e, i) {
        e.startsWith("--") ? t.style.setProperty(e, i) : t.style[e] = i
    }

    function tq(t) {
        let e;
        return () => (void 0 === e && (e = t()), e)
    }
    let tG = {};

    function tZ(t, e) {
        let i = tq(t);
        return () => tG[e] ? ? i()
    }
    let t_ = tZ(() => void 0 !== window.ScrollTimeline, "scrollTimeline"),
        tJ = t => null !== t;

    function tQ(t, {
        repeat: e,
        repeatType: i = "loop"
    }, n, s = 1) {
        let r = t.filter(tJ),
            o = s < 0 || e && "loop" !== i && e % 2 == 1 ? 0 : r.length - 1;
        return o && void 0 !== n ? n : r[o]
    }
    class t0 {
        constructor() {
            this.updateFinished()
        }
        get finished() {
            return this._finished
        }
        updateFinished() {
            this._finished = new Promise(t => {
                this.resolve = t
            })
        }
        notifyFinished() {
            this.resolve()
        }
        then(t, e) {
            return this.finished.then(t, e)
        }
    }
    let t1 = {
            layout: 0,
            mainThread: 0,
            waapi: 0
        },
        t2 = t => Array.isArray(t) && "number" == typeof t[0],
        t3 = tZ(() => {
            try {
                document.createElement("div").animate({
                    opacity: 0
                }, {
                    easing: "linear(0, 1)"
                })
            } catch (t) {
                return !1
            }
            return !0
        }, "linearEasing"),
        t5 = (t, e, i = 10) => {
            let n = "",
                s = Math.max(Math.round(e / i), 2);
            for (let e = 0; e < s; e++) n += Math.round(1e4 * t(e / (s - 1))) / 1e4 + ", ";
            return `linear(${n.substring(0,n.length-2)})`
        },
        t9 = ([t, e, i, n]) => `cubic-bezier(${t}, ${e}, ${i}, ${n})`,
        t4 = {
            linear: "linear",
            ease: "ease",
            easeIn: "ease-in",
            easeOut: "ease-out",
            easeInOut: "ease-in-out",
            circIn: t9([0, .65, .55, 1]),
            circOut: t9([.55, 0, 1, .45]),
            backIn: t9([.31, .01, .66, -.59]),
            backOut: t9([.33, 1.53, .69, .99])
        };

    function t6(t) {
        return "function" == typeof t && "applyToOptions" in t
    }
    class t8 extends t0 {
        constructor(t) {
            if (super(), this.finishedTime = null, this.isStopped = !1, this.manualStartTime = null, !t) return;
            const {
                element: e,
                name: i,
                keyframes: n,
                pseudoElement: s,
                allowFlatten: r = !1,
                finalKeyframe: o,
                onComplete: a
            } = t;
            this.isPseudoElement = !!s, this.allowFlatten = r, this.options = t, ti("string" != typeof t.type, 'Mini animate() doesn\'t support "type" as a string.', "mini-spring");
            const l = function({
                type: t,
                ...e
            }) {
                return t6(t) && t3() ? t.applyToOptions(e) : (e.duration ? ? (e.duration = 300), e.ease ? ? (e.ease = "easeOut"), e)
            }(t);
            this.animation = function(t, e, i, {
                delay: n = 0,
                duration: s = 300,
                repeat: r = 0,
                repeatType: o = "loop",
                ease: a = "easeOut",
                times: l
            } = {}, h) {
                let u = {
                    [e]: i
                };
                l && (u.offset = l);
                let d = function t(e, i) {
                    if (e) return "function" == typeof e ? t3() ? t5(e, i) : "ease-out" : t2(e) ? t9(e) : Array.isArray(e) ? e.map(e => t(e, i) || t4.easeOut) : t4[e]
                }(a, s);
                Array.isArray(d) && (u.easing = d);
                let c = {
                    delay: n,
                    duration: s,
                    easing: Array.isArray(d) ? "linear" : d,
                    fill: "both",
                    iterations: r + 1,
                    direction: "reverse" === o ? "alternate" : "normal"
                };
                h && (c.pseudoElement = h);
                let p = t.animate(u, c);
                return p
            }(e, i, n, l, s), !1 === l.autoplay && this.animation.pause(), this.animation.onfinish = () => {
                if (this.finishedTime = this.time, !s) {
                    let t = tQ(n, this.options, o, this.speed);
                    this.updateMotionValue && this.updateMotionValue(t), tK(e, i, t), this.animation.cancel()
                }
                a ? .(), this.notifyFinished()
            }
        }
        play() {
            this.isStopped || (this.manualStartTime = null, this.animation.play(), "finished" === this.state && this.updateFinished())
        }
        pause() {
            this.animation.pause()
        }
        complete() {
            this.animation.finish ? .()
        }
        cancel() {
            try {
                this.animation.cancel()
            } catch (t) {}
        }
        stop() {
            if (this.isStopped) return;
            this.isStopped = !0;
            let {
                state: t
            } = this;
            "idle" !== t && "finished" !== t && (this.updateMotionValue ? this.updateMotionValue() : this.commitStyles(), this.isPseudoElement || this.cancel())
        }
        commitStyles() {
            let t = this.options ? .element;
            !this.isPseudoElement && t ? .isConnected && this.animation.commitStyles ? .()
        }
        get duration() {
            return Number(this.animation.effect ? .getComputedTiming ? .().duration || 0) / 1e3
        }
        get iterationDuration() {
            let {
                delay: t = 0
            } = this.options || {};
            return this.duration + t / 1e3
        }
        get time() {
            return (Number(this.animation.currentTime) || 0) / 1e3
        }
        set time(t) {
            let e = null !== this.finishedTime;
            this.manualStartTime = null, this.finishedTime = null, this.animation.currentTime = tz(t), e && this.animation.pause()
        }
        get speed() {
            return this.animation.playbackRate
        }
        set speed(t) {
            t < 0 && (this.finishedTime = null), this.animation.playbackRate = t
        }
        get state() {
            return null !== this.finishedTime ? "finished" : this.animation.playState
        }
        get startTime() {
            return this.manualStartTime ? ? Number(this.animation.startTime)
        }
        set startTime(t) {
            this.manualStartTime = this.animation.startTime = t
        }
        attachTimeline({
            timeline: t,
            rangeStart: e,
            rangeEnd: i,
            observe: n
        }) {
            return (this.allowFlatten && this.animation.effect ? .updateTiming({
                easing: "linear"
            }), this.animation.onfinish = null, t && t_()) ? (this.animation.timeline = t, e && (this.animation.rangeStart = e), i && (this.animation.rangeEnd = i), tP) : n(this)
        }
    }
    let t7 = new Set(["opacity", "clipPath", "filter", "transform"]),
        {
            schedule: et
        } = tM(queueMicrotask, !1);

    function ee() {
        i = void 0
    }
    let ei = {
        now: () => (void 0 === i && ei.set(tV.isProcessing || tA.useManualTiming ? tV.timestamp : performance.now()), i),
        set: t => {
            i = t, queueMicrotask(ee)
        }
    };
    class en {
        constructor(t, e = {}) {
            this.canTrackVelocity = null, this.events = {}, this.updateAndNotify = t => {
                let e = ei.now();
                if (this.updatedAt !== e && this.setPrevFrameValue(), this.prev = this.current, this.setCurrent(t), this.current !== this.prev && (this.events.change ? .notify(this.current), this.dependents))
                    for (let t of this.dependents) t.dirty()
            }, this.hasAnimated = !1, this.setCurrent(t), this.owner = e.owner
        }
        setCurrent(t) {
            this.current = t, this.updatedAt = ei.now(), null === this.canTrackVelocity && void 0 !== t && (this.canTrackVelocity = !isNaN(parseFloat(this.current)))
        }
        setPrevFrameValue(t = this.current) {
            this.prevFrameValue = t, this.prevUpdatedAt = this.updatedAt
        }
        onChange(t) {
            return this.on("change", t)
        }
        on(t, e) {
            this.events[t] || (this.events[t] = new tX);
            let i = this.events[t].add(e);
            return "change" === t ? () => {
                i(), tk.read(() => {
                    this.events.change.getSize() || this.stop()
                })
            } : i
        }
        clearListeners() {
            for (let t in this.events) this.events[t].clear()
        }
        attach(t, e) {
            this.passiveEffect = t, this.stopPassiveEffect = e
        }
        set(t) {
            this.passiveEffect ? this.passiveEffect(t, this.updateAndNotify) : this.updateAndNotify(t)
        }
        setWithVelocity(t, e, i) {
            this.set(e), this.prev = void 0, this.prevFrameValue = t, this.prevUpdatedAt = this.updatedAt - i
        }
        jump(t, e = !0) {
            this.updateAndNotify(t), this.prev = t, this.prevUpdatedAt = this.prevFrameValue = void 0, e && this.stop(), this.stopPassiveEffect && this.stopPassiveEffect()
        }
        dirty() {
            this.events.change ? .notify(this.current)
        }
        addDependent(t) {
            this.dependents || (this.dependents = new Set), this.dependents.add(t)
        }
        removeDependent(t) {
            this.dependents && this.dependents.delete(t)
        }
        get() {
            return e && e.push(this), this.current
        }
        getPrevious() {
            return this.prev
        }
        getVelocity() {
            var t;
            let e = ei.now();
            if (!this.canTrackVelocity || void 0 === this.prevFrameValue || e - this.updatedAt > 30) return 0;
            let i = Math.min(this.updatedAt - this.prevUpdatedAt, 30);
            return t = parseFloat(this.current) - parseFloat(this.prevFrameValue), i ? 1e3 / i * t : 0
        }
        start(t) {
            return this.stop(), new Promise(e => {
                this.hasAnimated = !0, this.animation = t(e), this.events.animationStart && this.events.animationStart.notify()
            }).then(() => {
                this.events.animationComplete && this.events.animationComplete.notify(), this.clearAnimation()
            })
        }
        stop() {
            this.animation && (this.animation.stop(), this.events.animationCancel && this.events.animationCancel.notify()), this.clearAnimation()
        }
        isAnimating() {
            return !!this.animation
        }
        clearAnimation() {
            delete this.animation
        }
        destroy() {
            this.dependents ? .clear(), this.events.destroy ? .notify(), this.clearListeners(), this.stop(), this.stopPassiveEffect && this.stopPassiveEffect()
        }
    }

    function es(t, e) {
        return new en(t, e)
    }
    let er = [..._, M, B],
        eo = new WeakMap;

    function ea(t) {
        return null !== t && "object" == typeof t && "function" == typeof t.start
    }

    function el(t) {
        return "string" == typeof t || Array.isArray(t)
    }
    let eh = ["animate", "whileInView", "whileFocus", "whileHover", "whileTap", "whileDrag", "exit"],
        eu = ["initial", ...eh];

    function ed(t) {
        return ea(t.animate) || eu.some(e => el(t[e]))
    }

    function ec(t) {
        return !!(ed(t) || t.variants)
    }
    let ep = {
            current: null
        },
        em = {
            current: !1
        },
        ef = "u" > typeof window;

    function eg(t) {
        let e = [{}, {}];
        return t ? .values.forEach((t, i) => {
            e[0][i] = t.get(), e[1][i] = t.getVelocity()
        }), e
    }

    function ey(t, e, i, n) {
        if ("function" == typeof e) {
            let [s, r] = eg(n);
            e = e(void 0 !== i ? i : t.custom, s, r)
        }
        if ("string" == typeof e && (e = t.variants && t.variants[e]), "function" == typeof e) {
            let [s, r] = eg(n);
            e = e(void 0 !== i ? i : t.custom, s, r)
        }
        return e
    }
    let ev = ["AnimationStart", "AnimationComplete", "Update", "BeforeLayoutMeasure", "LayoutMeasure", "LayoutAnimationStart", "LayoutAnimationComplete"],
        ex = {};
    class ew {
        scrapeMotionValuesFromProps(t, e, i) {
            return {}
        }
        constructor({
            parent: t,
            props: e,
            presenceContext: i,
            reducedMotionConfig: n,
            skipAnimations: s,
            blockInitialAnimation: r,
            visualState: o
        }, a = {}) {
            this.current = null, this.children = new Set, this.isVariantNode = !1, this.isControllingVariants = !1, this.shouldReduceMotion = null, this.shouldSkipAnimations = !1, this.values = new Map, this.KeyframeResolver = tO, this.features = {}, this.valueSubscriptions = new Map, this.prevMotionValues = {}, this.hasBeenMounted = !1, this.events = {}, this.propEventSubscriptions = {}, this.notifyUpdate = () => this.notify("Update", this.latestValues), this.render = () => {
                this.current && (this.triggerBuild(), this.renderInstance(this.current, this.renderState, this.props.style, this.projection))
            }, this.renderScheduledAt = 0, this.scheduleRender = () => {
                let t = ei.now();
                this.renderScheduledAt < t && (this.renderScheduledAt = t, tk.render(this.render, !1, !0))
            };
            const {
                latestValues: l,
                renderState: h
            } = o;
            this.latestValues = l, this.baseTarget = { ...l
            }, this.initialValues = e.initial ? { ...l
            } : {}, this.renderState = h, this.parent = t, this.props = e, this.presenceContext = i, this.depth = t ? t.depth + 1 : 0, this.reducedMotionConfig = n, this.skipAnimationsConfig = s, this.options = a, this.blockInitialAnimation = !!r, this.isControllingVariants = ed(e), this.isVariantNode = ec(e), this.isVariantNode && (this.variantChildren = new Set), this.manuallyAnimateOnMount = !!(t && t.current);
            const {
                willChange: u,
                ...d
            } = this.scrapeMotionValuesFromProps(e, {}, this);
            for (const t in d) {
                const e = d[t];
                void 0 !== l[t] && q(e) && e.set(l[t])
            }
        }
        mount(t) {
            if (this.hasBeenMounted)
                for (let t in this.initialValues) this.values.get(t) ? .jump(this.initialValues[t]), this.latestValues[t] = this.initialValues[t];
            this.current = t, eo.set(t, this), this.projection && !this.projection.instance && this.projection.mount(t), this.parent && this.isVariantNode && !this.isControllingVariants && (this.removeFromVariantTree = this.parent.addVariantChild(this)), this.values.forEach((t, e) => this.bindToMotionValue(e, t)), "never" === this.reducedMotionConfig ? this.shouldReduceMotion = !1 : "always" === this.reducedMotionConfig ? this.shouldReduceMotion = !0 : (em.current || function() {
                if (em.current = !0, ef)
                    if (window.matchMedia) {
                        let t = window.matchMedia("(prefers-reduced-motion)"),
                            e = () => ep.current = t.matches;
                        t.addEventListener("change", e), e()
                    } else ep.current = !1
            }(), this.shouldReduceMotion = ep.current), this.shouldSkipAnimations = this.skipAnimationsConfig ? ? !1, this.parent ? .addChild(this), this.update(this.props, this.presenceContext), this.hasBeenMounted = !0
        }
        unmount() {
            for (let t in this.projection && this.projection.unmount(), tC(this.notifyUpdate), tC(this.render), this.valueSubscriptions.forEach(t => t()), this.valueSubscriptions.clear(), this.removeFromVariantTree && this.removeFromVariantTree(), this.parent ? .removeChild(this), this.events) this.events[t].clear();
            for (let t in this.features) {
                let e = this.features[t];
                e && (e.unmount(), e.isMounted = !1)
            }
            this.current = null
        }
        addChild(t) {
            this.children.add(t), this.enteringChildren ? ? (this.enteringChildren = new Set), this.enteringChildren.add(t)
        }
        removeChild(t) {
            this.children.delete(t), this.enteringChildren && this.enteringChildren.delete(t)
        }
        bindToMotionValue(t, e) {
            let i;
            if (this.valueSubscriptions.has(t) && this.valueSubscriptions.get(t)(), e.accelerate && t7.has(t) && this.current instanceof HTMLElement) {
                let {
                    factory: i,
                    keyframes: n,
                    times: s,
                    ease: r,
                    duration: o
                } = e.accelerate, a = new t8({
                    element: this.current,
                    name: t,
                    keyframes: n,
                    times: s,
                    ease: r,
                    duration: tz(o)
                }), l = i(a);
                this.valueSubscriptions.set(t, () => {
                    l(), a.cancel()
                });
                return
            }
            let n = o.has(t);
            n && this.onBindTransform && this.onBindTransform();
            let s = e.on("change", e => {
                this.latestValues[t] = e, this.props.onUpdate && tk.preRender(this.notifyUpdate), n && this.projection && (this.projection.isTransformDirty = !0), this.scheduleRender()
            });
            "u" > typeof window && window.MotionCheckAppearSync && (i = window.MotionCheckAppearSync(this, t, e)), this.valueSubscriptions.set(t, () => {
                s(), i && i(), e.owner && e.stop()
            })
        }
        sortNodePosition(t) {
            return this.current && this.sortInstanceNodePosition && this.type === t.type ? this.sortInstanceNodePosition(this.current, t.current) : 0
        }
        updateFeatures() {
            let t = "animation";
            for (t in ex) {
                let e = ex[t];
                if (!e) continue;
                let {
                    isEnabled: i,
                    Feature: n
                } = e;
                if (!this.features[t] && n && i(this.props) && (this.features[t] = new n(this)), this.features[t]) {
                    let e = this.features[t];
                    e.isMounted ? e.update() : (e.mount(), e.isMounted = !0)
                }
            }
        }
        triggerBuild() {
            this.build(this.renderState, this.latestValues, this.props)
        }
        measureViewportBox() {
            return this.current ? this.measureInstanceViewportBox(this.current, this.props) : K()
        }
        getStaticValue(t) {
            return this.latestValues[t]
        }
        setStaticValue(t, e) {
            this.latestValues[t] = e
        }
        update(t, e) {
            (t.transformTemplate || this.props.transformTemplate) && this.scheduleRender(), this.prevProps = this.props, this.props = t, this.prevPresenceContext = this.presenceContext, this.presenceContext = e;
            for (let e = 0; e < ev.length; e++) {
                let i = ev[e];
                this.propEventSubscriptions[i] && (this.propEventSubscriptions[i](), delete this.propEventSubscriptions[i]);
                let n = t["on" + i];
                n && (this.propEventSubscriptions[i] = this.on(i, n))
            }
            this.prevMotionValues = function(t, e, i) {
                for (let n in e) {
                    let s = e[n],
                        r = i[n];
                    if (q(s)) t.addValue(n, s);
                    else if (q(r)) t.addValue(n, es(s, {
                        owner: t
                    }));
                    else if (r !== s)
                        if (t.hasValue(n)) {
                            let e = t.getValue(n);
                            !0 === e.liveStyle ? e.jump(s) : e.hasAnimated || e.set(s)
                        } else {
                            let e = t.getStaticValue(n);
                            t.addValue(n, es(void 0 !== e ? e : s, {
                                owner: t
                            }))
                        }
                }
                for (let n in i) void 0 === e[n] && t.removeValue(n);
                return e
            }(this, this.scrapeMotionValuesFromProps(t, this.prevProps || {}, this), this.prevMotionValues), this.handleChildMotionValue && this.handleChildMotionValue()
        }
        getProps() {
            return this.props
        }
        getVariant(t) {
            return this.props.variants ? this.props.variants[t] : void 0
        }
        getDefaultTransition() {
            return this.props.transition
        }
        getTransformPagePoint() {
            return this.props.transformPagePoint
        }
        getClosestVariantNode() {
            return this.isVariantNode ? this : this.parent ? this.parent.getClosestVariantNode() : void 0
        }
        addVariantChild(t) {
            let e = this.getClosestVariantNode();
            if (e) return e.variantChildren && e.variantChildren.add(t), () => e.variantChildren.delete(t)
        }
        addValue(t, e) {
            let i = this.values.get(t);
            e !== i && (i && this.removeValue(t), this.bindToMotionValue(t, e), this.values.set(t, e), this.latestValues[t] = e.get())
        }
        removeValue(t) {
            this.values.delete(t);
            let e = this.valueSubscriptions.get(t);
            e && (e(), this.valueSubscriptions.delete(t)), delete this.latestValues[t], this.removeValueFromRenderState(t, this.renderState)
        }
        hasValue(t) {
            return this.values.has(t)
        }
        getValue(t, e) {
            if (this.props.values && this.props.values[t]) return this.props.values[t];
            let i = this.values.get(t);
            return void 0 === i && void 0 !== e && (i = es(null === e ? void 0 : e, {
                owner: this
            }), this.addValue(t, i)), i
        }
        readValue(t, e) {
            let i = void 0 === this.latestValues[t] && this.current ? this.getBaseTargetFromProps(this.props, t) ? ? this.readValueFromInstance(this.current, t, this.options) : this.latestValues[t];
            if (null != i) {
                let n, s;
                if ("string" == typeof i && (n = i, /^-?(?:\d+(?:\.\d+)?|\.\d+)$/u.test(n) || (s = i, /^0[^.\s]+$/u.test(s)))) i = parseFloat(i);
                else {
                    let n;
                    n = i, !er.find(Z(n)) && B.test(e) && (i = tW(t, e))
                }
                this.setBaseTarget(t, q(i) ? i.get() : i)
            }
            return q(i) ? i.get() : i
        }
        setBaseTarget(t, e) {
            this.baseTarget[t] = e
        }
        getBaseTarget(t) {
            let e, {
                initial: i
            } = this.props;
            if ("string" == typeof i || "object" == typeof i) {
                let n = ey(this.props, i, this.presenceContext ? .custom);
                n && (e = n[t])
            }
            if (i && void 0 !== e) return e;
            let n = this.getBaseTargetFromProps(this.props, t);
            return void 0 === n || q(n) ? void 0 !== this.initialValues[t] && void 0 === e ? void 0 : this.baseTarget[t] : n
        }
        on(t, e) {
            return this.events[t] || (this.events[t] = new tX), this.events[t].add(e)
        }
        notify(t, ...e) {
            this.events[t] && this.events[t].notify(...e)
        }
        scheduleRenderMicrotask() {
            et.render(this.render)
        }
    }
    class eT extends ew {
        constructor() {
            super(...arguments), this.KeyframeResolver = tN
        }
        sortInstanceNodePosition(t, e) {
            return 2 & t.compareDocumentPosition(e) ? 1 : -1
        }
        getBaseTargetFromProps(t, e) {
            let i = t.style;
            return i ? i[e] : void 0
        }
        removeValueFromRenderState(t, {
            vars: e,
            style: i
        }) {
            delete e[t], delete i[t]
        }
        handleChildMotionValue() {
            this.childSubscription && (this.childSubscription(), delete this.childSubscription);
            let {
                children: t
            } = this.props;
            q(t) && (this.childSubscription = t.on("change", t => {
                this.current && (this.current.textContent = `${t}`)
            }))
        }
    }

    function eb(t) {
        return t.replace(/([A-Z])/g, t => `-${t.toLowerCase()}`)
    }
    let eS = (t, e) => e && "number" == typeof t ? e.transform(t) : t,
        eP = {
            x: "translateX",
            y: "translateY",
            z: "translateZ",
            transformPerspective: "perspective"
        },
        eA = r.length;

    function eE(t, e, i) {
        let {
            style: n,
            vars: s,
            transformOrigin: a
        } = t, l = !1, h = !1;
        for (let t in e) {
            let i = e[t];
            if (o.has(t)) {
                l = !0;
                continue
            }
            if (ts(t)) {
                s[t] = i;
                continue
            } {
                let e = eS(i, $[t]);
                t.startsWith("origin") ? (h = !0, a[t] = e) : n[t] = e
            }
        }
        if (!e.transform && (l || i ? n.transform = function(t, e, i) {
                let n = "",
                    s = !0;
                for (let o = 0; o < eA; o++) {
                    let a = r[o],
                        l = t[a];
                    if (void 0 === l) continue;
                    let h = !0;
                    if ("number" == typeof l) h = l === +!!a.startsWith("scale");
                    else {
                        let t = parseFloat(l);
                        h = a.startsWith("scale") ? 1 === t : 0 === t
                    }
                    if (!h || i) {
                        let t = eS(l, $[a]);
                        if (!h) {
                            s = !1;
                            let e = eP[a] || a;
                            n += `${e}(${t}) `
                        }
                        i && (e[a] = t)
                    }
                }
                return n = n.trim(), i ? n = i(e, s ? "" : n) : s && (n = "none"), n
            }(e, t.transform, i) : n.transform && (n.transform = "none")), h) {
            let {
                originX: t = "50%",
                originY: e = "50%",
                originZ: i = 0
            } = a;
            n.transformOrigin = `${t} ${e} ${i}`
        }
    }
    let eM = {
            offset: "stroke-dashoffset",
            array: "stroke-dasharray"
        },
        ek = {
            offset: "strokeDashoffset",
            array: "strokeDasharray"
        },
        eC = ["offsetDistance", "offsetPath", "offsetRotate", "offsetAnchor"];

    function eV(t, {
        attrX: e,
        attrY: i,
        attrScale: n,
        pathLength: s,
        pathSpacing: r = 1,
        pathOffset: o = 0,
        ...a
    }, l, h, u) {
        if (eE(t, a, h), l) {
            t.style.viewBox && (t.attrs.viewBox = t.style.viewBox);
            return
        }
        t.attrs = t.style, t.style = {};
        let {
            attrs: d,
            style: c
        } = t;
        for (let t of (d.transform && (c.transform = d.transform, delete d.transform), (c.transform || d.transformOrigin) && (c.transformOrigin = d.transformOrigin ? ? "50% 50%", delete d.transformOrigin), c.transform && (c.transformBox = u ? .transformBox ? ? "fill-box", delete d.transformBox), eC)) void 0 !== d[t] && (c[t] = d[t], delete d[t]);
        void 0 !== e && (d.x = e), void 0 !== i && (d.y = i), void 0 !== n && (d.scale = n), void 0 !== s && function(t, e, i = 1, n = 0, s = !0) {
            t.pathLength = 1;
            let r = s ? eM : ek;
            t[r.offset] = `${-n}`, t[r.array] = `${e} ${i}`
        }(d, s, r, o, !1)
    }
    let eR = new Set(["baseFrequency", "diffuseConstant", "kernelMatrix", "kernelUnitLength", "keySplines", "keyTimes", "limitingConeAngle", "markerHeight", "markerWidth", "numOctaves", "targetX", "targetY", "surfaceScale", "specularConstant", "specularExponent", "stdDeviation", "tableValues", "viewBox", "gradientTransform", "pathLength", "startOffset", "textLength", "lengthAdjust"]),
        eD = t => "string" == typeof t && "svg" === t.toLowerCase();

    function eL(t, {
        style: e,
        vars: i
    }, n, s) {
        let r, o = t.style;
        for (r in e) o[r] = e[r];
        for (r in s ? .applyProjectionStyles(o, n), i) o.setProperty(r, i[r])
    }

    function eB(t, e) {
        return e.max === e.min ? 0 : t / (e.max - e.min) * 100
    }
    let ej = {
            correct: (t, e) => {
                if (!e.target) return t;
                if ("string" == typeof t)
                    if (!b.test(t)) return t;
                    else t = parseFloat(t);
                let i = eB(t, e.target.x),
                    n = eB(t, e.target.y);
                return `${i}% ${n}%`
            }
        },
        eF = (t, e, i) => t + (e - t) * i,
        eI = {
            borderRadius: { ...ej,
                applyTo: ["borderTopLeftRadius", "borderTopRightRadius", "borderBottomLeftRadius", "borderBottomRightRadius"]
            },
            borderTopLeftRadius: ej,
            borderTopRightRadius: ej,
            borderBottomLeftRadius: ej,
            borderBottomRightRadius: ej,
            boxShadow: {
                correct: (t, {
                    treeScale: e,
                    projectionDelta: i
                }) => {
                    let n = B.parse(t);
                    if (n.length > 5) return t;
                    let s = B.createTransformer(t),
                        r = +("number" != typeof n[0]),
                        o = i.x.scale * e.x,
                        a = i.y.scale * e.y;
                    n[0 + r] /= o, n[1 + r] /= a;
                    let l = eF(o, a, .5);
                    return "number" == typeof n[2 + r] && (n[2 + r] /= l), "number" == typeof n[3 + r] && (n[3 + r] /= l), s(n)
                }
            }
        };

    function eO(t, {
        layout: e,
        layoutId: i
    }) {
        return o.has(t) || t.startsWith("origin") || (e || void 0 !== i) && (!!eI[t] || "opacity" === t)
    }

    function eU(t, e, i) {
        let n = t.style,
            s = e ? .style,
            r = {};
        if (!n) return r;
        for (let e in n)(q(n[e]) || s && q(s[e]) || eO(e, t) || i ? .getValue(e) ? .liveStyle !== void 0) && (r[e] = n[e]);
        return r
    }

    function eW(t, e, i) {
        let n = eU(t, e, i);
        for (let i in t)(q(t[i]) || q(e[i])) && (n[-1 !== r.indexOf(i) ? "attr" + i.charAt(0).toUpperCase() + i.substring(1) : i] = t[i]);
        return n
    }
    class e$ extends eT {
        constructor() {
            super(...arguments), this.type = "svg", this.isSVGTag = !1, this.measureInstanceViewportBox = K
        }
        getBaseTargetFromProps(t, e) {
            return t[e]
        }
        readValueFromInstance(t, e) {
            if (o.has(e)) {
                let t = z(e);
                return t && t.default || 0
            }
            return e = eR.has(e) ? e : eb(e), t.getAttribute(e)
        }
        scrapeMotionValuesFromProps(t, e, i) {
            return eW(t, e, i)
        }
        build(t, e, i) {
            eV(t, e, this.isSVGTag, i.transformTemplate, i.style)
        }
        renderInstance(t, e, i, n) {
            for (let i in eL(t, e, void 0, n), e.attrs) t.setAttribute(eR.has(i) ? i : eb(i), e.attrs[i])
        }
        mount(t) {
            this.isSVGTag = eD(t.tagName), super.mount(t)
        }
    }

    function eN({
        top: t,
        left: e,
        right: i,
        bottom: n
    }) {
        return {
            x: {
                min: e,
                max: i
            },
            y: {
                min: t,
                max: n
            }
        }
    }

    function ez(t) {
        return void 0 === t || 1 === t
    }

    function eH({
        scale: t,
        scaleX: e,
        scaleY: i
    }) {
        return !ez(t) || !ez(e) || !ez(i)
    }

    function eY(t) {
        return eH(t) || eX(t) || t.z || t.rotate || t.rotateX || t.rotateY || t.skewX || t.skewY
    }

    function eX(t) {
        var e, i;
        return (e = t.x) && "0%" !== e || (i = t.y) && "0%" !== i
    }

    function eK(t, e, i, n, s) {
        return void 0 !== s && (t = n + s * (t - n)), n + i * (t - n) + e
    }

    function eq(t, e = 0, i = 1, n, s) {
        t.min = eK(t.min, e, i, n, s), t.max = eK(t.max, e, i, n, s)
    }

    function eG(t, {
        x: e,
        y: i
    }) {
        eq(t.x, e.translate, e.scale, e.originPoint), eq(t.y, i.translate, i.scale, i.originPoint)
    }

    function eZ(t, e) {
        t.min += e, t.max += e
    }

    function e_(t, e, i, n, s = .5) {
        let r = eF(t.min, t.max, s);
        eq(t, e, i, r, n)
    }

    function eJ(t, e) {
        return "string" == typeof t ? parseFloat(t) / 100 * (e.max - e.min) : t
    }

    function eQ(t, e, i) {
        let n = i ? ? t;
        e_(t.x, eJ(e.x, n.x), e.scaleX, e.scale, e.originX), e_(t.y, eJ(e.y, n.y), e.scaleY, e.scale, e.originY)
    }

    function e0(t, e) {
        return eN(function(t, e) {
            if (!e) return t;
            let i = e({
                    x: t.left,
                    y: t.top
                }),
                n = e({
                    x: t.right,
                    y: t.bottom
                });
            return {
                top: i.y,
                left: i.x,
                bottom: n.y,
                right: n.x
            }
        }(t.getBoundingClientRect(), e))
    }
    class e1 extends eT {
        constructor() {
            super(...arguments), this.type = "html", this.renderInstance = eL
        }
        readValueFromInstance(t, e) {
            if (o.has(e)) return this.projection ? .isProjecting ? ty(e) : ((t, e) => {
                let {
                    transform: i = "none"
                } = getComputedStyle(t);
                return tv(i, e)
            })(t, e); {
                let i = window.getComputedStyle(t),
                    n = (ts(e) ? i.getPropertyValue(e) : i[e]) || 0;
                return "string" == typeof n ? n.trim() : n
            }
        }
        measureInstanceViewportBox(t, {
            transformPagePoint: e
        }) {
            return e0(t, e)
        }
        build(t, e, i) {
            eE(t, e, i.transformTemplate)
        }
        scrapeMotionValuesFromProps(t, e, i) {
            return eU(t, e, i)
        }
    }
    var e2 = t.i(271645);
    let e3 = ["animate", "circle", "defs", "desc", "ellipse", "g", "image", "line", "filter", "marker", "mask", "metadata", "path", "pattern", "polygon", "polyline", "rect", "stop", "switch", "symbol", "svg", "text", "tspan", "use", "view"];

    function e5(t) {
        if ("string" != typeof t || t.includes("-"));
        else if (e3.indexOf(t) > -1 || /[A-Z]/u.test(t)) return !0;
        return !1
    }
    var e9 = t.i(843476);
    let e4 = (0, e2.createContext)({}),
        e6 = (0, e2.createContext)({
            strict: !1
        }),
        e8 = (0, e2.createContext)({
            transformPagePoint: t => t,
            isStatic: !1,
            reducedMotion: "never"
        }),
        e7 = (0, e2.createContext)({});

    function it(t) {
        return Array.isArray(t) ? t.join(" ") : t
    }
    let ie = () => ({
        style: {},
        transform: {},
        transformOrigin: {},
        vars: {}
    });

    function ii(t, e, i) {
        for (let n in e) q(e[n]) || eO(n, i) || (t[n] = e[n])
    }
    let is = () => ({ ...ie(),
            attrs: {}
        }),
        ir = new Set(["animate", "exit", "variants", "initial", "style", "values", "variants", "transition", "transformTemplate", "custom", "inherit", "onBeforeLayoutMeasure", "onAnimationStart", "onAnimationComplete", "onUpdate", "onDragStart", "onDrag", "onDragEnd", "onMeasureDragConstraints", "onDirectionLock", "onDragTransitionEnd", "_dragX", "_dragY", "onHoverStart", "onHoverEnd", "onViewportEnter", "onViewportLeave", "globalTapTarget", "propagate", "ignoreStrict", "viewport"]);

    function io(t) {
        return t.startsWith("while") || t.startsWith("drag") && "draggable" !== t || t.startsWith("layout") || t.startsWith("onTap") || t.startsWith("onPan") || t.startsWith("onLayout") || ir.has(t)
    }
    let ia = t => !io(t);
    try {
        Q = t.r(934537).default, "function" == typeof Q && (ia = t => t.startsWith("on") ? !io(t) : Q(t))
    } catch {}

    function il(t) {
        return q(t) ? t.get() : t
    }
    let ih = (0, e2.createContext)(null);

    function iu(t) {
        let e = (0, e2.useRef)(null);
        return null === e.current && (e.current = t()), e.current
    }
    let id = t => (e, i) => {
            let n = (0, e2.useContext)(e7),
                s = (0, e2.useContext)(ih),
                r = () => (function({
                    scrapeMotionValuesFromProps: t,
                    createRenderState: e
                }, i, n, s) {
                    return {
                        latestValues: function(t, e, i, n) {
                            let s = {},
                                r = n(t, {});
                            for (let t in r) s[t] = il(r[t]);
                            let {
                                initial: o,
                                animate: a
                            } = t, l = ed(t), h = ec(t);
                            e && h && !l && !1 !== t.inherit && (void 0 === o && (o = e.initial), void 0 === a && (a = e.animate));
                            let u = !!i && !1 === i.initial,
                                d = (u = u || !1 === o) ? a : o;
                            if (d && "boolean" != typeof d && !ea(d)) {
                                let e = Array.isArray(d) ? d : [d];
                                for (let i = 0; i < e.length; i++) {
                                    let n = ey(t, e[i]);
                                    if (n) {
                                        let {
                                            transitionEnd: t,
                                            transition: e,
                                            ...i
                                        } = n;
                                        for (let t in i) {
                                            let e = i[t];
                                            if (Array.isArray(e)) {
                                                let t = u ? e.length - 1 : 0;
                                                e = e[t]
                                            }
                                            null !== e && (s[t] = e)
                                        }
                                        for (let e in t) s[e] = t[e]
                                    }
                                }
                            }
                            return s
                        }(i, n, s, t),
                        renderState: e()
                    }
                })(t, e, n, s);
            return i ? r() : iu(r)
        },
        ic = id({
            scrapeMotionValuesFromProps: eU,
            createRenderState: ie
        }),
        ip = id({
            scrapeMotionValuesFromProps: eW,
            createRenderState: is
        }),
        im = {
            animation: ["animate", "variants", "whileHover", "whileTap", "exit", "whileInView", "whileFocus", "whileDrag"],
            exit: ["exit"],
            drag: ["drag", "dragControls"],
            focus: ["whileFocus"],
            hover: ["whileHover", "onHoverStart", "onHoverEnd"],
            tap: ["whileTap", "onTap", "onTapStart", "onTapCancel"],
            pan: ["onPan", "onPanStart", "onPanSessionStart", "onPanEnd"],
            inView: ["whileInView", "onViewportEnter", "onViewportLeave"],
            layout: ["layout", "layoutId"]
        },
        ig = !1;

    function iy() {
        return ! function() {
            if (ig) return;
            let t = {};
            for (let e in im) t[e] = {
                isEnabled: t => im[e].some(e => !!t[e])
            };
            ex = t, ig = !0
        }(), ex
    }
    let iv = Symbol.for("motionComponentSymbol"),
        ix = "data-" + eb("framerAppearId"),
        iw = (0, e2.createContext)({});

    function iT(t) {
        return t && "object" == typeof t && Object.prototype.hasOwnProperty.call(t, "current")
    }
    let ib = "u" > typeof window ? e2.useLayoutEffect : e2.useEffect;

    function iS(t, {
        forwardMotionProps: e = !1,
        type: i
    } = {}, n, s) {
        n && function(t) {
            let e = iy();
            for (let i in t) e[i] = { ...e[i],
                ...t[i]
            };
            ex = e
        }(n);
        let r = i ? "svg" === i : e5(t),
            o = r ? ip : ic;

        function a(i, n) {
            var a;
            let l, h, u, d = { ...(0, e2.useContext)(e8),
                    ...i,
                    layoutId: function({
                        layoutId: t
                    }) {
                        let e = (0, e2.useContext)(e4).id;
                        return e && void 0 !== t ? e + "-" + t : t
                    }(i)
                },
                {
                    isStatic: c
                } = d,
                p = function(t) {
                    let {
                        initial: e,
                        animate: i
                    } = function(t, e) {
                        if (ed(t)) {
                            let {
                                initial: e,
                                animate: i
                            } = t;
                            return {
                                initial: !1 === e || el(e) ? e : void 0,
                                animate: el(i) ? i : void 0
                            }
                        }
                        return !1 !== t.inherit ? e : {}
                    }(t, (0, e2.useContext)(e7));
                    return (0, e2.useMemo)(() => ({
                        initial: e,
                        animate: i
                    }), [it(e), it(i)])
                }(i),
                m = o(i, c);
            if (!c && "u" > typeof window) {
                (0, e2.useContext)(e6).strict;
                let e = function(t) {
                    let {
                        drag: e,
                        layout: i
                    } = iy();
                    if (!e && !i) return {};
                    let n = { ...e,
                        ...i
                    };
                    return {
                        MeasureLayout: e ? .isEnabled(t) || i ? .isEnabled(t) ? n.MeasureLayout : void 0,
                        ProjectionNode: n.ProjectionNode
                    }
                }(d);
                l = e.MeasureLayout, p.visualElement = function(t, e, i, n, s, r) {
                    let {
                        visualElement: o
                    } = (0, e2.useContext)(e7), a = (0, e2.useContext)(e6), l = (0, e2.useContext)(ih), h = (0, e2.useContext)(e8), u = h.reducedMotion, d = h.skipAnimations, c = (0, e2.useRef)(null), p = (0, e2.useRef)(!1);
                    n = n || a.renderer, !c.current && n && (c.current = n(t, {
                        visualState: e,
                        parent: o,
                        props: i,
                        presenceContext: l,
                        blockInitialAnimation: !!l && !1 === l.initial,
                        reducedMotionConfig: u,
                        skipAnimations: d,
                        isSVG: r
                    }), p.current && c.current && (c.current.manuallyAnimateOnMount = !0));
                    let m = c.current,
                        f = (0, e2.useContext)(iw);
                    m && !m.projection && s && ("html" === m.type || "svg" === m.type) && function(t, e, i, n) {
                        let {
                            layoutId: s,
                            layout: r,
                            drag: o,
                            dragConstraints: a,
                            layoutScroll: l,
                            layoutRoot: h,
                            layoutAnchor: u,
                            layoutCrossfade: d
                        } = e;
                        t.projection = new i(t.latestValues, e["data-framer-portal-id"] ? void 0 : function t(e) {
                            if (e) return !1 !== e.options.allowProjection ? e.projection : t(e.parent)
                        }(t.parent)), t.projection.setOptions({
                            layoutId: s,
                            layout: r,
                            alwaysMeasureLayout: !!o || a && iT(a),
                            visualElement: t,
                            animationType: "string" == typeof r ? r : "both",
                            initialPromotionConfig: n,
                            crossfade: d,
                            layoutScroll: l,
                            layoutRoot: h,
                            layoutAnchor: u
                        })
                    }(c.current, i, s, f);
                    let g = (0, e2.useRef)(!1);
                    (0, e2.useInsertionEffect)(() => {
                        m && g.current && m.update(i, l)
                    });
                    let y = i[ix],
                        v = (0, e2.useRef)(!!y && "u" > typeof window && !window.MotionHandoffIsComplete ? .(y) && window.MotionHasOptimisedAnimation ? .(y));
                    return ib(() => {
                        p.current = !0, m && (g.current = !0, window.MotionIsMounted = !0, m.updateFeatures(), m.scheduleRenderMicrotask(), v.current && m.animationState && m.animationState.animateChanges())
                    }), (0, e2.useEffect)(() => {
                        m && (!v.current && m.animationState && m.animationState.animateChanges(), v.current && (queueMicrotask(() => {
                            window.MotionHandoffMarkAsComplete ? .(y)
                        }), v.current = !1), m.enteringChildren = void 0)
                    }), m
                }(t, m, d, s, e.ProjectionNode, r)
            }
            return (0, e9.jsxs)(e7.Provider, {
                value: p,
                children: [l && p.visualElement ? (0, e9.jsx)(l, {
                    visualElement: p.visualElement,
                    ...d
                }) : null, function(t, e, i, {
                    latestValues: n
                }, s, r = !1, o) {
                    let a = (o ? ? e5(t) ? function(t, e, i, n) {
                            let s = (0, e2.useMemo)(() => {
                                let i = is();
                                return eV(i, e, eD(n), t.transformTemplate, t.style), { ...i.attrs,
                                    style: { ...i.style
                                    }
                                }
                            }, [e]);
                            if (t.style) {
                                let e = {};
                                ii(e, t.style, t), s.style = { ...e,
                                    ...s.style
                                }
                            }
                            return s
                        } : function(t, e) {
                            let i, n, s = {},
                                r = (i = t.style || {}, ii(n = {}, i, t), Object.assign(n, function({
                                    transformTemplate: t
                                }, e) {
                                    return (0, e2.useMemo)(() => {
                                        let i = ie();
                                        return eE(i, e, t), Object.assign({}, i.vars, i.style)
                                    }, [e])
                                }(t, e)), n);
                            return t.drag && !1 !== t.dragListener && (s.draggable = !1, r.userSelect = r.WebkitUserSelect = r.WebkitTouchCallout = "none", r.touchAction = !0 === t.drag ? "none" : `pan-${"x"===t.drag?"y":"x"}`), void 0 === t.tabIndex && (t.onTap || t.onTapStart || t.whileTap) && (s.tabIndex = 0), s.style = r, s
                        })(e, n, s, t),
                        l = function(t, e, i) {
                            let n = {};
                            for (let s in t)("values" !== s || "object" != typeof t.values) && !q(t[s]) && (ia(s) || !0 === i && io(s) || !e && !io(s) || t.draggable && s.startsWith("onDrag")) && (n[s] = t[s]);
                            return n
                        }(e, "string" == typeof t, r),
                        h = t !== e2.Fragment ? { ...l,
                            ...a,
                            ref: i
                        } : {},
                        {
                            children: u
                        } = e,
                        d = (0, e2.useMemo)(() => q(u) ? u.get() : u, [u]);
                    return (0, e2.createElement)(t, { ...h,
                        children: d
                    })
                }(t, i, (a = p.visualElement, h = (0, e2.useRef)(n), (0, e2.useInsertionEffect)(() => {
                    h.current = n
                }), u = (0, e2.useRef)(null), (0, e2.useCallback)(t => {
                    t && m.onMount ? .(t);
                    let e = h.current;
                    if ("function" == typeof e)
                        if (t) {
                            let i = e(t);
                            "function" == typeof i && (u.current = i)
                        } else u.current ? (u.current(), u.current = null) : e(t);
                    else e && (e.current = t);
                    a && (t ? a.mount(t) : a.unmount())
                }, [a])), m, c, e, r)]
            })
        }
        a.displayName = `motion.${"string"==typeof t?t:`create(${t.displayName??t.name??""})`}`;
        let l = (0, e2.forwardRef)(a);
        return l[iv] = t, l
    }
    class iP {
        constructor(t) {
            this.isMounted = !1, this.node = t
        }
        update() {}
    }

    function iA(t, e, i) {
        let n = t.getProps();
        return ey(n, e, void 0 !== i ? i : n.custom, t)
    }

    function iE(t, e) {
        if (t ? .inherit && e) {
            let {
                inherit: i,
                ...n
            } = t;
            return { ...e,
                ...n
            }
        }
        return t
    }

    function iM(t, e) {
        let i = t ? .[e] ? ? t ? .default ? ? t;
        return i !== t ? iE(i, t) : i
    }
    let ik = t => Array.isArray(t);

    function iC(t, e) {
        let i = t.getValue("willChange");
        if (q(i) && i.add) return i.add(e);
        if (!i && tA.WillChange) {
            let i = new tA.WillChange("auto");
            t.addValue("willChange", i), i.add(e)
        }
    }
    let iV = (t, e) => i => e(t(i)),
        iR = (...t) => t.reduce(iV);

    function iD(t, e, i) {
        return (i < 0 && (i += 1), i > 1 && (i -= 1), i < 1 / 6) ? t + (e - t) * 6 * i : i < .5 ? e : i < 2 / 3 ? t + (e - t) * (2 / 3 - i) * 6 : t
    }

    function iL(t, e) {
        return i => i > 0 ? e : t
    }
    let iB = (t, e, i) => {
            let n = t * t,
                s = i * (e * e - n) + n;
            return s < 0 ? 0 : Math.sqrt(s)
        },
        ij = [v, y, E];

    function iF(t) {
        let e = ij.find(e => e.test(t));
        if (te(!!e, `'${t}' is not an animatable color. Use the equivalent color code instead.`, "color-not-animatable"), !e) return !1;
        let i = e.parse(t);
        return e === E && (i = function({
            hue: t,
            saturation: e,
            lightness: i,
            alpha: n
        }) {
            t /= 360, i /= 100;
            let s = 0,
                r = 0,
                o = 0;
            if (e /= 100) {
                let n = i < .5 ? i * (1 + e) : i + e - i * e,
                    a = 2 * i - n;
                s = iD(a, n, t + 1 / 3), r = iD(a, n, t), o = iD(a, n, t - 1 / 3)
            } else s = r = o = i;
            return {
                red: Math.round(255 * s),
                green: Math.round(255 * r),
                blue: Math.round(255 * o),
                alpha: n
            }
        }(i)), i
    }
    let iI = (t, e) => {
            let i = iF(t),
                n = iF(e);
            if (!i || !n) return iL(t, e);
            let s = { ...i
            };
            return t => (s.red = iB(i.red, n.red, t), s.green = iB(i.green, n.green, t), s.blue = iB(i.blue, n.blue, t), s.alpha = eF(i.alpha, n.alpha, t), y.transform(s))
        },
        iO = new Set(["none", "hidden"]);

    function iU(t, e) {
        return i => eF(t, e, i)
    }

    function iW(t) {
        return "number" == typeof t ? iU : "string" == typeof t ? to(t) ? iL : M.test(t) ? iI : iz : Array.isArray(t) ? i$ : "object" == typeof t ? M.test(t) ? iI : iN : iL
    }

    function i$(t, e) {
        let i = [...t],
            n = i.length,
            s = t.map((t, i) => iW(t)(t, e[i]));
        return t => {
            for (let e = 0; e < n; e++) i[e] = s[e](t);
            return i
        }
    }

    function iN(t, e) {
        let i = { ...t,
                ...e
            },
            n = {};
        for (let s in i) void 0 !== t[s] && void 0 !== e[s] && (n[s] = iW(t[s])(t[s], e[s]));
        return t => {
            for (let e in n) i[e] = n[e](t);
            return i
        }
    }
    let iz = (t, e) => {
        let i = B.createTransformer(e),
            n = D(t),
            s = D(e);
        if (!(n.indexes.var.length === s.indexes.var.length && n.indexes.color.length === s.indexes.color.length && n.indexes.number.length >= s.indexes.number.length)) return te(!0, `Complex values '${t}' and '${e}' too different to mix. Ensure all colors are of the same type, and that each contains the same quantity of number and color values. Falling back to instant transition.`, "complex-values-different"), iL(t, e);
        if (iO.has(t) && !s.values.length || iO.has(e) && !n.values.length) return iO.has(t) ? i => i <= 0 ? t : e : i => i >= 1 ? e : t;
        return iR(i$(function(t, e) {
            let i = [],
                n = {
                    color: 0,
                    var: 0,
                    number: 0
                };
            for (let s = 0; s < e.values.length; s++) {
                let r = e.types[s],
                    o = t.indexes[r][n[r]],
                    a = t.values[o] ? ? 0;
                i[s] = a, n[r]++
            }
            return i
        }(n, s), s.values), i)
    };

    function iH(t, e, i) {
        return "number" == typeof t && "number" == typeof e && "number" == typeof i ? eF(t, e, i) : iW(t)(t, e)
    }
    let iY = t => {
        let e = ({
            timestamp: e
        }) => t(e);
        return {
            start: (t = !0) => tk.update(e, t),
            stop: () => tC(e),
            now: () => tV.isProcessing ? tV.timestamp : ei.now()
        }
    };

    function iX(t) {
        let e = 0,
            i = t.next(e);
        for (; !i.done && e < 2e4;) e += 50, i = t.next(e);
        return e >= 2e4 ? 1 / 0 : e
    }
    let iK = .01,
        iq = 2,
        iG = .005,
        iZ = .5;

    function i_(t, e) {
        return t * Math.sqrt(1 - e * e)
    }
    let iJ = ["duration", "bounce"],
        iQ = ["stiffness", "damping", "mass"];

    function i0(t, e) {
        return e.some(e => void 0 !== t[e])
    }

    function i1(t = .3, e = .3) {
        let i, n, s, r, o, l, h = "object" != typeof t ? {
                visualDuration: t,
                keyframes: [0, 1],
                bounce: e
            } : t,
            {
                restSpeed: u,
                restDelta: d
            } = h,
            c = h.keyframes[0],
            p = h.keyframes[h.keyframes.length - 1],
            m = {
                done: !1,
                value: c
            },
            {
                stiffness: f,
                damping: g,
                mass: y,
                duration: v,
                velocity: x,
                isResolvedFromDuration: w
            } = function(t) {
                let e = {
                    velocity: 0,
                    stiffness: 100,
                    damping: 10,
                    mass: 1,
                    isResolvedFromDuration: !1,
                    ...t
                };
                if (!i0(t, iQ) && i0(t, iJ))
                    if (e.velocity = 0, t.visualDuration) {
                        let i = 2 * Math.PI / (1.2 * t.visualDuration),
                            n = i * i,
                            s = 2 * a(.05, 1, 1 - (t.bounce || 0)) * Math.sqrt(n);
                        e = { ...e,
                            mass: 1,
                            stiffness: n,
                            damping: s
                        }
                    } else {
                        let i = function({
                            duration: t = 800,
                            bounce: e = .3,
                            velocity: i = 0,
                            mass: n = 1
                        }) {
                            let s, r;
                            te(t <= tz(10), "Spring duration must be 10 seconds or less", "spring-duration-limit");
                            let o = 1 - e;
                            o = a(.05, 1, o), t = a(.01, 10, t / 1e3), o < 1 ? (s = e => {
                                let n = e * o,
                                    s = n * t;
                                return .001 - (n - i) / i_(e, o) * Math.exp(-s)
                            }, r = e => {
                                let n = e * o * t,
                                    r = Math.pow(o, 2) * Math.pow(e, 2) * t,
                                    a = Math.exp(-n),
                                    l = i_(Math.pow(e, 2), o);
                                return (n * i + i - r) * a * (-s(e) + .001 > 0 ? -1 : 1) / l
                            }) : (s = e => -.001 + Math.exp(-e * t) * ((e - i) * t + 1), r = e => t * t * (i - e) * Math.exp(-e * t));
                            let l = function(t, e, i) {
                                let n = i;
                                for (let i = 1; i < 12; i++) n -= t(n) / e(n);
                                return n
                            }(s, r, 5 / t);
                            if (t = tz(t), isNaN(l)) return {
                                stiffness: 100,
                                damping: 10,
                                duration: t
                            }; {
                                let e = Math.pow(l, 2) * n;
                                return {
                                    stiffness: e,
                                    damping: 2 * o * Math.sqrt(n * e),
                                    duration: t
                                }
                            }
                        }({ ...t,
                            velocity: 0
                        });
                        (e = { ...e,
                            ...i,
                            mass: 1
                        }).isResolvedFromDuration = !0
                    }
                return e
            }({ ...h,
                velocity: -((h.velocity || 0) / 1e3)
            }),
            T = x || 0,
            b = g / (2 * Math.sqrt(f * y)),
            S = p - c,
            P = Math.sqrt(f / y) / 1e3,
            A = 5 > Math.abs(S);
        if (u || (u = A ? iK : iq), d || (d = A ? iG : iZ), b < 1) s = i_(P, b), r = (T + b * P * S) / s, i = t => p - Math.exp(-b * P * t) * (r * Math.sin(s * t) + S * Math.cos(s * t)), o = b * P * r + S * s, l = b * P * S - r * s, n = t => Math.exp(-b * P * t) * (o * Math.sin(s * t) + l * Math.cos(s * t));
        else if (1 === b) {
            i = t => p - Math.exp(-P * t) * (S + (T + P * S) * t);
            let t = T + P * S;
            n = e => Math.exp(-P * e) * (P * t * e - T)
        } else {
            let t = P * Math.sqrt(b * b - 1);
            i = e => {
                let i = Math.exp(-b * P * e),
                    n = Math.min(t * e, 300);
                return p - i * ((T + b * P * S) * Math.sinh(n) + t * S * Math.cosh(n)) / t
            };
            let e = (T + b * P * S) / t,
                s = b * P * e - S * t,
                r = b * P * S - e * t;
            n = e => {
                let i = Math.exp(-b * P * e),
                    n = Math.min(t * e, 300);
                return i * (s * Math.sinh(n) + r * Math.cosh(n))
            }
        }
        let E = {
            calculatedDuration: w && v || null,
            velocity: t => tz(n(t)),
            next: t => {
                if (!w && b < 1) {
                    let e = Math.exp(-b * P * t),
                        i = Math.sin(s * t),
                        n = Math.cos(s * t),
                        a = p - e * (r * i + S * n);
                    return m.done = Math.abs(tz(e * (o * i + l * n))) <= u && Math.abs(p - a) <= d, m.value = m.done ? p : a, m
                }
                let e = i(t);
                return w ? m.done = t >= v : m.done = Math.abs(tz(n(t))) <= u && Math.abs(p - e) <= d, m.value = m.done ? p : e, m
            },
            toString: () => {
                let t = Math.min(iX(E), 2e4),
                    e = t5(e => E.next(t * e).value, t, 30);
                return t + "ms " + e
            },
            toTransition: () => {}
        };
        return E
    }

    function i2(t, e, i) {
        var n, s;
        let r = Math.max(e - 5, 0);
        return n = i - t(r), (s = e - r) ? 1e3 / s * n : 0
    }

    function i3({
        keyframes: t,
        velocity: e = 0,
        power: i = .8,
        timeConstant: n = 325,
        bounceDamping: s = 10,
        bounceStiffness: r = 500,
        modifyTarget: o,
        min: a,
        max: l,
        restDelta: h = .5,
        restSpeed: u
    }) {
        let d, c, p = t[0],
            m = {
                done: !1,
                value: p
            },
            f = i * e,
            g = p + f,
            y = void 0 === o ? g : o(g);
        y !== g && (f = y - p);
        let v = t => -f * Math.exp(-t / n),
            x = t => y + v(t),
            w = t => {
                let e = v(t),
                    i = x(t);
                m.done = Math.abs(e) <= h, m.value = m.done ? y : i
            },
            T = t => {
                let e;
                if (e = m.value, void 0 !== a && e < a || void 0 !== l && e > l) {
                    var i;
                    d = t, c = i1({
                        keyframes: [m.value, (i = m.value, void 0 === a ? l : void 0 === l || Math.abs(a - i) < Math.abs(l - i) ? a : l)],
                        velocity: i2(x, t, m.value),
                        damping: s,
                        stiffness: r,
                        restDelta: h,
                        restSpeed: u
                    })
                }
            };
        return T(0), {
            calculatedDuration: null,
            next: t => {
                let e = !1;
                return (c || void 0 !== d || (e = !0, w(t), T(t)), void 0 !== d && t >= d) ? c.next(t - d) : (e || w(t), m)
            }
        }
    }
    i1.applyToOptions = t => {
        let e = function(t, e = 100, i) {
            let n = i({ ...t,
                    keyframes: [0, e]
                }),
                s = Math.min(iX(n), 2e4);
            return {
                type: "keyframes",
                ease: t => n.next(s * t).value / e,
                duration: s / 1e3
            }
        }(t, 100, i1);
        return t.ease = e.ease, t.duration = tz(e.duration), t.type = "keyframes", t
    };
    let i5 = (t, e, i) => (((1 - 3 * i + 3 * e) * t + (3 * i - 6 * e)) * t + 3 * e) * t;

    function i9(t, e, i, n) {
        return t === e && i === n ? tP : s => 0 === s || 1 === s ? s : i5(function(t, e, i, n, s) {
            let r, o, a = 0;
            do(r = i5(o = e + (i - e) / 2, n, s) - t) > 0 ? i = o : e = o; while (Math.abs(r) > 1e-7 && ++a < 12) return o
        }(s, 0, 1, t, i), e, n)
    }
    let i4 = i9(.42, 0, 1, 1),
        i6 = i9(0, 0, .58, 1),
        i8 = i9(.42, 0, .58, 1),
        i7 = t => e => e <= .5 ? t(2 * e) / 2 : (2 - t(2 * (1 - e))) / 2,
        nt = t => e => 1 - t(1 - e),
        ne = i9(.33, 1.53, .69, .99),
        ni = nt(ne),
        nn = i7(ni),
        ns = t => t >= 1 ? 1 : (t *= 2) < 1 ? .5 * ni(t) : .5 * (2 - Math.pow(2, -10 * (t - 1))),
        nr = t => 1 - Math.sin(Math.acos(t)),
        no = nt(nr),
        na = i7(nr),
        nl = {
            linear: tP,
            easeIn: i4,
            easeInOut: i8,
            easeOut: i6,
            circIn: nr,
            circInOut: na,
            circOut: no,
            backIn: ni,
            backInOut: nn,
            backOut: ne,
            anticipate: ns
        },
        nh = t => {
            if (t2(t)) {
                ti(4 === t.length, "Cubic bezier arrays must contain four numerical values.", "cubic-bezier-length");
                let [e, i, n, s] = t;
                return i9(e, i, n, s)
            }
            return "string" == typeof t ? (ti(void 0 !== nl[t], `Invalid easing type '${t}'`, "invalid-easing-type"), nl[t]) : t
        },
        nu = (t, e, i) => {
            let n = e - t;
            return 0 === n ? 1 : (i - t) / n
        };

    function nd({
        duration: t = 300,
        keyframes: e,
        times: i,
        ease: n = "easeInOut"
    }) {
        var s;
        let r, o = Array.isArray(n) && "number" != typeof n[0] ? n.map(nh) : nh(n),
            l = {
                done: !1,
                value: e[0]
            },
            h = function(t, e, {
                clamp: i = !0,
                ease: n,
                mixer: s
            } = {}) {
                let r = t.length;
                if (ti(r === e.length, "Both input and output ranges must be the same length", "range-length"), 1 === r) return () => e[0];
                if (2 === r && e[0] === e[1]) return () => e[1];
                let o = t[0] === t[1];
                t[0] > t[r - 1] && (t = [...t].reverse(), e = [...e].reverse());
                let l = function(t, e, i) {
                        let n = [],
                            s = i || tA.mix || iH,
                            r = t.length - 1;
                        for (let i = 0; i < r; i++) {
                            let r = s(t[i], t[i + 1]);
                            e && (r = iR(Array.isArray(e) ? e[i] || tP : e, r)), n.push(r)
                        }
                        return n
                    }(e, n, s),
                    h = l.length,
                    u = i => {
                        if (o && i < t[0]) return e[0];
                        let n = 0;
                        if (h > 1)
                            for (; n < t.length - 2 && !(i < t[n + 1]); n++);
                        let s = nu(t[n], t[n + 1], i);
                        return l[n](s)
                    };
                return i ? e => u(a(t[0], t[r - 1], e)) : u
            }((s = i && i.length === e.length ? i : (! function(t, e) {
                let i = t[t.length - 1];
                for (let n = 1; n <= e; n++) {
                    let s = nu(0, e, n);
                    t.push(eF(i, 1, s))
                }
            }(r = [0], e.length - 1), r), s.map(e => e * t)), e, {
                ease: Array.isArray(o) ? o : e.map(() => o || i8).splice(0, e.length - 1)
            });
        return {
            calculatedDuration: t,
            next: e => (l.value = h(e), l.done = e >= t, l)
        }
    }
    let nc = {
        decay: i3,
        inertia: i3,
        tween: nd,
        keyframes: nd,
        spring: i1
    };

    function np(t) {
        "string" == typeof t.type && (t.type = nc[t.type])
    }
    let nm = t => t / 100;
    class nf extends t0 {
        constructor(t) {
            super(), this.state = "idle", this.startTime = null, this.isStopped = !1, this.currentTime = 0, this.holdTime = null, this.playbackSpeed = 1, this.delayState = {
                done: !1,
                value: void 0
            }, this.stop = () => {
                let {
                    motionValue: t
                } = this.options;
                t && t.updatedAt !== ei.now() && this.tick(ei.now()), this.isStopped = !0, "idle" !== this.state && (this.teardown(), this.options.onStop ? .())
            }, t1.mainThread++, this.options = t, this.initAnimation(), this.play(), !1 === t.autoplay && this.pause()
        }
        initAnimation() {
            let {
                options: t
            } = this;
            np(t);
            let {
                type: e = nd,
                repeat: i = 0,
                repeatDelay: n = 0,
                repeatType: s,
                velocity: r = 0
            } = t, {
                keyframes: o
            } = t, a = e || nd;
            a !== nd && "number" != typeof o[0] && (this.mixKeyframes = iR(nm, iH(o[0], o[1])), o = [0, 100]);
            let l = a({ ...t,
                keyframes: o
            });
            "mirror" === s && (this.mirroredGenerator = a({ ...t,
                keyframes: [...o].reverse(),
                velocity: -r
            })), null === l.calculatedDuration && (l.calculatedDuration = iX(l));
            let {
                calculatedDuration: h
            } = l;
            this.calculatedDuration = h, this.resolvedDuration = h + n, this.totalDuration = this.resolvedDuration * (i + 1) - n, this.generator = l
        }
        updateTime(t) {
            let e = Math.round(t - this.startTime) * this.playbackSpeed;
            null !== this.holdTime ? this.currentTime = this.holdTime : this.currentTime = e
        }
        tick(t, e = !1) {
            let i, {
                generator: n,
                totalDuration: s,
                mixKeyframes: r,
                mirroredGenerator: o,
                resolvedDuration: l,
                calculatedDuration: h
            } = this;
            if (null === this.startTime) return n.next(0);
            let {
                delay: u = 0,
                keyframes: d,
                repeat: c,
                repeatType: p,
                repeatDelay: m,
                type: f,
                onUpdate: g,
                finalKeyframe: y
            } = this.options;
            this.speed > 0 ? this.startTime = Math.min(this.startTime, t) : this.speed < 0 && (this.startTime = Math.min(t - s / this.speed, this.startTime)), e ? this.currentTime = t : this.updateTime(t);
            let v = this.currentTime - u * (this.playbackSpeed >= 0 ? 1 : -1),
                x = this.playbackSpeed >= 0 ? v < 0 : v > s;
            this.currentTime = Math.max(v, 0), "finished" === this.state && null === this.holdTime && (this.currentTime = s);
            let w = this.currentTime,
                T = n;
            if (c) {
                let t = Math.min(this.currentTime, s) / l,
                    e = Math.floor(t),
                    i = t % 1;
                !i && t >= 1 && (i = 1), 1 === i && e--, (e = Math.min(e, c + 1)) % 2 && ("reverse" === p ? (i = 1 - i, m && (i -= m / l)) : "mirror" === p && (T = o)), w = a(0, 1, i) * l
            }
            x ? (this.delayState.value = d[0], i = this.delayState) : i = T.next(w), r && !x && (i.value = r(i.value));
            let {
                done: b
            } = i;
            x || null === h || (b = this.playbackSpeed >= 0 ? this.currentTime >= s : this.currentTime <= 0);
            let S = null === this.holdTime && ("finished" === this.state || "running" === this.state && b);
            return S && f !== i3 && (i.value = tQ(d, this.options, y, this.speed)), g && g(i.value), S && this.finish(), i
        }
        then(t, e) {
            return this.finished.then(t, e)
        }
        get duration() {
            return this.calculatedDuration / 1e3
        }
        get iterationDuration() {
            let {
                delay: t = 0
            } = this.options || {};
            return this.duration + t / 1e3
        }
        get time() {
            return this.currentTime / 1e3
        }
        set time(t) {
            t = tz(t), this.currentTime = t, null === this.startTime || null !== this.holdTime || 0 === this.playbackSpeed ? this.holdTime = t : this.driver && (this.startTime = this.driver.now() - t / this.playbackSpeed), this.driver ? this.driver.start(!1) : (this.startTime = 0, this.state = "paused", this.holdTime = t, this.tick(t))
        }
        getGeneratorVelocity() {
            let t = this.currentTime;
            if (t <= 0) return this.options.velocity || 0;
            if (this.generator.velocity) return this.generator.velocity(t);
            let e = this.generator.next(t).value;
            return i2(t => this.generator.next(t).value, t, e)
        }
        get speed() {
            return this.playbackSpeed
        }
        set speed(t) {
            let e = this.playbackSpeed !== t;
            e && this.driver && this.updateTime(ei.now()), this.playbackSpeed = t, e && this.driver && (this.time = this.currentTime / 1e3)
        }
        play() {
            if (this.isStopped) return;
            let {
                driver: t = iY,
                startTime: e
            } = this.options;
            this.driver || (this.driver = t(t => this.tick(t))), this.options.onPlay ? .();
            let i = this.driver.now();
            "finished" === this.state ? (this.updateFinished(), this.startTime = i) : null !== this.holdTime ? this.startTime = i - this.holdTime : this.startTime || (this.startTime = e ? ? i), "finished" === this.state && this.speed < 0 && (this.startTime += this.calculatedDuration), this.holdTime = null, this.state = "running", this.driver.start()
        }
        pause() {
            this.state = "paused", this.updateTime(ei.now()), this.holdTime = this.currentTime
        }
        complete() {
            "running" !== this.state && this.play(), this.state = "finished", this.holdTime = null
        }
        finish() {
            this.notifyFinished(), this.teardown(), this.state = "finished", this.options.onComplete ? .()
        }
        cancel() {
            this.holdTime = null, this.startTime = 0, this.tick(0), this.teardown(), this.options.onCancel ? .()
        }
        teardown() {
            this.state = "idle", this.stopDriver(), this.startTime = this.holdTime = null, t1.mainThread--
        }
        stopDriver() {
            this.driver && (this.driver.stop(), this.driver = void 0)
        }
        sample(t) {
            return this.startTime = 0, this.tick(t, !0)
        }
        attachTimeline(t) {
            return this.options.allowFlatten && (this.options.type = "keyframes", this.options.ease = "linear", this.initAnimation()), this.driver ? .stop(), t.observe(this)
        }
    }
    let ng = {
        anticipate: ns,
        backInOut: nn,
        circInOut: na
    };
    class ny extends t8 {
        constructor(t) {
            ! function(t) {
                "string" == typeof t.ease && t.ease in ng && (t.ease = ng[t.ease])
            }(t), np(t), super(t), void 0 !== t.startTime && !1 !== t.autoplay && (this.startTime = t.startTime), this.options = t
        }
        updateMotionValue(t) {
            let {
                motionValue: e,
                onUpdate: i,
                onComplete: n,
                element: s,
                ...r
            } = this.options;
            if (!e) return;
            if (void 0 !== t) return void e.set(t);
            let o = new nf({ ...r,
                    autoplay: !1
                }),
                l = Math.max(10, ei.now() - this.startTime),
                h = a(0, 10, l - 10),
                u = o.sample(l).value,
                {
                    name: d
                } = this.options;
            s && d && tK(s, d, u), e.setWithVelocity(o.sample(Math.max(0, l - h)).value, u, h), o.stop()
        }
    }
    let nv = (t, e) => "zIndex" !== e && !!("number" == typeof t || Array.isArray(t) || "string" == typeof t && (B.test(t) || "0" === t) && !t.startsWith("url("));

    function nx(t) {
        t.duration = 0, t.type = "keyframes"
    }
    let nw = /^(?:oklch|oklab|lab|lch|color|color-mix|light-dark)\(/,
        nT = new Set(["color", "backgroundColor", "outlineColor", "fill", "stroke", "borderColor", "borderTopColor", "borderRightColor", "borderBottomColor", "borderLeftColor"]),
        nb = tq(() => Object.hasOwnProperty.call(Element.prototype, "animate"));
    class nS extends t0 {
        constructor({
            autoplay: t = !0,
            delay: e = 0,
            type: i = "keyframes",
            repeat: n = 0,
            repeatDelay: s = 0,
            repeatType: r = "loop",
            keyframes: o,
            name: a,
            motionValue: l,
            element: h,
            ...u
        }) {
            super(), this.stop = () => {
                this._animation && (this._animation.stop(), this.stopTimeline ? .()), this.keyframeResolver ? .cancel()
            }, this.createdAt = ei.now();
            const d = {
                    autoplay: t,
                    delay: e,
                    type: i,
                    repeat: n,
                    repeatDelay: s,
                    repeatType: r,
                    name: a,
                    motionValue: l,
                    element: h,
                    ...u
                },
                c = h ? .KeyframeResolver || tO;
            this.keyframeResolver = new c(o, (t, e, i) => this.onKeyframesResolved(t, e, d, !i), a, l, h), this.keyframeResolver ? .scheduleResolve()
        }
        onKeyframesResolved(t, e, i, n) {
            let s;
            this.keyframeResolver = void 0;
            let {
                name: r,
                type: o,
                velocity: a,
                delay: l,
                isHandoff: h,
                onUpdate: u
            } = i;
            this.resolvedAt = ei.now();
            let d = !0;
            ! function(t, e, i, n) {
                let s = t[0];
                if (null === s) return !1;
                if ("display" === e || "visibility" === e) return !0;
                let r = t[t.length - 1],
                    o = nv(s, e),
                    a = nv(r, e);
                return te(o === a, `You are trying to animate ${e} from "${s}" to "${r}". "${o?r:s}" is not an animatable value.`, "value-not-animatable"), !!o && !!a && (function(t) {
                    let e = t[0];
                    if (1 === t.length) return !0;
                    for (let i = 0; i < t.length; i++)
                        if (t[i] !== e) return !0
                }(t) || ("spring" === i || t6(i)) && n)
            }(t, r, o, a) && (d = !1, (tA.instantAnimations || !l) && u ? .(tQ(t, i, e)), t[0] = t[t.length - 1], nx(i), i.repeat = 0);
            let c = {
                    startTime: n ? this.resolvedAt && this.resolvedAt - this.createdAt > 40 ? this.resolvedAt : this.createdAt : void 0,
                    finalKeyframe: e,
                    ...i,
                    keyframes: t
                },
                p = d && !h && function(t) {
                    let {
                        motionValue: e,
                        name: i,
                        repeatDelay: n,
                        repeatType: s,
                        damping: r,
                        type: o,
                        keyframes: a
                    } = t;
                    if (!(e ? .owner ? .current instanceof HTMLElement)) return !1;
                    let {
                        onUpdate: l,
                        transformTemplate: h
                    } = e.owner.getProps();
                    return nb() && i && (t7.has(i) || nT.has(i) && function(t) {
                        for (let e = 0; e < t.length; e++)
                            if ("string" == typeof t[e] && nw.test(t[e])) return !0;
                        return !1
                    }(a)) && ("transform" !== i || !h) && !l && !n && "mirror" !== s && 0 !== r && "inertia" !== o
                }(c),
                m = c.motionValue ? .owner ? .current;
            if (p) try {
                s = new ny({ ...c,
                    element: m
                })
            } catch {
                s = new nf(c)
            } else s = new nf(c);
            s.finished.then(() => {
                this.notifyFinished()
            }).catch(tP), this.pendingTimeline && (this.stopTimeline = s.attachTimeline(this.pendingTimeline), this.pendingTimeline = void 0), this._animation = s
        }
        get finished() {
            return this._animation ? this.animation.finished : this._finished
        }
        then(t, e) {
            return this.finished.finally(t).then(() => {})
        }
        get animation() {
            return this._animation || (this.keyframeResolver ? .resume(), tj = !0, tI(), tF(), tj = !1), this._animation
        }
        get duration() {
            return this.animation.duration
        }
        get iterationDuration() {
            return this.animation.iterationDuration
        }
        get time() {
            return this.animation.time
        }
        set time(t) {
            this.animation.time = t
        }
        get speed() {
            return this.animation.speed
        }
        get state() {
            return this.animation.state
        }
        set speed(t) {
            this.animation.speed = t
        }
        get startTime() {
            return this.animation.startTime
        }
        attachTimeline(t) {
            return this._animation ? this.stopTimeline = this.animation.attachTimeline(t) : this.pendingTimeline = t, () => this.stop()
        }
        play() {
            this.animation.play()
        }
        pause() {
            this.animation.pause()
        }
        complete() {
            this.animation.complete()
        }
        cancel() {
            this._animation && this.animation.cancel(), this.keyframeResolver ? .cancel()
        }
    }
    let nP = {
            type: "spring",
            stiffness: 500,
            damping: 25,
            restSpeed: 10
        },
        nA = {
            type: "keyframes",
            duration: .8
        },
        nE = {
            type: "keyframes",
            ease: [.25, .1, .35, 1],
            duration: .3
        },
        nM = new Set(["when", "delay", "delayChildren", "staggerChildren", "staggerDirection", "repeat", "repeatType", "repeatDelay", "from", "elapsed"]),
        nk = (t, e, i, n = {}, s, r) => a => {
            let l = iM(n, t) || {},
                h = l.delay || n.delay || 0,
                {
                    elapsed: u = 0
                } = n;
            u -= tz(h);
            let d = {
                keyframes: Array.isArray(i) ? i : [null, i],
                ease: "easeOut",
                velocity: e.getVelocity(),
                ...l,
                delay: -u,
                onUpdate: t => {
                    e.set(t), l.onUpdate && l.onUpdate(t)
                },
                onComplete: () => {
                    a(), l.onComplete && l.onComplete()
                },
                name: t,
                motionValue: e,
                element: r ? void 0 : s
            };
            ! function(t) {
                for (let e in t)
                    if (!nM.has(e)) return !0;
                return !1
            }(l) && Object.assign(d, ((t, {
                keyframes: e
            }) => e.length > 2 ? nA : o.has(t) ? t.startsWith("scale") ? {
                type: "spring",
                stiffness: 550,
                damping: 0 === e[1] ? 2 * Math.sqrt(550) : 30,
                restSpeed: 10
            } : nP : nE)(t, d)), d.duration && (d.duration = tz(d.duration)), d.repeatDelay && (d.repeatDelay = tz(d.repeatDelay)), void 0 !== d.from && (d.keyframes[0] = d.from);
            let c = !1;
            if (!1 !== d.type && (0 !== d.duration || d.repeatDelay) || (nx(d), 0 === d.delay && (c = !0)), (tA.instantAnimations || tA.skipAnimations || s ? .shouldSkipAnimations) && (c = !0, nx(d), d.delay = 0), d.allowFlatten = !l.type && !l.ease, c && !r && void 0 !== e.get()) {
                let t = tQ(d.keyframes, l);
                if (void 0 !== t) return void tk.update(() => {
                    d.onUpdate(t), d.onComplete()
                })
            }
            return l.isSync ? new nf(d) : new nS(d)
        };

    function nC(t, e, {
        delay: i = 0,
        transitionOverride: n,
        type: s
    } = {}) {
        let {
            transition: r,
            transitionEnd: o,
            ...a
        } = e, l = t.getDefaultTransition();
        r = r ? iE(r, l) : l;
        let h = r ? .reduceMotion;
        n && (r = n);
        let u = [],
            d = s && t.animationState && t.animationState.getState()[s];
        for (let e in a) {
            let n = t.getValue(e, t.latestValues[e] ? ? null),
                s = a[e];
            if (void 0 === s || d && function({
                    protectedKeys: t,
                    needsAnimating: e
                }, i) {
                    let n = t.hasOwnProperty(i) && !0 !== e[i];
                    return e[i] = !1, n
                }(d, e)) continue;
            let o = {
                    delay: i,
                    ...iM(r || {}, e)
                },
                l = n.get();
            if (void 0 !== l && !n.isAnimating() && !Array.isArray(s) && s === l && !o.velocity) {
                tk.update(() => n.set(s));
                continue
            }
            let c = !1;
            if (window.MotionHandoffAnimation) {
                let i = t.props[ix];
                if (i) {
                    let t = window.MotionHandoffAnimation(i, e, tk);
                    null !== t && (o.startTime = t, c = !0)
                }
            }
            iC(t, e);
            let p = h ? ? t.shouldReduceMotion;
            n.start(nk(e, n, s, p && G.has(e) ? {
                type: !1
            } : o, t, c));
            let m = n.animation;
            m && u.push(m)
        }
        if (o) {
            let e = () => tk.update(() => {
                o && function(t, e) {
                    let {
                        transitionEnd: i = {},
                        transition: n = {},
                        ...s
                    } = iA(t, e) || {};
                    for (let e in s = { ...s,
                            ...i
                        }) {
                        var r;
                        let i = ik(r = s[e]) ? r[r.length - 1] || 0 : r;
                        t.hasValue(e) ? t.getValue(e).set(i) : t.addValue(e, es(i))
                    }
                }(t, o)
            });
            u.length ? Promise.all(u).then(e) : e()
        }
        return u
    }

    function nV(t, e, i, n = 0, s = 1) {
        let r = Array.from(t).sort((t, e) => t.sortNodePosition(e)).indexOf(e),
            o = t.size,
            a = (o - 1) * n;
        return "function" == typeof i ? i(r, o) : 1 === s ? r * n : a - r * n
    }

    function nR(t, e, i = {}) {
        let n = iA(t, e, "exit" === i.type ? t.presenceContext ? .custom : void 0),
            {
                transition: s = t.getDefaultTransition() || {}
            } = n || {};
        i.transitionOverride && (s = i.transitionOverride);
        let r = n ? () => Promise.all(nC(t, n, i)) : () => Promise.resolve(),
            o = t.variantChildren && t.variantChildren.size ? (n = 0) => {
                let {
                    delayChildren: r = 0,
                    staggerChildren: o,
                    staggerDirection: a
                } = s;
                return function(t, e, i = 0, n = 0, s = 0, r = 1, o) {
                    let a = [];
                    for (let l of t.variantChildren) l.notify("AnimationStart", e), a.push(nR(l, e, { ...o,
                        delay: i + ("function" == typeof n ? 0 : n) + nV(t.variantChildren, l, n, s, r)
                    }).then(() => l.notify("AnimationComplete", e)));
                    return Promise.all(a)
                }(t, e, n, r, o, a, i)
            } : () => Promise.resolve(),
            {
                when: a
            } = s;
        if (!a) return Promise.all([r(), o(i.delay)]); {
            let [t, e] = "beforeChildren" === a ? [r, o] : [o, r];
            return t().then(() => e())
        }
    }
    let nD = eu.length;

    function nL(t, e) {
        if (!Array.isArray(e)) return !1;
        let i = e.length;
        if (i !== t.length) return !1;
        for (let n = 0; n < i; n++)
            if (e[n] !== t[n]) return !1;
        return !0
    }
    let nB = [...eh].reverse(),
        nj = eh.length;

    function nF(t = !1) {
        return {
            isActive: t,
            protectedKeys: {},
            needsAnimating: {},
            prevResolvedValues: {}
        }
    }

    function nI() {
        return {
            animate: nF(!0),
            whileInView: nF(),
            whileHover: nF(),
            whileTap: nF(),
            whileDrag: nF(),
            whileFocus: nF(),
            exit: nF()
        }
    }
    let nO = 0;

    function nU(t) {
        return [t("x"), t("y")]
    }

    function nW(t, e, i, n = {
        passive: !0
    }) {
        return t.addEventListener(e, i, n), () => t.removeEventListener(e, i)
    }
    let n$ = {
        x: !1,
        y: !1
    };

    function nN(t) {
        return t.max - t.min
    }

    function nz(t, e, i, n = .5) {
        t.origin = n, t.originPoint = eF(e.min, e.max, t.origin), t.scale = nN(i) / nN(e), t.translate = eF(i.min, i.max, t.origin) - t.originPoint, (t.scale >= .9999 && t.scale <= 1.0001 || isNaN(t.scale)) && (t.scale = 1), (t.translate >= -.01 && t.translate <= .01 || isNaN(t.translate)) && (t.translate = 0)
    }

    function nH(t, e, i, n) {
        nz(t.x, e.x, i.x, n ? n.originX : void 0), nz(t.y, e.y, i.y, n ? n.originY : void 0)
    }

    function nY(t, e, i, n = 0) {
        t.min = (n ? eF(i.min, i.max, n) : i.min) + e.min, t.max = t.min + nN(e)
    }

    function nX(t, e, i, n = 0) {
        let s = n ? eF(i.min, i.max, n) : i.min;
        t.min = e.min - s, t.max = t.min + nN(e)
    }

    function nK(t, e, i, n) {
        nX(t.x, e.x, i.x, n ? .x), nX(t.y, e.y, i.y, n ? .y)
    }

    function nq(t) {
        return "object" == typeof t && null !== t
    }

    function nG(t) {
        return nq(t) && "ownerSVGElement" in t
    }

    function nZ(t, e, i) {
        if (null == t) return [];
        if (t instanceof EventTarget) return [t];
        if ("string" == typeof t) {
            let n = document;
            e && (n = e.current);
            let s = i ? .[t] ? ? n.querySelectorAll(t);
            return s ? Array.from(s) : []
        }
        return Array.from(t).filter(t => null != t)
    }
    t.s(["resolveElements", 0, nZ], 749652);
    let n_ = new WeakMap,
        nJ = (t, e, i) => (n, s) => s && s[0] ? s[0][t + "Size"] : nG(n) && "getBBox" in n ? n.getBBox()[e] : n[i],
        nQ = nJ("inline", "width", "offsetWidth"),
        n0 = nJ("block", "height", "offsetHeight");

    function n1({
        target: t,
        borderBoxSize: e
    }) {
        n_.get(t) ? .forEach(i => {
            i(t, {
                get width() {
                    return nQ(t, e)
                },
                get height() {
                    return n0(t, e)
                }
            })
        })
    }

    function n2(t) {
        t.forEach(n1)
    }
    let n3 = new Set;

    function n5(t, e) {
        let i;
        return "function" == typeof t ? (n3.add(t), s || (s = () => {
            let t = {
                get width() {
                    return window.innerWidth
                },
                get height() {
                    return window.innerHeight
                }
            };
            n3.forEach(e => e(t))
        }, window.addEventListener("resize", s)), () => {
            n3.delete(t), n3.size || "function" != typeof s || (window.removeEventListener("resize", s), s = void 0)
        }) : (!n && "u" > typeof ResizeObserver && (n = new ResizeObserver(n2)), (i = nZ(t)).forEach(t => {
            let i = n_.get(t);
            i || (i = new Set, n_.set(t, i)), i.add(e), n ? .observe(t)
        }), () => {
            i.forEach(t => {
                let i = n_.get(t);
                i ? .delete(e), i ? .size || n ? .unobserve(t)
            })
        })
    }
    let n9 = new Set(["BUTTON", "INPUT", "SELECT", "TEXTAREA", "A"]),
        n4 = new Set(["INPUT", "SELECT", "TEXTAREA"]),
        n6 = t => "mouse" === t.pointerType ? "number" != typeof t.button || t.button <= 0 : !1 !== t.isPrimary;

    function n8(t) {
        return {
            point: {
                x: t.pageX,
                y: t.pageY
            }
        }
    }

    function n7(t, e, i, n) {
        return nW(t, e, t => n6(t) && i(t, n8(t)), n)
    }
    let st = ({
            current: t
        }) => t ? t.ownerDocument.defaultView : null,
        se = (t, e) => Math.abs(t - e),
        si = new Set(["auto", "scroll"]);
    class sn {
        constructor(t, e, {
            transformPagePoint: i,
            contextWindow: n = window,
            dragSnapToOrigin: s = !1,
            distanceThreshold: r = 3,
            element: o
        } = {}) {
            if (this.startEvent = null, this.lastMoveEvent = null, this.lastMoveEventInfo = null, this.lastRawMoveEventInfo = null, this.handlers = {}, this.contextWindow = window, this.scrollPositions = new Map, this.removeScrollListeners = null, this.onElementScroll = t => {
                    this.handleScroll(t.target)
                }, this.onWindowScroll = () => {
                    this.handleScroll(window)
                }, this.updatePoint = () => {
                    var t, e;
                    if (!(this.lastMoveEvent && this.lastMoveEventInfo)) return;
                    this.lastRawMoveEventInfo && (this.lastMoveEventInfo = ss(this.lastRawMoveEventInfo, this.transformPagePoint));
                    let i = so(this.lastMoveEventInfo, this.history),
                        n = null !== this.startEvent,
                        s = (t = i.offset, e = {
                            x: 0,
                            y: 0
                        }, Math.sqrt(se(t.x, e.x) ** 2 + se(t.y, e.y) ** 2) >= this.distanceThreshold);
                    if (!n && !s) return;
                    let {
                        point: r
                    } = i, {
                        timestamp: o
                    } = tV;
                    this.history.push({ ...r,
                        timestamp: o
                    });
                    let {
                        onStart: a,
                        onMove: l
                    } = this.handlers;
                    n || (a && a(this.lastMoveEvent, i), this.startEvent = this.lastMoveEvent), l && l(this.lastMoveEvent, i)
                }, this.handlePointerMove = (t, e) => {
                    this.lastMoveEvent = t, this.lastRawMoveEventInfo = e, this.lastMoveEventInfo = ss(e, this.transformPagePoint), tk.update(this.updatePoint, !0)
                }, this.handlePointerUp = (t, e) => {
                    this.end();
                    let {
                        onEnd: i,
                        onSessionEnd: n,
                        resumeAnimation: s
                    } = this.handlers;
                    if ((this.dragSnapToOrigin || !this.startEvent) && s && s(), !(this.lastMoveEvent && this.lastMoveEventInfo)) return;
                    let r = so("pointercancel" === t.type ? this.lastMoveEventInfo : ss(e, this.transformPagePoint), this.history);
                    this.startEvent && i && i(t, r), n && n(t, r)
                }, !n6(t)) return;
            this.dragSnapToOrigin = s, this.handlers = e, this.transformPagePoint = i, this.distanceThreshold = r, this.contextWindow = n || window;
            const a = ss(n8(t), this.transformPagePoint),
                {
                    point: l
                } = a,
                {
                    timestamp: h
                } = tV;
            this.history = [{ ...l,
                timestamp: h
            }];
            const {
                onSessionStart: u
            } = e;
            u && u(t, so(a, this.history)), this.removeListeners = iR(n7(this.contextWindow, "pointermove", this.handlePointerMove), n7(this.contextWindow, "pointerup", this.handlePointerUp), n7(this.contextWindow, "pointercancel", this.handlePointerUp)), o && this.startScrollTracking(o)
        }
        startScrollTracking(t) {
            let e = t.parentElement;
            for (; e;) {
                let t = getComputedStyle(e);
                (si.has(t.overflowX) || si.has(t.overflowY)) && this.scrollPositions.set(e, {
                    x: e.scrollLeft,
                    y: e.scrollTop
                }), e = e.parentElement
            }
            this.scrollPositions.set(window, {
                x: window.scrollX,
                y: window.scrollY
            }), window.addEventListener("scroll", this.onElementScroll, {
                capture: !0
            }), window.addEventListener("scroll", this.onWindowScroll), this.removeScrollListeners = () => {
                window.removeEventListener("scroll", this.onElementScroll, {
                    capture: !0
                }), window.removeEventListener("scroll", this.onWindowScroll)
            }
        }
        handleScroll(t) {
            let e = this.scrollPositions.get(t);
            if (!e) return;
            let i = t === window,
                n = i ? {
                    x: window.scrollX,
                    y: window.scrollY
                } : {
                    x: t.scrollLeft,
                    y: t.scrollTop
                },
                s = {
                    x: n.x - e.x,
                    y: n.y - e.y
                };
            (0 !== s.x || 0 !== s.y) && (i ? this.lastMoveEventInfo && (this.lastMoveEventInfo.point.x += s.x, this.lastMoveEventInfo.point.y += s.y) : this.history.length > 0 && (this.history[0].x -= s.x, this.history[0].y -= s.y), this.scrollPositions.set(t, n), tk.update(this.updatePoint, !0))
        }
        updateHandlers(t) {
            this.handlers = t
        }
        end() {
            this.removeListeners && this.removeListeners(), this.removeScrollListeners && this.removeScrollListeners(), this.scrollPositions.clear(), tC(this.updatePoint)
        }
    }

    function ss(t, e) {
        return e ? {
            point: e(t.point)
        } : t
    }

    function sr(t, e) {
        return {
            x: t.x - e.x,
            y: t.y - e.y
        }
    }

    function so({
        point: t
    }, e) {
        return {
            point: t,
            delta: sr(t, sa(e)),
            offset: sr(t, e[0]),
            velocity: function(t) {
                if (t.length < 2) return {
                    x: 0,
                    y: 0
                };
                let e = t.length - 1,
                    i = null,
                    n = sa(t);
                for (; e >= 0 && (i = t[e], !(n.timestamp - i.timestamp > tz(.1)));) e--;
                if (!i) return {
                    x: 0,
                    y: 0
                };
                i === t[0] && t.length > 2 && n.timestamp - i.timestamp > 2 * tz(.1) && (i = t[1]);
                let s = (n.timestamp - i.timestamp) / 1e3;
                if (0 === s) return {
                    x: 0,
                    y: 0
                };
                let r = {
                    x: (n.x - i.x) / s,
                    y: (n.y - i.y) / s
                };
                return r.x === 1 / 0 && (r.x = 0), r.y === 1 / 0 && (r.y = 0), r
            }(e)
        }
    }

    function sa(t) {
        return t[t.length - 1]
    }

    function sl(t, e, i) {
        return {
            min: void 0 !== e ? t.min + e : void 0,
            max: void 0 !== i ? t.max + i - (t.max - t.min) : void 0
        }
    }

    function sh(t, e) {
        let i = e.min - t.min,
            n = e.max - t.max;
        return e.max - e.min < t.max - t.min && ([i, n] = [n, i]), {
            min: i,
            max: n
        }
    }

    function su(t, e, i) {
        return {
            min: sd(t, e),
            max: sd(t, i)
        }
    }

    function sd(t, e) {
        return "number" == typeof t ? t : t[e] || 0
    }
    let sc = new WeakMap;
    class sp {
        constructor(t) {
            this.openDragLock = null, this.isDragging = !1, this.currentDirection = null, this.originPoint = {
                x: 0,
                y: 0
            }, this.constraints = !1, this.hasMutatedConstraints = !1, this.elastic = K(), this.latestPointerEvent = null, this.latestPanInfo = null, this.visualElement = t
        }
        start(t, {
            snapToCursor: e = !1,
            distanceThreshold: i
        } = {}) {
            let {
                presenceContext: n
            } = this.visualElement;
            if (n && !1 === n.isPresent) return;
            let s = t => {
                    e && this.snapToCursor(n8(t).point), this.stopAnimation()
                },
                r = (t, e) => {
                    let {
                        drag: i,
                        dragPropagation: n,
                        onDragStart: s
                    } = this.getProps();
                    if (i && !n && (this.openDragLock && this.openDragLock(), this.openDragLock = function(t) {
                            if ("x" === t || "y" === t)
                                if (n$[t]) return null;
                                else return n$[t] = !0, () => {
                                    n$[t] = !1
                                };
                            return n$.x || n$.y ? null : (n$.x = n$.y = !0, () => {
                                n$.x = n$.y = !1
                            })
                        }(i), !this.openDragLock)) return;
                    this.latestPointerEvent = t, this.latestPanInfo = e, this.isDragging = !0, this.currentDirection = null, this.resolveConstraints(), this.visualElement.projection && (this.visualElement.projection.isAnimationBlocked = !0, this.visualElement.projection.target = void 0), nU(t => {
                        let e = this.getAxisMotionValue(t).get() || 0;
                        if (T.test(e)) {
                            let {
                                projection: i
                            } = this.visualElement;
                            if (i && i.layout) {
                                let n = i.layout.layoutBox[t];
                                n && (e = nN(n) * (parseFloat(e) / 100))
                            }
                        }
                        this.originPoint[t] = e
                    }), s && tk.update(() => s(t, e), !1, !0), iC(this.visualElement, "transform");
                    let {
                        animationState: r
                    } = this.visualElement;
                    r && r.setActive("whileDrag", !0)
                },
                o = (t, e) => {
                    this.latestPointerEvent = t, this.latestPanInfo = e;
                    let {
                        dragPropagation: i,
                        dragDirectionLock: n,
                        onDirectionLock: s,
                        onDrag: r
                    } = this.getProps();
                    if (!i && !this.openDragLock) return;
                    let {
                        offset: o
                    } = e;
                    if (n && null === this.currentDirection) {
                        this.currentDirection = function(t, e = 10) {
                            let i = null;
                            return Math.abs(t.y) > e ? i = "y" : Math.abs(t.x) > e && (i = "x"), i
                        }(o), null !== this.currentDirection && s && s(this.currentDirection);
                        return
                    }
                    this.updateAxis("x", e.point, o), this.updateAxis("y", e.point, o), this.visualElement.render(), r && tk.update(() => r(t, e), !1, !0)
                },
                a = (t, e) => {
                    this.latestPointerEvent = t, this.latestPanInfo = e, this.stop(t, e), this.latestPointerEvent = null, this.latestPanInfo = null
                },
                l = () => {
                    let {
                        dragSnapToOrigin: t
                    } = this.getProps();
                    (t || this.constraints) && this.startAnimation({
                        x: 0,
                        y: 0
                    })
                },
                {
                    dragSnapToOrigin: h
                } = this.getProps();
            this.panSession = new sn(t, {
                onSessionStart: s,
                onStart: r,
                onMove: o,
                onSessionEnd: a,
                resumeAnimation: l
            }, {
                transformPagePoint: this.visualElement.getTransformPagePoint(),
                dragSnapToOrigin: h,
                distanceThreshold: i,
                contextWindow: st(this.visualElement),
                element: this.visualElement.current
            })
        }
        stop(t, e) {
            let i = t || this.latestPointerEvent,
                n = e || this.latestPanInfo,
                s = this.isDragging;
            if (this.cancel(), !s || !n || !i) return;
            let {
                velocity: r
            } = n;
            this.startAnimation(r);
            let {
                onDragEnd: o
            } = this.getProps();
            o && tk.postRender(() => o(i, n))
        }
        cancel() {
            this.isDragging = !1;
            let {
                projection: t,
                animationState: e
            } = this.visualElement;
            t && (t.isAnimationBlocked = !1), this.endPanSession();
            let {
                dragPropagation: i
            } = this.getProps();
            !i && this.openDragLock && (this.openDragLock(), this.openDragLock = null), e && e.setActive("whileDrag", !1)
        }
        endPanSession() {
            this.panSession && this.panSession.end(), this.panSession = void 0
        }
        updateAxis(t, e, i) {
            let {
                drag: n
            } = this.getProps();
            if (!i || !sf(t, n, this.currentDirection)) return;
            let s = this.getAxisMotionValue(t),
                r = this.originPoint[t] + i[t];
            this.constraints && this.constraints[t] && (r = function(t, {
                min: e,
                max: i
            }, n) {
                return void 0 !== e && t < e ? t = n ? eF(e, t, n.min) : Math.max(t, e) : void 0 !== i && t > i && (t = n ? eF(i, t, n.max) : Math.min(t, i)), t
            }(r, this.constraints[t], this.elastic[t])), s.set(r)
        }
        resolveConstraints() {
            let {
                dragConstraints: t,
                dragElastic: e
            } = this.getProps(), i = this.visualElement.projection && !this.visualElement.projection.layout ? this.visualElement.projection.measure(!1) : this.visualElement.projection ? .layout, n = this.constraints;
            t && iT(t) ? this.constraints || (this.constraints = this.resolveRefConstraints()) : t && i ? this.constraints = function(t, {
                top: e,
                left: i,
                bottom: n,
                right: s
            }) {
                return {
                    x: sl(t.x, i, s),
                    y: sl(t.y, e, n)
                }
            }(i.layoutBox, t) : this.constraints = !1, this.elastic = function(t = .35) {
                return !1 === t ? t = 0 : !0 === t && (t = .35), {
                    x: su(t, "left", "right"),
                    y: su(t, "top", "bottom")
                }
            }(e), n !== this.constraints && !iT(t) && i && this.constraints && !this.hasMutatedConstraints && nU(t => {
                var e, n;
                let s;
                !1 !== this.constraints && this.getAxisMotionValue(t) && (this.constraints[t] = (e = i.layoutBox[t], n = this.constraints[t], s = {}, void 0 !== n.min && (s.min = n.min - e.min), void 0 !== n.max && (s.max = n.max - e.min), s))
            })
        }
        resolveRefConstraints() {
            var t;
            let {
                dragConstraints: e,
                onMeasureDragConstraints: i
            } = this.getProps();
            if (!e || !iT(e)) return !1;
            let n = e.current;
            ti(null !== n, "If `dragConstraints` is set as a React ref, that ref must be passed to another component's `ref` prop.", "drag-constraints-ref");
            let {
                projection: s
            } = this.visualElement;
            if (!s || !s.layout) return !1;
            let r = function(t, e, i) {
                    let n = e0(t, i),
                        {
                            scroll: s
                        } = e;
                    return s && (eZ(n.x, s.offset.x), eZ(n.y, s.offset.y)), n
                }(n, s.root, this.visualElement.getTransformPagePoint()),
                o = (t = s.layout.layoutBox, {
                    x: sh(t.x, r.x),
                    y: sh(t.y, r.y)
                });
            if (i) {
                let t = i(function({
                    x: t,
                    y: e
                }) {
                    return {
                        top: e.min,
                        right: t.max,
                        bottom: e.max,
                        left: t.min
                    }
                }(o));
                this.hasMutatedConstraints = !!t, t && (o = eN(t))
            }
            return o
        }
        startAnimation(t) {
            let {
                drag: e,
                dragMomentum: i,
                dragElastic: n,
                dragTransition: s,
                dragSnapToOrigin: r,
                onDragTransitionEnd: o
            } = this.getProps(), a = this.constraints || {};
            return Promise.all(nU(o => {
                if (!sf(o, e, this.currentDirection)) return;
                let l = a && a[o] || {};
                (!0 === r || r === o) && (l = {
                    min: 0,
                    max: 0
                });
                let h = {
                    type: "inertia",
                    velocity: i ? t[o] : 0,
                    bounceStiffness: n ? 200 : 1e6,
                    bounceDamping: n ? 40 : 1e7,
                    timeConstant: 750,
                    restDelta: 1,
                    restSpeed: 10,
                    ...s,
                    ...l
                };
                return this.startAxisValueAnimation(o, h)
            })).then(o)
        }
        startAxisValueAnimation(t, e) {
            let i = this.getAxisMotionValue(t);
            return iC(this.visualElement, t), i.start(nk(t, i, 0, e, this.visualElement, !1))
        }
        stopAnimation() {
            nU(t => this.getAxisMotionValue(t).stop())
        }
        getAxisMotionValue(t) {
            let e = `_drag${t.toUpperCase()}`,
                i = this.visualElement.getProps();
            return i[e] || this.visualElement.getValue(t, (i.initial ? i.initial[t] : void 0) || 0)
        }
        snapToCursor(t) {
            nU(e => {
                let {
                    drag: i
                } = this.getProps();
                if (!sf(e, i, this.currentDirection)) return;
                let {
                    projection: n
                } = this.visualElement, s = this.getAxisMotionValue(e);
                if (n && n.layout) {
                    let {
                        min: i,
                        max: r
                    } = n.layout.layoutBox[e], o = s.get() || 0;
                    s.set(t[e] - eF(i, r, .5) + o)
                }
            })
        }
        scalePositionWithinConstraints() {
            if (!this.visualElement.current) return;
            let {
                drag: t,
                dragConstraints: e
            } = this.getProps(), {
                projection: i
            } = this.visualElement;
            if (!iT(e) || !i || !this.constraints) return;
            this.stopAnimation();
            let n = {
                x: 0,
                y: 0
            };
            nU(t => {
                let e = this.getAxisMotionValue(t);
                if (e && !1 !== this.constraints) {
                    var i, s;
                    let r, o, l, h = e.get();
                    n[t] = (i = {
                        min: h,
                        max: h
                    }, s = this.constraints[t], r = .5, o = nN(i), (l = nN(s)) > o ? r = nu(s.min, s.max - o, i.min) : o > l && (r = nu(i.min, i.max - l, s.min)), a(0, 1, r))
                }
            });
            let {
                transformTemplate: s
            } = this.visualElement.getProps();
            this.visualElement.current.style.transform = s ? s({}, "") : "none", i.root && i.root.updateScroll(), i.updateLayout(), this.constraints = !1, this.resolveConstraints(), nU(e => {
                if (!sf(e, t, null)) return;
                let i = this.getAxisMotionValue(e),
                    {
                        min: s,
                        max: r
                    } = this.constraints[e];
                i.set(eF(s, r, n[e]))
            }), this.visualElement.render()
        }
        addListeners() {
            let t;
            if (!this.visualElement.current) return;
            sc.set(this.visualElement, this);
            let e = this.visualElement.current,
                i = n7(e, "pointerdown", t => {
                    let {
                        drag: i,
                        dragListener: n = !0
                    } = this.getProps(), s = t.target, r = s !== e && (n4.has(s.tagName) || !0 === s.isContentEditable);
                    i && n && !r && this.start(t)
                }),
                n = () => {
                    var i, n, s;
                    let r, o, {
                        dragConstraints: a
                    } = this.getProps();
                    iT(a) && a.current && (this.constraints = this.resolveRefConstraints(), t || (i = e, n = a.current, r = n5(i, sm(s = () => this.scalePositionWithinConstraints())), o = n5(n, sm(s)), t = () => {
                        r(), o()
                    }))
                },
                {
                    projection: s
                } = this.visualElement,
                r = s.addEventListener("measure", n);
            s && !s.layout && (s.root && s.root.updateScroll(), s.updateLayout()), tk.read(n);
            let o = nW(window, "resize", () => this.scalePositionWithinConstraints()),
                a = s.addEventListener("didUpdate", ({
                    delta: t,
                    hasLayoutChanged: e
                }) => {
                    this.isDragging && e && (nU(e => {
                        let i = this.getAxisMotionValue(e);
                        i && (this.originPoint[e] += t[e].translate, i.set(i.get() + t[e].translate))
                    }), this.visualElement.render())
                });
            return () => {
                o(), i(), r(), a && a(), t && t()
            }
        }
        getProps() {
            let t = this.visualElement.getProps(),
                {
                    drag: e = !1,
                    dragDirectionLock: i = !1,
                    dragPropagation: n = !1,
                    dragConstraints: s = !1,
                    dragElastic: r = .35,
                    dragMomentum: o = !0
                } = t;
            return { ...t,
                drag: e,
                dragDirectionLock: i,
                dragPropagation: n,
                dragConstraints: s,
                dragElastic: r,
                dragMomentum: o
            }
        }
    }

    function sm(t) {
        let e = !0;
        return () => {
            if (e) {
                e = !1;
                return
            }
            t()
        }
    }

    function sf(t, e, i) {
        return (!0 === e || e === t) && (null === i || i === t)
    }
    let sg = t => (e, i) => {
            t && tk.update(() => t(e, i), !1, !0)
        },
        sy = {
            hasAnimatedSinceResize: !0,
            hasEverUpdated: !1
        };
    var sv = e2;

    function sx(t = !0) {
        let e = (0, e2.useContext)(ih);
        if (null === e) return [!0, null];
        let {
            isPresent: i,
            onExitComplete: n,
            register: s
        } = e, r = (0, e2.useId)();
        (0, e2.useEffect)(() => {
            if (t) return s(r)
        }, [t]);
        let o = (0, e2.useCallback)(() => t && n && n(r), [r, n, t]);
        return !i && n ? [!1, o] : [!0]
    }
    let sw = !1;
    class sT extends sv.Component {
        componentDidMount() {
            let {
                visualElement: t,
                layoutGroup: e,
                switchLayoutGroup: i,
                layoutId: n
            } = this.props, {
                projection: s
            } = t;
            s && (e.group && e.group.add(s), i && i.register && n && i.register(s), sw && s.root.didUpdate(), s.addEventListener("animationComplete", () => {
                this.safeToRemove()
            }), s.setOptions({ ...s.options,
                layoutDependency: this.props.layoutDependency,
                onExitComplete: () => this.safeToRemove()
            })), sy.hasEverUpdated = !0
        }
        getSnapshotBeforeUpdate(t) {
            let {
                layoutDependency: e,
                visualElement: i,
                drag: n,
                isPresent: s
            } = this.props, {
                projection: r
            } = i;
            return r && (r.isPresent = s, t.layoutDependency !== e && r.setOptions({ ...r.options,
                layoutDependency: e
            }), sw = !0, n || t.layoutDependency !== e || void 0 === e || t.isPresent !== s ? r.willUpdate() : this.safeToRemove(), t.isPresent !== s && (s ? r.promote() : r.relegate() || tk.postRender(() => {
                let t = r.getStack();
                t && t.members.length || this.safeToRemove()
            }))), null
        }
        componentDidUpdate() {
            let {
                visualElement: t,
                layoutAnchor: e
            } = this.props, {
                projection: i
            } = t;
            i && (i.options.layoutAnchor = e, i.root.didUpdate(), et.postRender(() => {
                !i.currentAnimation && i.isLead() && this.safeToRemove()
            }))
        }
        componentWillUnmount() {
            let {
                visualElement: t,
                layoutGroup: e,
                switchLayoutGroup: i
            } = this.props, {
                projection: n
            } = t;
            sw = !0, n && (n.scheduleCheckAfterUnmount(), e && e.group && e.group.remove(n), i && i.deregister && i.deregister(n))
        }
        safeToRemove() {
            let {
                safeToRemove: t
            } = this.props;
            t && t()
        }
        render() {
            return null
        }
    }

    function sb(t) {
        let [e, i] = sx(), n = (0, sv.useContext)(e4);
        return (0, e9.jsx)(sT, { ...t,
            layoutGroup: n,
            switchLayoutGroup: (0, sv.useContext)(iw),
            isPresent: e,
            safeToRemove: i
        })
    }
    let sS = ["borderTopLeftRadius", "borderTopRightRadius", "borderBottomLeftRadius", "borderBottomRightRadius"],
        sP = sS.length,
        sA = t => "string" == typeof t ? parseFloat(t) : t,
        sE = t => "number" == typeof t || b.test(t);

    function sM(t, e) {
        return void 0 !== t[e] ? t[e] : t.borderRadius
    }
    let sk = sV(0, .5, no),
        sC = sV(.5, .95, tP);

    function sV(t, e, i) {
        return n => n < t ? 0 : n > e ? 1 : i(nu(t, e, n))
    }

    function sR(t, e) {
        t.min = e.min, t.max = e.max
    }

    function sD(t, e) {
        sR(t.x, e.x), sR(t.y, e.y)
    }

    function sL(t, e) {
        t.translate = e.translate, t.scale = e.scale, t.originPoint = e.originPoint, t.origin = e.origin
    }

    function sB(t, e, i, n, s) {
        return t -= e, t = n + 1 / i * (t - n), void 0 !== s && (t = n + 1 / s * (t - n)), t
    }

    function sj(t, e, [i, n, s], r, o) {
        ! function(t, e = 0, i = 1, n = .5, s, r = t, o = t) {
            if (T.test(e) && (e = parseFloat(e), e = eF(o.min, o.max, e / 100) - o.min), "number" != typeof e) return;
            let a = eF(r.min, r.max, n);
            t === r && (a -= e), t.min = sB(t.min, e, i, a, s), t.max = sB(t.max, e, i, a, s)
        }(t, e[i], e[n], e[s], e.scale, r, o)
    }
    let sF = ["x", "scaleX", "originX"],
        sI = ["y", "scaleY", "originY"];

    function sO(t, e, i, n) {
        sj(t.x, e, sF, i ? i.x : void 0, n ? n.x : void 0), sj(t.y, e, sI, i ? i.y : void 0, n ? n.y : void 0)
    }

    function sU(t) {
        return 0 === t.translate && 1 === t.scale
    }

    function sW(t) {
        return sU(t.x) && sU(t.y)
    }

    function s$(t, e) {
        return t.min === e.min && t.max === e.max
    }

    function sN(t, e) {
        return Math.round(t.min) === Math.round(e.min) && Math.round(t.max) === Math.round(e.max)
    }

    function sz(t, e) {
        return sN(t.x, e.x) && sN(t.y, e.y)
    }

    function sH(t) {
        return nN(t.x) / nN(t.y)
    }

    function sY(t, e) {
        return t.translate === e.translate && t.scale === e.scale && t.originPoint === e.originPoint
    }
    class sX {
        constructor() {
            this.members = []
        }
        add(t) {
            tH(this.members, t);
            for (let e = this.members.length - 1; e >= 0; e--) {
                let i = this.members[e];
                if (i === t || i === this.lead || i === this.prevLead) continue;
                let n = i.instance;
                n && !1 !== n.isConnected || i.snapshot || (tY(this.members, i), i.unmount())
            }
            t.scheduleRender()
        }
        remove(t) {
            if (tY(this.members, t), t === this.prevLead && (this.prevLead = void 0), t === this.lead) {
                let t = this.members[this.members.length - 1];
                t && this.promote(t)
            }
        }
        relegate(t) {
            for (let e = this.members.indexOf(t) - 1; e >= 0; e--) {
                let t = this.members[e];
                if (!1 !== t.isPresent && t.instance ? .isConnected !== !1) return this.promote(t), !0
            }
            return !1
        }
        promote(t, e) {
            let i = this.lead;
            if (t !== i && (this.prevLead = i, this.lead = t, t.show(), i)) {
                i.updateSnapshot(), t.scheduleRender();
                let {
                    layoutDependency: n
                } = i.options, {
                    layoutDependency: s
                } = t.options;
                (void 0 === n || n !== s) && (t.resumeFrom = i, e && (i.preserveOpacity = !0), i.snapshot && (t.snapshot = i.snapshot, t.snapshot.latestValues = i.animationValues || i.latestValues), t.root ? .isUpdating && (t.isLayoutDirty = !0)), !1 === t.options.crossfade && i.hide()
            }
        }
        exitAnimationComplete() {
            this.members.forEach(t => {
                t.options.onExitComplete ? .(), t.resumingFrom ? .options.onExitComplete ? .()
            })
        }
        scheduleRender() {
            this.members.forEach(t => t.instance && t.scheduleRender(!1))
        }
        removeLeadSnapshot() {
            this.lead ? .snapshot && (this.lead.snapshot = void 0)
        }
    }
    let sK = (t, e) => t.depth - e.depth;
    class sq {
        constructor() {
            this.children = [], this.isDirty = !1
        }
        add(t) {
            tH(this.children, t), this.isDirty = !0
        }
        remove(t) {
            tY(this.children, t), this.isDirty = !0
        }
        forEach(t) {
            this.isDirty && this.children.sort(sK), this.isDirty = !1, this.children.forEach(t)
        }
    }
    let sG = ["", "X", "Y", "Z"],
        sZ = 0;

    function s_(t, e, i, n) {
        let {
            latestValues: s
        } = e;
        s[t] && (i[t] = s[t], e.setStaticValue(t, 0), n && (n[t] = 0))
    }

    function sJ({
        attachResizeListener: t,
        defaultParent: e,
        measureScroll: i,
        checkIsScrollRoot: n,
        resetTransform: s
    }) {
        return class {
            constructor(t = {}, i = e ? .()) {
                this.id = sZ++, this.animationId = 0, this.animationCommitId = 0, this.children = new Set, this.options = {}, this.isTreeAnimating = !1, this.isAnimationBlocked = !1, this.isLayoutDirty = !1, this.isProjectionDirty = !1, this.isSharedProjectionDirty = !1, this.isTransformDirty = !1, this.updateManuallyBlocked = !1, this.updateBlockedByResize = !1, this.isUpdating = !1, this.isSVG = !1, this.needsReset = !1, this.shouldResetTransform = !1, this.hasCheckedOptimisedAppear = !1, this.treeScale = {
                    x: 1,
                    y: 1
                }, this.eventHandlers = new Map, this.hasTreeAnimated = !1, this.layoutVersion = 0, this.updateScheduled = !1, this.scheduleUpdate = () => this.update(), this.projectionUpdateScheduled = !1, this.checkUpdateFailed = () => {
                    this.isUpdating && (this.isUpdating = !1, this.clearAllSnapshots())
                }, this.updateProjection = () => {
                    this.projectionUpdateScheduled = !1, this.nodes.forEach(s1), this.nodes.forEach(rt), this.nodes.forEach(re), this.nodes.forEach(s2)
                }, this.resolvedRelativeTargetAt = 0, this.linkedParentVersion = 0, this.hasProjected = !1, this.isVisible = !0, this.animationProgress = 0, this.sharedNodes = new Map, this.latestValues = t, this.root = i ? i.root || i : this, this.path = i ? [...i.path, i] : [], this.parent = i, this.depth = i ? i.depth + 1 : 0;
                for (let t = 0; t < this.path.length; t++) this.path[t].shouldResetTransform = !0;
                this.root === this && (this.nodes = new sq)
            }
            addEventListener(t, e) {
                return this.eventHandlers.has(t) || this.eventHandlers.set(t, new tX), this.eventHandlers.get(t).add(e)
            }
            notifyListeners(t, ...e) {
                let i = this.eventHandlers.get(t);
                i && i.notify(...e)
            }
            hasListeners(t) {
                return this.eventHandlers.has(t)
            }
            mount(e) {
                if (this.instance) return;
                this.isSVG = nG(e) && !(nG(e) && "svg" === e.tagName), this.instance = e;
                let {
                    layoutId: i,
                    layout: n,
                    visualElement: s
                } = this.options;
                if (s && !s.current && s.mount(e), this.root.nodes.add(this), this.parent && this.parent.children.add(this), this.root.hasTreeAnimated && (n || i) && (this.isLayoutDirty = !0), t) {
                    let i, n = 0,
                        s = () => this.root.updateBlockedByResize = !1;
                    tk.read(() => {
                        n = window.innerWidth
                    }), t(e, () => {
                        let t = window.innerWidth;
                        if (t !== n) {
                            let e, r;
                            n = t, this.root.updateBlockedByResize = !0, i && i(), e = ei.now(), r = ({
                                timestamp: t
                            }) => {
                                let i = t - e;
                                i >= 250 && (tC(r), s(i - 250))
                            }, tk.setup(r, !0), i = () => tC(r), sy.hasAnimatedSinceResize && (sy.hasAnimatedSinceResize = !1, this.nodes.forEach(s7))
                        }
                    })
                }
                i && this.root.registerSharedNode(i, this), !1 !== this.options.animate && s && (i || n) && this.addEventListener("didUpdate", ({
                    delta: t,
                    hasLayoutChanged: e,
                    hasRelativeLayoutChanged: i,
                    layout: n
                }) => {
                    if (this.isTreeAnimationBlocked()) {
                        this.target = void 0, this.relativeTarget = void 0;
                        return
                    }
                    let r = this.options.transition || s.getDefaultTransition() || ra,
                        {
                            onLayoutAnimationStart: o,
                            onLayoutAnimationComplete: a
                        } = s.getProps(),
                        l = !this.targetLayout || !sz(this.targetLayout, n),
                        h = !e && i;
                    if (this.options.layoutRoot || this.resumeFrom || h || e && (l || !this.currentAnimation)) {
                        this.resumeFrom && (this.resumingFrom = this.resumeFrom, this.resumingFrom.resumingFrom = void 0);
                        let e = { ...iM(r, "layout"),
                            onPlay: o,
                            onComplete: a
                        };
                        (s.shouldReduceMotion || this.options.layoutRoot) && (e.delay = 0, e.type = !1), this.startAnimation(e), this.setAnimationOrigin(t, h)
                    } else e || s7(this), this.isLead() && this.options.onExitComplete && this.options.onExitComplete();
                    this.targetLayout = n
                })
            }
            unmount() {
                this.options.layoutId && this.willUpdate(), this.root.nodes.remove(this);
                let t = this.getStack();
                t && t.remove(this), this.parent && this.parent.children.delete(this), this.instance = void 0, this.eventHandlers.clear(), tC(this.updateProjection)
            }
            blockUpdate() {
                this.updateManuallyBlocked = !0
            }
            unblockUpdate() {
                this.updateManuallyBlocked = !1
            }
            isUpdateBlocked() {
                return this.updateManuallyBlocked || this.updateBlockedByResize
            }
            isTreeAnimationBlocked() {
                return this.isAnimationBlocked || this.parent && this.parent.isTreeAnimationBlocked() || !1
            }
            startUpdate() {
                !this.isUpdateBlocked() && (this.isUpdating = !0, this.nodes && this.nodes.forEach(ri), this.animationId++)
            }
            getTransformTemplate() {
                let {
                    visualElement: t
                } = this.options;
                return t && t.getProps().transformTemplate
            }
            willUpdate(t = !0) {
                if (this.root.hasTreeAnimated = !0, this.root.isUpdateBlocked()) {
                    this.options.onExitComplete && this.options.onExitComplete();
                    return
                }
                if (window.MotionCancelOptimisedAnimation && !this.hasCheckedOptimisedAppear && function t(e) {
                        if (e.hasCheckedOptimisedAppear = !0, e.root === e) return;
                        let {
                            visualElement: i
                        } = e.options;
                        if (!i) return;
                        let n = i.props[ix];
                        if (window.MotionHasOptimisedAnimation(n, "transform")) {
                            let {
                                layout: t,
                                layoutId: i
                            } = e.options;
                            window.MotionCancelOptimisedAnimation(n, "transform", tk, !(t || i))
                        }
                        let {
                            parent: s
                        } = e;
                        s && !s.hasCheckedOptimisedAppear && t(s)
                    }(this), this.root.isUpdating || this.root.startUpdate(), this.isLayoutDirty) return;
                this.isLayoutDirty = !0;
                for (let t = 0; t < this.path.length; t++) {
                    let e = this.path[t];
                    e.shouldResetTransform = !0, ("string" == typeof e.latestValues.x || "string" == typeof e.latestValues.y) && (e.isLayoutDirty = !0), e.updateScroll("snapshot"), e.options.layoutRoot && e.willUpdate(!1)
                }
                let {
                    layoutId: e,
                    layout: i
                } = this.options;
                if (void 0 === e && !i) return;
                let n = this.getTransformTemplate();
                this.prevTransformTemplateValue = n ? n(this.latestValues, "") : void 0, this.updateSnapshot(), t && this.notifyListeners("willUpdate")
            }
            update() {
                if (this.updateScheduled = !1, this.isUpdateBlocked()) {
                    let t = this.updateBlockedByResize;
                    this.unblockUpdate(), this.updateBlockedByResize = !1, this.clearAllSnapshots(), t && this.nodes.forEach(s9), this.nodes.forEach(s5);
                    return
                }
                if (this.animationId <= this.animationCommitId) return void this.nodes.forEach(s4);
                this.animationCommitId = this.animationId, this.isUpdating ? (this.isUpdating = !1, this.nodes.forEach(s6), this.nodes.forEach(s8), this.nodes.forEach(sQ), this.nodes.forEach(s0)) : this.nodes.forEach(s4), this.clearAllSnapshots();
                let t = ei.now();
                tV.delta = a(0, 1e3 / 60, t - tV.timestamp), tV.timestamp = t, tV.isProcessing = !0, tR.update.process(tV), tR.preRender.process(tV), tR.render.process(tV), tV.isProcessing = !1
            }
            didUpdate() {
                this.updateScheduled || (this.updateScheduled = !0, et.read(this.scheduleUpdate))
            }
            clearAllSnapshots() {
                this.nodes.forEach(s3), this.sharedNodes.forEach(rn)
            }
            scheduleUpdateProjection() {
                this.projectionUpdateScheduled || (this.projectionUpdateScheduled = !0, tk.preRender(this.updateProjection, !1, !0))
            }
            scheduleCheckAfterUnmount() {
                tk.postRender(() => {
                    this.isLayoutDirty ? this.root.didUpdate() : this.root.checkUpdateFailed()
                })
            }
            updateSnapshot() {
                !this.snapshot && this.instance && (this.snapshot = this.measure(), !this.snapshot || nN(this.snapshot.measuredBox.x) || nN(this.snapshot.measuredBox.y) || (this.snapshot = void 0))
            }
            updateLayout() {
                if (!this.instance || (this.updateScroll(), !(this.options.alwaysMeasureLayout && this.isLead()) && !this.isLayoutDirty)) return;
                if (this.resumeFrom && !this.resumeFrom.instance)
                    for (let t = 0; t < this.path.length; t++) this.path[t].updateScroll();
                let t = this.layout;
                this.layout = this.measure(!1), this.layoutVersion++, this.layoutCorrected || (this.layoutCorrected = K()), this.isLayoutDirty = !1, this.projectionDelta = void 0, this.notifyListeners("measure", this.layout.layoutBox);
                let {
                    visualElement: e
                } = this.options;
                e && e.notify("LayoutMeasure", this.layout.layoutBox, t ? t.layoutBox : void 0)
            }
            updateScroll(t = "measure") {
                let e = !!(this.options.layoutScroll && this.instance);
                if (this.scroll && this.scroll.animationId === this.root.animationId && this.scroll.phase === t && (e = !1), e && this.instance) {
                    let e = n(this.instance);
                    this.scroll = {
                        animationId: this.root.animationId,
                        phase: t,
                        isRoot: e,
                        offset: i(this.instance),
                        wasRoot: this.scroll ? this.scroll.isRoot : e
                    }
                }
            }
            resetTransform() {
                if (!s) return;
                let t = this.isLayoutDirty || this.shouldResetTransform || this.options.alwaysMeasureLayout,
                    e = this.projectionDelta && !sW(this.projectionDelta),
                    i = this.getTransformTemplate(),
                    n = i ? i(this.latestValues, "") : void 0,
                    r = n !== this.prevTransformTemplateValue;
                t && this.instance && (e || eY(this.latestValues) || r) && (s(this.instance, n), this.shouldResetTransform = !1, this.scheduleRender())
            }
            measure(t = !0) {
                var e;
                let i = this.measurePageBox(),
                    n = this.removeElementScroll(i);
                return t && (n = this.removeTransform(n)), ru((e = n).x), ru(e.y), {
                    animationId: this.root.animationId,
                    measuredBox: i,
                    layoutBox: n,
                    latestValues: {},
                    source: this.id
                }
            }
            measurePageBox() {
                let {
                    visualElement: t
                } = this.options;
                if (!t) return K();
                let e = t.measureViewportBox();
                if (!(this.scroll ? .wasRoot || this.path.some(rc))) {
                    let {
                        scroll: t
                    } = this.root;
                    t && (eZ(e.x, t.offset.x), eZ(e.y, t.offset.y))
                }
                return e
            }
            removeElementScroll(t) {
                let e = K();
                if (sD(e, t), this.scroll ? .wasRoot) return e;
                for (let i = 0; i < this.path.length; i++) {
                    let n = this.path[i],
                        {
                            scroll: s,
                            options: r
                        } = n;
                    n !== this.root && s && r.layoutScroll && (s.wasRoot && sD(e, t), eZ(e.x, s.offset.x), eZ(e.y, s.offset.y))
                }
                return e
            }
            applyTransform(t, e = !1, i) {
                let n = i || K();
                sD(n, t);
                for (let t = 0; t < this.path.length; t++) {
                    let i = this.path[t];
                    !e && i.options.layoutScroll && i.scroll && i !== i.root && (eZ(n.x, -i.scroll.offset.x), eZ(n.y, -i.scroll.offset.y)), eY(i.latestValues) && eQ(n, i.latestValues, i.layout ? .layoutBox)
                }
                return eY(this.latestValues) && eQ(n, this.latestValues, this.layout ? .layoutBox), n
            }
            removeTransform(t) {
                let e = K();
                sD(e, t);
                for (let t = 0; t < this.path.length; t++) {
                    let i, n = this.path[t];
                    eY(n.latestValues) && (n.instance && (eH(n.latestValues) && n.updateSnapshot(), sD(i = K(), n.measurePageBox())), sO(e, n.latestValues, n.snapshot ? .layoutBox, i))
                }
                return eY(this.latestValues) && sO(e, this.latestValues), e
            }
            setTargetDelta(t) {
                this.targetDelta = t, this.root.scheduleUpdateProjection(), this.isProjectionDirty = !0
            }
            setOptions(t) {
                this.options = { ...this.options,
                    ...t,
                    crossfade: void 0 === t.crossfade || t.crossfade
                }
            }
            clearMeasurements() {
                this.scroll = void 0, this.layout = void 0, this.snapshot = void 0, this.prevTransformTemplateValue = void 0, this.targetDelta = void 0, this.target = void 0, this.isLayoutDirty = !1
            }
            forceRelativeParentToResolveTarget() {
                this.relativeParent && this.relativeParent.resolvedRelativeTargetAt !== tV.timestamp && this.relativeParent.resolveTargetDelta(!0)
            }
            resolveTargetDelta(t = !1) {
                let e = this.getLead();
                this.isProjectionDirty || (this.isProjectionDirty = e.isProjectionDirty), this.isTransformDirty || (this.isTransformDirty = e.isTransformDirty), this.isSharedProjectionDirty || (this.isSharedProjectionDirty = e.isSharedProjectionDirty);
                let i = !!this.resumingFrom || this !== e;
                if (!(t || i && this.isSharedProjectionDirty || this.isProjectionDirty || this.parent ? .isProjectionDirty || this.attemptToResolveRelativeTarget || this.root.updateBlockedByResize)) return;
                let {
                    layout: n,
                    layoutId: s
                } = this.options;
                if (!this.layout || !(n || s)) return;
                this.resolvedRelativeTargetAt = tV.timestamp;
                let r = this.getClosestProjectingParent();
                if (r && this.linkedParentVersion !== r.layoutVersion && !r.options.layoutRoot && this.removeRelativeTarget(), this.targetDelta || this.relativeTarget || (!1 !== this.options.layoutAnchor && r && r.layout ? this.createRelativeTarget(r, this.layout.layoutBox, r.layout.layoutBox) : this.removeRelativeTarget()), this.relativeTarget || this.targetDelta) {
                    if (this.target || (this.target = K(), this.targetWithTransforms = K()), this.relativeTarget && this.relativeTargetOrigin && this.relativeParent && this.relativeParent.target) {
                        var o, a, l, h;
                        this.forceRelativeParentToResolveTarget(), o = this.target, a = this.relativeTarget, l = this.relativeParent.target, h = this.options.layoutAnchor || void 0, nY(o.x, a.x, l.x, h ? .x), nY(o.y, a.y, l.y, h ? .y)
                    } else this.targetDelta ? (this.resumingFrom ? this.applyTransform(this.layout.layoutBox, !1, this.target) : sD(this.target, this.layout.layoutBox), eG(this.target, this.targetDelta)) : sD(this.target, this.layout.layoutBox);
                    this.attemptToResolveRelativeTarget && (this.attemptToResolveRelativeTarget = !1, !1 !== this.options.layoutAnchor && r && !!r.resumingFrom == !!this.resumingFrom && !r.options.layoutScroll && r.target && 1 !== this.animationProgress ? this.createRelativeTarget(r, this.target, r.target) : this.relativeParent = this.relativeTarget = void 0)
                }
            }
            getClosestProjectingParent() {
                if (!(!this.parent || eH(this.parent.latestValues) || eX(this.parent.latestValues)))
                    if (this.parent.isProjecting()) return this.parent;
                    else return this.parent.getClosestProjectingParent()
            }
            isProjecting() {
                return !!((this.relativeTarget || this.targetDelta || this.options.layoutRoot) && this.layout)
            }
            createRelativeTarget(t, e, i) {
                this.relativeParent = t, this.linkedParentVersion = t.layoutVersion, this.forceRelativeParentToResolveTarget(), this.relativeTarget = K(), this.relativeTargetOrigin = K(), nK(this.relativeTargetOrigin, e, i, this.options.layoutAnchor || void 0), sD(this.relativeTarget, this.relativeTargetOrigin)
            }
            removeRelativeTarget() {
                this.relativeParent = this.relativeTarget = void 0
            }
            calcProjection() {
                let t = this.getLead(),
                    e = !!this.resumingFrom || this !== t,
                    i = !0;
                if ((this.isProjectionDirty || this.parent ? .isProjectionDirty) && (i = !1), e && (this.isSharedProjectionDirty || this.isTransformDirty) && (i = !1), this.resolvedRelativeTargetAt === tV.timestamp && (i = !1), i) return;
                let {
                    layout: n,
                    layoutId: s
                } = this.options;
                if (this.isTreeAnimating = !!(this.parent && this.parent.isTreeAnimating || this.currentAnimation || this.pendingAnimation), this.isTreeAnimating || (this.targetDelta = this.relativeTarget = void 0), !this.layout || !(n || s)) return;
                sD(this.layoutCorrected, this.layout.layoutBox);
                let r = this.treeScale.x,
                    o = this.treeScale.y;
                ! function(t, e, i, n = !1) {
                    let s, r, o = i.length;
                    if (o) {
                        e.x = e.y = 1;
                        for (let a = 0; a < o; a++) {
                            r = (s = i[a]).projectionDelta;
                            let {
                                visualElement: o
                            } = s.options;
                            (!o || !o.props.style || "contents" !== o.props.style.display) && (n && s.options.layoutScroll && s.scroll && s !== s.root && (eZ(t.x, -s.scroll.offset.x), eZ(t.y, -s.scroll.offset.y)), r && (e.x *= r.x.scale, e.y *= r.y.scale, eG(t, r)), n && eY(s.latestValues) && eQ(t, s.latestValues, s.layout ? .layoutBox))
                        }
                        e.x < 1.0000000000001 && e.x > .999999999999 && (e.x = 1), e.y < 1.0000000000001 && e.y > .999999999999 && (e.y = 1)
                    }
                }(this.layoutCorrected, this.treeScale, this.path, e), t.layout && !t.target && (1 !== this.treeScale.x || 1 !== this.treeScale.y) && (t.target = t.layout.layoutBox, t.targetWithTransforms = K());
                let {
                    target: a
                } = t;
                if (!a) {
                    this.prevProjectionDelta && (this.createProjectionDeltas(), this.scheduleRender());
                    return
                }
                this.projectionDelta && this.prevProjectionDelta ? (sL(this.prevProjectionDelta.x, this.projectionDelta.x), sL(this.prevProjectionDelta.y, this.projectionDelta.y)) : this.createProjectionDeltas(), nH(this.projectionDelta, this.layoutCorrected, a, this.latestValues), this.treeScale.x === r && this.treeScale.y === o && sY(this.projectionDelta.x, this.prevProjectionDelta.x) && sY(this.projectionDelta.y, this.prevProjectionDelta.y) || (this.hasProjected = !0, this.scheduleRender(), this.notifyListeners("projectionUpdate", a))
            }
            hide() {
                this.isVisible = !1
            }
            show() {
                this.isVisible = !0
            }
            scheduleRender(t = !0) {
                if (this.options.visualElement ? .scheduleRender(), t) {
                    let t = this.getStack();
                    t && t.scheduleRender()
                }
                this.resumingFrom && !this.resumingFrom.instance && (this.resumingFrom = void 0)
            }
            createProjectionDeltas() {
                this.prevProjectionDelta = Y(), this.projectionDelta = Y(), this.projectionDeltaWithTransform = Y()
            }
            setAnimationOrigin(t, e = !1) {
                let i, n = this.snapshot,
                    s = n ? n.latestValues : {},
                    r = { ...this.latestValues
                    },
                    o = Y();
                this.relativeParent && this.relativeParent.options.layoutRoot || (this.relativeTarget = this.relativeTargetOrigin = void 0), this.attemptToResolveRelativeTarget = !e;
                let a = K(),
                    l = (n ? n.source : void 0) !== (this.layout ? this.layout.source : void 0),
                    h = this.getStack(),
                    u = !h || h.members.length <= 1,
                    d = !!(l && !u && !0 === this.options.crossfade && !this.path.some(ro));
                this.animationProgress = 0, this.mixTargetDelta = e => {
                    let n = e / 1e3;
                    if (rs(o.x, t.x, n), rs(o.y, t.y, n), this.setTargetDelta(o), this.relativeTarget && this.relativeTargetOrigin && this.layout && this.relativeParent && this.relativeParent.layout) {
                        var h, c, p, m, f, g;
                        nK(a, this.layout.layoutBox, this.relativeParent.layout.layoutBox, this.options.layoutAnchor || void 0), p = this.relativeTarget, m = this.relativeTargetOrigin, f = a, g = n, rr(p.x, m.x, f.x, g), rr(p.y, m.y, f.y, g), i && (h = this.relativeTarget, c = i, s$(h.x, c.x) && s$(h.y, c.y)) && (this.isProjectionDirty = !1), i || (i = K()), sD(i, this.relativeTarget)
                    }
                    l && (this.animationValues = r, function(t, e, i, n, s, r) {
                        s ? (t.opacity = eF(0, i.opacity ? ? 1, sk(n)), t.opacityExit = eF(e.opacity ? ? 1, 0, sC(n))) : r && (t.opacity = eF(e.opacity ? ? 1, i.opacity ? ? 1, n));
                        for (let s = 0; s < sP; s++) {
                            let r = sS[s],
                                o = sM(e, r),
                                a = sM(i, r);
                            (void 0 !== o || void 0 !== a) && (o || (o = 0), a || (a = 0), 0 === o || 0 === a || sE(o) === sE(a) ? (t[r] = Math.max(eF(sA(o), sA(a), n), 0), (T.test(a) || T.test(o)) && (t[r] += "%")) : t[r] = a)
                        }(e.rotate || i.rotate) && (t.rotate = eF(e.rotate || 0, i.rotate || 0, n))
                    }(r, s, this.latestValues, n, d, u)), this.root.scheduleUpdateProjection(), this.scheduleRender(), this.animationProgress = n
                }, this.mixTargetDelta(1e3 * !!this.options.layoutRoot)
            }
            startAnimation(t) {
                this.notifyListeners("animationStart"), this.currentAnimation ? .stop(), this.resumingFrom ? .currentAnimation ? .stop(), this.pendingAnimation && (tC(this.pendingAnimation), this.pendingAnimation = void 0), this.pendingAnimation = tk.update(() => {
                    var e, i, n;
                    let s;
                    sy.hasAnimatedSinceResize = !0, t1.layout++, this.motionValue || (this.motionValue = es(0)), this.motionValue.jump(0, !1), this.currentAnimation = (e = this.motionValue, i = [0, 1e3], n = { ...t,
                        velocity: 0,
                        isSync: !0,
                        onUpdate: e => {
                            this.mixTargetDelta(e), t.onUpdate && t.onUpdate(e)
                        },
                        onStop: () => {
                            t1.layout--
                        },
                        onComplete: () => {
                            t1.layout--, t.onComplete && t.onComplete(), this.completeAnimation()
                        }
                    }, (s = q(e) ? e : es(e)).start(nk("", s, i, n)), s.animation), this.resumingFrom && (this.resumingFrom.currentAnimation = this.currentAnimation), this.pendingAnimation = void 0
                })
            }
            completeAnimation() {
                this.resumingFrom && (this.resumingFrom.currentAnimation = void 0, this.resumingFrom.preserveOpacity = void 0);
                let t = this.getStack();
                t && t.exitAnimationComplete(), this.resumingFrom = this.currentAnimation = this.animationValues = void 0, this.notifyListeners("animationComplete")
            }
            finishAnimation() {
                this.currentAnimation && (this.mixTargetDelta && this.mixTargetDelta(1e3), this.currentAnimation.stop()), this.completeAnimation()
            }
            applyTransformsToTarget() {
                let t = this.getLead(),
                    {
                        targetWithTransforms: e,
                        target: i,
                        layout: n,
                        latestValues: s
                    } = t;
                if (e && i && n) {
                    if (this !== t && this.layout && n && rd(this.options.animationType, this.layout.layoutBox, n.layoutBox)) {
                        i = this.target || K();
                        let e = nN(this.layout.layoutBox.x);
                        i.x.min = t.target.x.min, i.x.max = i.x.min + e;
                        let n = nN(this.layout.layoutBox.y);
                        i.y.min = t.target.y.min, i.y.max = i.y.min + n
                    }
                    sD(e, i), eQ(e, s), nH(this.projectionDeltaWithTransform, this.layoutCorrected, e, s)
                }
            }
            registerSharedNode(t, e) {
                this.sharedNodes.has(t) || this.sharedNodes.set(t, new sX), this.sharedNodes.get(t).add(e);
                let i = e.options.initialPromotionConfig;
                e.promote({
                    transition: i ? i.transition : void 0,
                    preserveFollowOpacity: i && i.shouldPreserveFollowOpacity ? i.shouldPreserveFollowOpacity(e) : void 0
                })
            }
            isLead() {
                let t = this.getStack();
                return !t || t.lead === this
            }
            getLead() {
                let {
                    layoutId: t
                } = this.options;
                return t && this.getStack() ? .lead || this
            }
            getPrevLead() {
                let {
                    layoutId: t
                } = this.options;
                return t ? this.getStack() ? .prevLead : void 0
            }
            getStack() {
                let {
                    layoutId: t
                } = this.options;
                if (t) return this.root.sharedNodes.get(t)
            }
            promote({
                needsReset: t,
                transition: e,
                preserveFollowOpacity: i
            } = {}) {
                let n = this.getStack();
                n && n.promote(this, i), t && (this.projectionDelta = void 0, this.needsReset = !0), e && this.setOptions({
                    transition: e
                })
            }
            relegate() {
                let t = this.getStack();
                return !!t && t.relegate(this)
            }
            resetSkewAndRotation() {
                let {
                    visualElement: t
                } = this.options;
                if (!t) return;
                let e = !1,
                    {
                        latestValues: i
                    } = t;
                if ((i.z || i.rotate || i.rotateX || i.rotateY || i.rotateZ || i.skewX || i.skewY) && (e = !0), !e) return;
                let n = {};
                i.z && s_("z", t, n, this.animationValues);
                for (let e = 0; e < sG.length; e++) s_(`rotate${sG[e]}`, t, n, this.animationValues), s_(`skew${sG[e]}`, t, n, this.animationValues);
                for (let e in t.render(), n) t.setStaticValue(e, n[e]), this.animationValues && (this.animationValues[e] = n[e]);
                t.scheduleRender()
            }
            applyProjectionStyles(t, e) {
                if (!this.instance || this.isSVG) return;
                if (!this.isVisible) {
                    t.visibility = "hidden";
                    return
                }
                let i = this.getTransformTemplate();
                if (this.needsReset) {
                    this.needsReset = !1, t.visibility = "", t.opacity = "", t.pointerEvents = il(e ? .pointerEvents) || "", t.transform = i ? i(this.latestValues, "") : "none";
                    return
                }
                let n = this.getLead();
                if (!this.projectionDelta || !this.layout || !n.target) {
                    this.options.layoutId && (t.opacity = void 0 !== this.latestValues.opacity ? this.latestValues.opacity : 1, t.pointerEvents = il(e ? .pointerEvents) || ""), this.hasProjected && !eY(this.latestValues) && (t.transform = i ? i({}, "") : "none", this.hasProjected = !1);
                    return
                }
                t.visibility = "";
                let s = n.animationValues || n.latestValues;
                this.applyTransformsToTarget();
                let r = function(t, e, i) {
                    let n = "",
                        s = t.x.translate / e.x,
                        r = t.y.translate / e.y,
                        o = i ? .z || 0;
                    if ((s || r || o) && (n = `translate3d(${s}px, ${r}px, ${o}px) `), (1 !== e.x || 1 !== e.y) && (n += `scale(${1/e.x}, ${1/e.y}) `), i) {
                        let {
                            transformPerspective: t,
                            rotate: e,
                            rotateX: s,
                            rotateY: r,
                            skewX: o,
                            skewY: a
                        } = i;
                        t && (n = `perspective(${t}px) ${n}`), e && (n += `rotate(${e}deg) `), s && (n += `rotateX(${s}deg) `), r && (n += `rotateY(${r}deg) `), o && (n += `skewX(${o}deg) `), a && (n += `skewY(${a}deg) `)
                    }
                    let a = t.x.scale * e.x,
                        l = t.y.scale * e.y;
                    return (1 !== a || 1 !== l) && (n += `scale(${a}, ${l})`), n || "none"
                }(this.projectionDeltaWithTransform, this.treeScale, s);
                i && (r = i(s, r)), t.transform = r;
                let {
                    x: o,
                    y: a
                } = this.projectionDelta;
                for (let e in t.transformOrigin = `${100*o.origin}% ${100*a.origin}% 0`, n.animationValues ? t.opacity = n === this ? s.opacity ? ? this.latestValues.opacity ? ? 1 : this.preserveOpacity ? this.latestValues.opacity : s.opacityExit : t.opacity = n === this ? void 0 !== s.opacity ? s.opacity : "" : void 0 !== s.opacityExit ? s.opacityExit : 0, eI) {
                    if (void 0 === s[e]) continue;
                    let {
                        correct: i,
                        applyTo: o,
                        isCSSVariable: a
                    } = eI[e], l = "none" === r ? s[e] : i(s[e], n);
                    if (o) {
                        let e = o.length;
                        for (let i = 0; i < e; i++) t[o[i]] = l
                    } else a ? this.options.visualElement.renderState.vars[e] = l : t[e] = l
                }
                this.options.layoutId && (t.pointerEvents = n === this ? il(e ? .pointerEvents) || "" : "none")
            }
            clearSnapshot() {
                this.resumeFrom = this.snapshot = void 0
            }
            resetTree() {
                this.root.nodes.forEach(t => t.currentAnimation ? .stop()), this.root.nodes.forEach(s5), this.root.sharedNodes.clear()
            }
        }
    }

    function sQ(t) {
        t.updateLayout()
    }

    function s0(t) {
        let e = t.resumeFrom ? .snapshot || t.snapshot;
        if (t.isLead() && t.layout && e && t.hasListeners("didUpdate")) {
            let {
                layoutBox: i,
                measuredBox: n
            } = t.layout, {
                animationType: s
            } = t.options, r = e.source !== t.layout.source;
            if ("size" === s) nU(t => {
                let n = r ? e.measuredBox[t] : e.layoutBox[t],
                    s = nN(n);
                n.min = i[t].min, n.max = n.min + s
            });
            else if ("x" === s || "y" === s) {
                let t = "x" === s ? "y" : "x";
                sR(r ? e.measuredBox[t] : e.layoutBox[t], i[t])
            } else rd(s, e.layoutBox, i) && nU(n => {
                let s = r ? e.measuredBox[n] : e.layoutBox[n],
                    o = nN(i[n]);
                s.max = s.min + o, t.relativeTarget && !t.currentAnimation && (t.isProjectionDirty = !0, t.relativeTarget[n].max = t.relativeTarget[n].min + o)
            });
            let o = Y();
            nH(o, i, e.layoutBox);
            let a = Y();
            r ? nH(a, t.applyTransform(n, !0), e.measuredBox) : nH(a, i, e.layoutBox);
            let l = !sW(o),
                h = !1;
            if (!t.resumeFrom) {
                let n = t.getClosestProjectingParent();
                if (n && !n.resumeFrom) {
                    let {
                        snapshot: s,
                        layout: r
                    } = n;
                    if (s && r) {
                        let o = t.options.layoutAnchor || void 0,
                            a = K();
                        nK(a, e.layoutBox, s.layoutBox, o);
                        let l = K();
                        nK(l, i, r.layoutBox, o), sz(a, l) || (h = !0), n.options.layoutRoot && (t.relativeTarget = l, t.relativeTargetOrigin = a, t.relativeParent = n)
                    }
                }
            }
            t.notifyListeners("didUpdate", {
                layout: i,
                snapshot: e,
                delta: a,
                layoutDelta: o,
                hasLayoutChanged: l,
                hasRelativeLayoutChanged: h
            })
        } else if (t.isLead()) {
            let {
                onExitComplete: e
            } = t.options;
            e && e()
        }
        t.options.transition = void 0
    }

    function s1(t) {
        t.parent && (t.isProjecting() || (t.isProjectionDirty = t.parent.isProjectionDirty), t.isSharedProjectionDirty || (t.isSharedProjectionDirty = !!(t.isProjectionDirty || t.parent.isProjectionDirty || t.parent.isSharedProjectionDirty)), t.isTransformDirty || (t.isTransformDirty = t.parent.isTransformDirty))
    }

    function s2(t) {
        t.isProjectionDirty = t.isSharedProjectionDirty = t.isTransformDirty = !1
    }

    function s3(t) {
        t.clearSnapshot()
    }

    function s5(t) {
        t.clearMeasurements()
    }

    function s9(t) {
        t.isLayoutDirty = !0, t.updateLayout()
    }

    function s4(t) {
        t.isLayoutDirty = !1
    }

    function s6(t) {
        t.isAnimationBlocked && t.layout && !t.isLayoutDirty && (t.snapshot = t.layout, t.isLayoutDirty = !0)
    }

    function s8(t) {
        let {
            visualElement: e
        } = t.options;
        e && e.getProps().onBeforeLayoutMeasure && e.notify("BeforeLayoutMeasure"), t.resetTransform()
    }

    function s7(t) {
        t.finishAnimation(), t.targetDelta = t.relativeTarget = t.target = void 0, t.isProjectionDirty = !0
    }

    function rt(t) {
        t.resolveTargetDelta()
    }

    function re(t) {
        t.calcProjection()
    }

    function ri(t) {
        t.resetSkewAndRotation()
    }

    function rn(t) {
        t.removeLeadSnapshot()
    }

    function rs(t, e, i) {
        t.translate = eF(e.translate, 0, i), t.scale = eF(e.scale, 1, i), t.origin = e.origin, t.originPoint = e.originPoint
    }

    function rr(t, e, i, n) {
        t.min = eF(e.min, i.min, n), t.max = eF(e.max, i.max, n)
    }

    function ro(t) {
        return t.animationValues && void 0 !== t.animationValues.opacityExit
    }
    let ra = {
            duration: .45,
            ease: [.4, 0, .1, 1]
        },
        rl = t => "u" > typeof navigator && navigator.userAgent && navigator.userAgent.toLowerCase().includes(t),
        rh = rl("applewebkit/") && !rl("chrome/") ? Math.round : tP;

    function ru(t) {
        t.min = rh(t.min), t.max = rh(t.max)
    }

    function rd(t, e, i) {
        return "position" === t || "preserve-aspect" === t && !(.2 >= Math.abs(sH(e) - sH(i)))
    }

    function rc(t) {
        return t !== t.root && t.scroll ? .wasRoot
    }
    let rp = sJ({
            attachResizeListener: (t, e) => nW(t, "resize", e),
            measureScroll: () => ({
                x: document.documentElement.scrollLeft || document.body ? .scrollLeft || 0,
                y: document.documentElement.scrollTop || document.body ? .scrollTop || 0
            }),
            checkIsScrollRoot: () => !0
        }),
        rm = {
            current: void 0
        },
        rf = sJ({
            measureScroll: t => ({
                x: t.scrollLeft,
                y: t.scrollTop
            }),
            defaultParent: () => {
                if (!rm.current) {
                    let t = new rp({});
                    t.mount(window), t.setOptions({
                        layoutScroll: !0
                    }), rm.current = t
                }
                return rm.current
            },
            resetTransform: (t, e) => {
                t.style.transform = void 0 !== e ? e : "none"
            },
            checkIsScrollRoot: t => "fixed" === window.getComputedStyle(t).position
        });

    function rg(t, e) {
        let i = nZ(t),
            n = new AbortController;
        return [i, {
            passive: !0,
            ...e,
            signal: n.signal
        }, () => n.abort()]
    }

    function ry(t, e, i) {
        let {
            props: n
        } = t;
        t.animationState && n.whileHover && t.animationState.setActive("whileHover", "Start" === i);
        let s = n["onHover" + i];
        s && tk.postRender(() => s(e, n8(e)))
    }

    function rv(t) {
        return nq(t) && "offsetHeight" in t && !("ownerSVGElement" in t)
    }
    let rx = (t, e) => !!e && (t === e || rx(t, e.parentElement)),
        rw = new WeakSet;

    function rT(t) {
        return e => {
            "Enter" === e.key && t(e)
        }
    }

    function rb(t, e) {
        t.dispatchEvent(new PointerEvent("pointer" + e, {
            isPrimary: !0,
            bubbles: !0
        }))
    }

    function rS(t) {
        return n6(t) && !(n$.x || n$.y)
    }
    let rP = new WeakSet;

    function rA(t, e, i) {
        let {
            props: n
        } = t;
        if (t.current instanceof HTMLButtonElement && t.current.disabled) return;
        t.animationState && n.whileTap && t.animationState.setActive("whileTap", "Start" === i);
        let s = n["onTap" + ("End" === i ? "" : i)];
        s && tk.postRender(() => s(e, n8(e)))
    }
    let rE = new WeakMap,
        rM = new WeakMap,
        rk = t => {
            let e = rE.get(t.target);
            e && e(t)
        },
        rC = t => {
            t.forEach(rk)
        },
        rV = {
            some: 0,
            all: 1
        },
        rR = function(t, e) {
            if ("u" < typeof Proxy) return iS;
            let i = new Map,
                n = (i, n) => iS(i, n, t, e);
            return new Proxy((t, e) => n(t, e), {
                get: (s, r) => "create" === r ? n : (i.has(r) || i.set(r, iS(r, void 0, t, e)), i.get(r))
            })
        }({
            animation: {
                Feature: class extends iP {
                    constructor(t) {
                        super(t), t.animationState || (t.animationState = function(t) {
                            let e = e => Promise.all(e.map(({
                                    animation: e,
                                    options: i
                                }) => (function(t, e, i = {}) {
                                    let n;
                                    if (t.notify("AnimationStart", e), Array.isArray(e)) n = Promise.all(e.map(e => nR(t, e, i)));
                                    else if ("string" == typeof e) n = nR(t, e, i);
                                    else {
                                        let s = "function" == typeof e ? iA(t, e, i.custom) : e;
                                        n = Promise.all(nC(t, s, i))
                                    }
                                    return n.then(() => {
                                        t.notify("AnimationComplete", e)
                                    })
                                })(t, e, i))),
                                i = nI(),
                                n = !0,
                                s = !1,
                                r = e => (i, n) => {
                                    let s = iA(t, n, "exit" === e ? t.presenceContext ? .custom : void 0);
                                    if (s) {
                                        let {
                                            transition: t,
                                            transitionEnd: e,
                                            ...n
                                        } = s;
                                        i = { ...i,
                                            ...n,
                                            ...e
                                        }
                                    }
                                    return i
                                };

                            function o(o) {
                                let {
                                    props: a
                                } = t, l = function t(e) {
                                    if (!e) return;
                                    if (!e.isControllingVariants) {
                                        let i = e.parent && t(e.parent) || {};
                                        return void 0 !== e.props.initial && (i.initial = e.props.initial), i
                                    }
                                    let i = {};
                                    for (let t = 0; t < nD; t++) {
                                        let n = eu[t],
                                            s = e.props[n];
                                        (el(s) || !1 === s) && (i[n] = s)
                                    }
                                    return i
                                }(t.parent) || {}, h = [], u = new Set, d = {}, c = 1 / 0;
                                for (let e = 0; e < nj; e++) {
                                    var p, m;
                                    let f = nB[e],
                                        g = i[f],
                                        y = void 0 !== a[f] ? a[f] : l[f],
                                        v = el(y),
                                        x = f === o ? g.isActive : null;
                                    !1 === x && (c = e);
                                    let w = y === l[f] && y !== a[f] && v;
                                    if (w && (n || s) && t.manuallyAnimateOnMount && (w = !1), g.protectedKeys = { ...d
                                        }, !g.isActive && null === x || !y && !g.prevProp || ea(y) || "boolean" == typeof y) continue;
                                    if ("exit" === f && g.isActive && !0 !== x) {
                                        g.prevResolvedValues && (d = { ...d,
                                            ...g.prevResolvedValues
                                        });
                                        continue
                                    }
                                    let T = (p = g.prevProp, "string" == typeof(m = y) ? m !== p : !!Array.isArray(m) && !nL(m, p)),
                                        b = T || f === o && g.isActive && !w && v || e > c && v,
                                        S = !1,
                                        P = Array.isArray(y) ? y : [y],
                                        A = P.reduce(r(f), {});
                                    !1 === x && (A = {});
                                    let {
                                        prevResolvedValues: E = {}
                                    } = g, M = { ...E,
                                        ...A
                                    }, k = e => {
                                        b = !0, u.has(e) && (S = !0, u.delete(e)), g.needsAnimating[e] = !0;
                                        let i = t.getValue(e);
                                        i && (i.liveStyle = !1)
                                    };
                                    for (let t in M) {
                                        let e = A[t],
                                            i = E[t];
                                        if (!d.hasOwnProperty(t))(ik(e) && ik(i) ? nL(e, i) : e === i) ? void 0 !== e && u.has(t) ? k(t) : g.protectedKeys[t] = !0 : null != e ? k(t) : u.add(t)
                                    }
                                    g.prevProp = y, g.prevResolvedValues = A, g.isActive && (d = { ...d,
                                        ...A
                                    }), (n || s) && t.blockInitialAnimation && (b = !1);
                                    let C = w && T,
                                        V = !C || S;
                                    b && V && h.push(...P.map(e => {
                                        let i = {
                                            type: f
                                        };
                                        if ("string" == typeof e && (n || s) && !C && t.manuallyAnimateOnMount && t.parent) {
                                            let {
                                                parent: n
                                            } = t, s = iA(n, e);
                                            if (n.enteringChildren && s) {
                                                let {
                                                    delayChildren: e
                                                } = s.transition || {};
                                                i.delay = nV(n.enteringChildren, t, e)
                                            }
                                        }
                                        return {
                                            animation: e,
                                            options: i
                                        }
                                    }))
                                }
                                if (u.size) {
                                    let e = {};
                                    if ("boolean" != typeof a.initial) {
                                        let i = iA(t, Array.isArray(a.initial) ? a.initial[0] : a.initial);
                                        i && i.transition && (e.transition = i.transition)
                                    }
                                    u.forEach(i => {
                                        let n = t.getBaseTarget(i),
                                            s = t.getValue(i);
                                        s && (s.liveStyle = !0), e[i] = n ? ? null
                                    }), h.push({
                                        animation: e
                                    })
                                }
                                let f = !!h.length;
                                return n && (!1 === a.initial || a.initial === a.animate) && !t.manuallyAnimateOnMount && (f = !1), n = !1, s = !1, f ? e(h) : Promise.resolve()
                            }
                            return {
                                animateChanges: o,
                                setActive: function(e, n) {
                                    if (i[e].isActive === n) return Promise.resolve();
                                    t.variantChildren ? .forEach(t => t.animationState ? .setActive(e, n)), i[e].isActive = n;
                                    let s = o(e);
                                    for (let t in i) i[t].protectedKeys = {};
                                    return s
                                },
                                setAnimateFunction: function(i) {
                                    e = i(t)
                                },
                                getState: () => i,
                                reset: () => {
                                    i = nI(), s = !0
                                }
                            }
                        }(t))
                    }
                    updateAnimationControlsSubscription() {
                        let {
                            animate: t
                        } = this.node.getProps();
                        ea(t) && (this.unmountControls = t.subscribe(this.node))
                    }
                    mount() {
                        this.updateAnimationControlsSubscription()
                    }
                    update() {
                        let {
                            animate: t
                        } = this.node.getProps(), {
                            animate: e
                        } = this.node.prevProps || {};
                        t !== e && this.updateAnimationControlsSubscription()
                    }
                    unmount() {
                        this.node.animationState.reset(), this.unmountControls ? .()
                    }
                }
            },
            exit: {
                Feature: class extends iP {
                    constructor() {
                        super(...arguments), this.id = nO++, this.isExitComplete = !1
                    }
                    update() {
                        if (!this.node.presenceContext) return;
                        let {
                            isPresent: t,
                            onExitComplete: e
                        } = this.node.presenceContext, {
                            isPresent: i
                        } = this.node.prevPresenceContext || {};
                        if (!this.node.animationState || t === i) return;
                        if (t && !1 === i) {
                            if (this.isExitComplete) {
                                let {
                                    initial: t,
                                    custom: e
                                } = this.node.getProps();
                                if ("string" == typeof t) {
                                    let i = iA(this.node, t, e);
                                    if (i) {
                                        let {
                                            transition: t,
                                            transitionEnd: e,
                                            ...n
                                        } = i;
                                        for (let t in n) this.node.getValue(t) ? .jump(n[t])
                                    }
                                }
                                this.node.animationState.reset(), this.node.animationState.animateChanges()
                            } else this.node.animationState.setActive("exit", !1);
                            this.isExitComplete = !1;
                            return
                        }
                        let n = this.node.animationState.setActive("exit", !t);
                        e && !t && n.then(() => {
                            this.isExitComplete = !0, e(this.id)
                        })
                    }
                    mount() {
                        let {
                            register: t,
                            onExitComplete: e
                        } = this.node.presenceContext || {};
                        e && e(this.id), t && (this.unmount = t(this.id))
                    }
                    unmount() {}
                }
            },
            inView: {
                Feature: class extends iP {
                    constructor() {
                        super(...arguments), this.hasEnteredView = !1, this.isInView = !1
                    }
                    startObserver() {
                        var t;
                        let e;
                        this.stopObserver ? .();
                        let {
                            viewport: i = {}
                        } = this.node.getProps(), {
                            root: n,
                            margin: s,
                            amount: r = "some",
                            once: o
                        } = i, a = {
                            root: n ? n.current : void 0,
                            rootMargin: s,
                            threshold: "number" == typeof r ? r : rV[r]
                        }, l = t => {
                            let {
                                isIntersecting: e
                            } = t;
                            if (this.isInView === e || (this.isInView = e, o && !e && this.hasEnteredView)) return;
                            e && (this.hasEnteredView = !0), this.node.animationState && this.node.animationState.setActive("whileInView", e);
                            let {
                                onViewportEnter: i,
                                onViewportLeave: n
                            } = this.node.getProps(), s = e ? i : n;
                            s && s(t)
                        };
                        this.stopObserver = (t = this.node.current, e = function({
                            root: t,
                            ...e
                        }) {
                            let i = t || document;
                            rM.has(i) || rM.set(i, {});
                            let n = rM.get(i),
                                s = JSON.stringify(e);
                            return n[s] || (n[s] = new IntersectionObserver(rC, {
                                root: t,
                                ...e
                            })), n[s]
                        }(a), rE.set(t, l), e.observe(t), () => {
                            rE.delete(t), e.unobserve(t)
                        })
                    }
                    mount() {
                        this.startObserver()
                    }
                    update() {
                        if ("u" < typeof IntersectionObserver) return;
                        let {
                            props: t,
                            prevProps: e
                        } = this.node;
                        ["amount", "margin", "root"].some(function({
                            viewport: t = {}
                        }, {
                            viewport: e = {}
                        } = {}) {
                            return i => t[i] !== e[i]
                        }(t, e)) && this.startObserver()
                    }
                    unmount() {
                        this.stopObserver ? .(), this.hasEnteredView = !1, this.isInView = !1
                    }
                }
            },
            tap: {
                Feature: class extends iP {
                    mount() {
                        let {
                            current: t
                        } = this.node;
                        if (!t) return;
                        let {
                            globalTapTarget: e,
                            propagate: i
                        } = this.node.props;
                        this.unmount = function(t, e, i = {}) {
                            let [n, s, r] = rg(t, i), o = t => {
                                let n = t.currentTarget;
                                if (!rS(t) || rP.has(t)) return;
                                rw.add(n), i.stopPropagation && rP.add(t);
                                let r = e(n, t),
                                    o = (t, e) => {
                                        window.removeEventListener("pointerup", a), window.removeEventListener("pointercancel", l), rw.has(n) && rw.delete(n), rS(t) && "function" == typeof r && r(t, {
                                            success: e
                                        })
                                    },
                                    a = t => {
                                        o(t, n === window || n === document || i.useGlobalTarget || rx(n, t.target))
                                    },
                                    l = t => {
                                        o(t, !1)
                                    };
                                window.addEventListener("pointerup", a, s), window.addEventListener("pointercancel", l, s)
                            };
                            return n.forEach(t => {
                                ((i.useGlobalTarget ? window : t).addEventListener("pointerdown", o, s), rv(t)) && (t.addEventListener("focus", t => ((t, e) => {
                                    let i = t.currentTarget;
                                    if (!i) return;
                                    let n = rT(() => {
                                        if (rw.has(i)) return;
                                        rb(i, "down");
                                        let t = rT(() => {
                                            rb(i, "up")
                                        });
                                        i.addEventListener("keyup", t, e), i.addEventListener("blur", () => rb(i, "cancel"), e)
                                    });
                                    i.addEventListener("keydown", n, e), i.addEventListener("blur", () => i.removeEventListener("keydown", n), e)
                                })(t, s)), n9.has(t.tagName) || !0 === t.isContentEditable || t.hasAttribute("tabindex") || (t.tabIndex = 0))
                            }), r
                        }(t, (t, e) => (rA(this.node, e, "Start"), (t, {
                            success: e
                        }) => rA(this.node, t, e ? "End" : "Cancel")), {
                            useGlobalTarget: e,
                            stopPropagation: i ? .tap === !1
                        })
                    }
                    unmount() {}
                }
            },
            focus: {
                Feature: class extends iP {
                    constructor() {
                        super(...arguments), this.isActive = !1
                    }
                    onFocus() {
                        let t = !1;
                        try {
                            t = this.node.current.matches(":focus-visible")
                        } catch (e) {
                            t = !0
                        }
                        t && this.node.animationState && (this.node.animationState.setActive("whileFocus", !0), this.isActive = !0)
                    }
                    onBlur() {
                        this.isActive && this.node.animationState && (this.node.animationState.setActive("whileFocus", !1), this.isActive = !1)
                    }
                    mount() {
                        this.unmount = iR(nW(this.node.current, "focus", () => this.onFocus()), nW(this.node.current, "blur", () => this.onBlur()))
                    }
                    unmount() {}
                }
            },
            hover: {
                Feature: class extends iP {
                    mount() {
                        let {
                            current: t
                        } = this.node;
                        t && (this.unmount = function(t, e, i = {}) {
                            let [n, s, r] = rg(t, i);
                            return n.forEach(t => {
                                let i, n = !1,
                                    r = !1,
                                    o = e => {
                                        i && (i(e), i = void 0), t.removeEventListener("pointerleave", l)
                                    },
                                    a = t => {
                                        n = !1, window.removeEventListener("pointerup", a), window.removeEventListener("pointercancel", a), r && (r = !1, o(t))
                                    },
                                    l = t => {
                                        if ("touch" !== t.pointerType) {
                                            if (n) {
                                                r = !0;
                                                return
                                            }
                                            o(t)
                                        }
                                    };
                                t.addEventListener("pointerenter", n => {
                                    if ("touch" === n.pointerType || n$.x || n$.y) return;
                                    r = !1;
                                    let o = e(t, n);
                                    "function" == typeof o && (i = o, t.addEventListener("pointerleave", l, s))
                                }, s), t.addEventListener("pointerdown", () => {
                                    n = !0, window.addEventListener("pointerup", a, s), window.addEventListener("pointercancel", a, s)
                                }, s)
                            }), r
                        }(t, (t, e) => (ry(this.node, e, "Start"), t => ry(this.node, t, "End"))))
                    }
                    unmount() {}
                }
            },
            pan: {
                Feature: class extends iP {
                    constructor() {
                        super(...arguments), this.removePointerDownListener = tP
                    }
                    onPointerDown(t) {
                        this.session = new sn(t, this.createPanHandlers(), {
                            transformPagePoint: this.node.getTransformPagePoint(),
                            contextWindow: st(this.node)
                        })
                    }
                    createPanHandlers() {
                        let {
                            onPanSessionStart: t,
                            onPanStart: e,
                            onPan: i,
                            onPanEnd: n
                        } = this.node.getProps();
                        return {
                            onSessionStart: sg(t),
                            onStart: sg(e),
                            onMove: sg(i),
                            onEnd: (t, e) => {
                                delete this.session, n && tk.postRender(() => n(t, e))
                            }
                        }
                    }
                    mount() {
                        this.removePointerDownListener = n7(this.node.current, "pointerdown", t => this.onPointerDown(t))
                    }
                    update() {
                        this.session && this.session.updateHandlers(this.createPanHandlers())
                    }
                    unmount() {
                        this.removePointerDownListener(), this.session && this.session.end()
                    }
                }
            },
            drag: {
                Feature: class extends iP {
                    constructor(t) {
                        super(t), this.removeGroupControls = tP, this.removeListeners = tP, this.controls = new sp(t)
                    }
                    mount() {
                        let {
                            dragControls: t
                        } = this.node.getProps();
                        t && (this.removeGroupControls = t.subscribe(this.controls)), this.removeListeners = this.controls.addListeners() || tP
                    }
                    update() {
                        let {
                            dragControls: t
                        } = this.node.getProps(), {
                            dragControls: e
                        } = this.node.prevProps || {};
                        t !== e && (this.removeGroupControls(), t && (this.removeGroupControls = t.subscribe(this.controls)))
                    }
                    unmount() {
                        this.removeGroupControls(), this.removeListeners(), this.controls.isDragging || this.controls.endPanSession()
                    }
                },
                ProjectionNode: rf,
                MeasureLayout: sb
            },
            layout: {
                ProjectionNode: rf,
                MeasureLayout: sb
            }
        }, (t, e) => e.isSVG ? ? e5(t) ? new e$(e) : new e1(e, {
            allowProjection: t !== e2.Fragment
        }));
    t.s(["motion", 0, rR], 846932);
    var rD = e2;

    function rL(t, e) {
        if ("function" == typeof t) return t(e);
        null != t && (t.current = e)
    }
    class rB extends rD.Component {
        getSnapshotBeforeUpdate(t) {
            let e = this.props.childRef.current;
            if (rv(e) && t.isPresent && !this.props.isPresent && !1 !== this.props.pop) {
                let t = e.offsetParent,
                    i = rv(t) && t.offsetWidth || 0,
                    n = rv(t) && t.offsetHeight || 0,
                    s = getComputedStyle(e),
                    r = this.props.sizeRef.current;
                r.height = parseFloat(s.height), r.width = parseFloat(s.width), r.top = e.offsetTop, r.left = e.offsetLeft, r.right = i - r.width - r.left, r.bottom = n - r.height - r.top
            }
            return null
        }
        componentDidUpdate() {}
        render() {
            return this.props.children
        }
    }

    function rj({
        children: t,
        isPresent: e,
        anchorX: i,
        anchorY: n,
        root: s,
        pop: r
    }) {
        let o = (0, rD.useId)(),
            a = (0, rD.useRef)(null),
            l = (0, rD.useRef)({
                width: 0,
                height: 0,
                top: 0,
                left: 0,
                right: 0,
                bottom: 0
            }),
            {
                nonce: h
            } = (0, rD.useContext)(e8),
            u = function(...t) {
                return e2.useCallback(function(...t) {
                    return e => {
                        let i = !1,
                            n = t.map(t => {
                                let n = rL(t, e);
                                return i || "function" != typeof n || (i = !0), n
                            });
                        if (i) return () => {
                            for (let e = 0; e < n.length; e++) {
                                let i = n[e];
                                "function" == typeof i ? i() : rL(t[e], null)
                            }
                        }
                    }
                }(...t), t)
            }(a, t.props ? .ref ? ? t ? .ref);
        return (0, rD.useInsertionEffect)(() => {
            let {
                width: t,
                height: u,
                top: d,
                left: c,
                right: p,
                bottom: m
            } = l.current;
            if (e || !1 === r || !a.current || !t || !u) return;
            let f = "left" === i ? `left: ${c}` : `right: ${p}`,
                g = "bottom" === n ? `bottom: ${m}` : `top: ${d}`;
            a.current.dataset.motionPopId = o;
            let y = document.createElement("style");
            h && (y.nonce = h);
            let v = s ? ? document.head;
            return v.appendChild(y), y.sheet && y.sheet.insertRule(`
          [data-motion-pop-id="${o}"] {
            position: absolute !important;
            width: ${t}px !important;
            height: ${u}px !important;
            ${f}px !important;
            ${g}px !important;
          }
        `), () => {
                a.current ? .removeAttribute("data-motion-pop-id"), v.contains(y) && v.removeChild(y)
            }
        }, [e]), (0, e9.jsx)(rB, {
            isPresent: e,
            childRef: a,
            sizeRef: l,
            pop: r,
            children: !1 === r ? t : rD.cloneElement(t, {
                ref: u
            })
        })
    }
    let rF = ({
        children: t,
        initial: e,
        isPresent: i,
        onExitComplete: n,
        custom: s,
        presenceAffectsLayout: r,
        mode: o,
        anchorX: a,
        anchorY: l,
        root: h
    }) => {
        let u = iu(rI),
            d = (0, e2.useId)(),
            c = !0,
            p = (0, e2.useMemo)(() => (c = !1, {
                id: d,
                initial: e,
                isPresent: i,
                custom: s,
                onExitComplete: t => {
                    for (let e of (u.set(t, !0), u.values()))
                        if (!e) return;
                    n && n()
                },
                register: t => (u.set(t, !1), () => u.delete(t))
            }), [i, u, n]);
        return r && c && (p = { ...p
        }), (0, e2.useMemo)(() => {
            u.forEach((t, e) => u.set(e, !1))
        }, [i]), e2.useEffect(() => {
            i || u.size || !n || n()
        }, [i]), t = (0, e9.jsx)(rj, {
            pop: "popLayout" === o,
            isPresent: i,
            anchorX: a,
            anchorY: l,
            root: h,
            children: t
        }), (0, e9.jsx)(ih.Provider, {
            value: p,
            children: t
        })
    };

    function rI() {
        return new Map
    }
    let rO = t => t.key || "";

    function rU(t) {
        let e = [];
        return e2.Children.forEach(t, t => {
            (0, e2.isValidElement)(t) && e.push(t)
        }), e
    }
    t.s(["AnimatePresence", 0, ({
        children: t,
        custom: e,
        initial: i = !0,
        onExitComplete: n,
        presenceAffectsLayout: s = !0,
        mode: r = "sync",
        propagate: o = !1,
        anchorX: a = "left",
        anchorY: l = "top",
        root: h
    }) => {
        let [u, d] = sx(o), c = (0, e2.useMemo)(() => rU(t), [t]), p = o && !u ? [] : c.map(rO), m = (0, e2.useRef)(!0), f = (0, e2.useRef)(c), g = iu(() => new Map), y = (0, e2.useRef)(new Set), [v, x] = (0, e2.useState)(c), [w, T] = (0, e2.useState)(c);
        ib(() => {
            m.current = !1, f.current = c;
            for (let t = 0; t < w.length; t++) {
                let e = rO(w[t]);
                p.includes(e) ? (g.delete(e), y.current.delete(e)) : !0 !== g.get(e) && g.set(e, !1)
            }
        }, [w, p.length, p.join("-")]);
        let b = [];
        if (c !== v) {
            let t = [...c];
            for (let e = 0; e < w.length; e++) {
                let i = w[e],
                    n = rO(i);
                p.includes(n) || (t.splice(e, 0, i), b.push(i))
            }
            return "wait" === r && b.length && (t = b), T(rU(t)), x(c), null
        }
        let {
            forceRender: S
        } = (0, e2.useContext)(e4);
        return (0, e9.jsx)(e9.Fragment, {
            children: w.map(t => {
                let v = rO(t),
                    x = (!o || !!u) && (c === w || p.includes(v));
                return (0, e9.jsx)(rF, {
                    isPresent: x,
                    initial: (!m.current || !!i) && void 0,
                    custom: e,
                    presenceAffectsLayout: s,
                    mode: r,
                    root: h,
                    onExitComplete: x ? void 0 : () => {
                        if (y.current.has(v) || !g.has(v)) return;
                        y.current.add(v), g.set(v, !0);
                        let t = !0;
                        g.forEach(e => {
                            e || (t = !1)
                        }), t && (S ? .(), T(f.current), o && d ? .(), n && n())
                    },
                    anchorX: a,
                    anchorY: l,
                    children: t
                }, v)
            })
        })
    }], 88653)
}]);